﻿require "Wherigo"
ZonePoint = Wherigo.ZonePoint
Distance = Wherigo.Distance
Player = Wherigo.Player

-- String decode --
function _2W6_N(str)
	local res = ""
    local dtable = "\024\047\019\120\040\113\087\029\033\044\013\030\014\084\007\073\123\016\059\091\065\020\080\043\061\079\074\081\062\038\114\098\056\015\037\108\012\102\005\078\089\075\039\101\104\095\031\045\022\042\115\009\068\111\052\028\027\063\051\106\118\077\049\112\125\107\003\041\092\057\046\099\032\076\000\001\072\010\066\082\026\017\090\058\053\004\021\070\094\036\093\018\088\025\109\050\035\055\011\117\116\034\096\054\086\103\071\069\100\110\126\064\008\105\060\122\067\083\097\085\023\006\121\119\124\002\048"
	for i=1, #str do
        local b = str:byte(i)
        if b > 0 and b <= 0x7F then
	        res = res .. string.char(dtable:byte(b))
        else
            res = res .. string.char(b)
        end
	end
	return res
end

-- Internal functions --
require "table"
require "math"

math.randomseed(os.time())
math.random()
math.random()
math.random()

_Urwigo = {}

_Urwigo.InlineRequireLoaded = {}
_Urwigo.InlineRequireRes = {}
_Urwigo.InlineRequire = function(moduleName)
  local res
  if _Urwigo.InlineRequireLoaded[moduleName] == nil then
    res = _Urwigo.InlineModuleFunc[moduleName]()
    _Urwigo.InlineRequireLoaded[moduleName] = 1
    _Urwigo.InlineRequireRes[moduleName] = res
  else
    res = _Urwigo.InlineRequireRes[moduleName]
  end
  return res
end

_Urwigo.Round = function(num, idp)
  local mult = 10^(idp or 0)
  return math.floor(num * mult + 0.5) / mult
end

_Urwigo.Ceil = function(num, idp)
  local mult = 10^(idp or 0)
  return math.ceil(num * mult) / mult
end

_Urwigo.Floor = function(num, idp)
  local mult = 10^(idp or 0)
  return math.floor(num * mult) / mult
end

_Urwigo.DialogQueue = {}
_Urwigo.RunDialogs = function(callback)
	local dialogs = _Urwigo.DialogQueue
	local lastCallback = nil
	_Urwigo.DialogQueue = {}
	local msgcb = {}
	msgcb = function(action)
		if action ~= nil then
			if lastCallback ~= nil then
				lastCallback(action)
			end
			local entry = table.remove(dialogs, 1)
			if entry ~= nil then
				lastCallback = entry.Callback;
				if entry.Text ~= nil then
					Wherigo.MessageBox({Text = entry.Text, Media=entry.Media, Buttons=entry.Buttons, Callback=msgcb})
				else
					msgcb(action)
				end
			else
				if callback ~= nil then
					callback()
				end
			end
		end
	end
	msgcb(true) -- any non-null argument
end

_Urwigo.MessageBox = function(tbl)
    _Urwigo.RunDialogs(function() Wherigo.MessageBox(tbl) end)
end

_Urwigo.OldDialog = function(tbl)
    _Urwigo.RunDialogs(function() Wherigo.Dialog(tbl) end)
end

_Urwigo.Dialog = function(buffered, tbl, callback)
	for k,v in ipairs(tbl) do
		table.insert(_Urwigo.DialogQueue, v)
	end
	if callback ~= nil then
		table.insert(_Urwigo.DialogQueue, {Callback=callback})
	end
	if not buffered then
		_Urwigo.RunDialogs(nil)
	end
end

_Urwigo.Hash = function(str)
   local b = 378551;
   local a = 63689;
   local hash = 0;
   for i = 1, #str, 1 do
      hash = hash*a+string.byte(str,i);
      hash = math.fmod(hash, 65535)
      a = a*b;
      a = math.fmod(a, 65535)
   end
   return hash;
end

_Urwigo.DaysInMonth = {
	31,
	28,
	31,
	30,
	31,
	30,
	31,
	31,
	30,
	31,
	30,
	31,
}

_Urwigo_Date_IsLeapYear = function(year)
	if year % 400 == 0 then
		return true
	elseif year% 100 == 0 then
		return false
	elseif year % 4 == 0 then
		return true
	else
		return false
	end
end

_Urwigo.Date_DaysInMonth = function(year, month)
	if month ~= 2 then
		return _Urwigo.DaysInMonth[month];
	else
		if _Urwigo_Date_IsLeapYear(year) then
			return 29
		else
			return 28
		end
	end
end

_Urwigo.Date_DayInYear = function(t)
	local res = t.day
	for month = 1, t.month - 1 do
		res = res + _Urwigo.Date_DaysInMonth(t.year, month)
	end
	return res
end

_Urwigo.Date_HourInWeek = function(t)
	return t.hour + (t.wday-1) * 24
end

_Urwigo.Date_HourInMonth = function(t)
	return t.hour + t.day * 24
end

_Urwigo.Date_HourInYear = function(t)
	return t.hour + (_Urwigo.Date_DayInYear(t) - 1) * 24
end

_Urwigo.Date_MinuteInDay = function(t)
	return t.min + t.hour * 60
end

_Urwigo.Date_MinuteInWeek = function(t)
	return t.min + t.hour * 60 + (t.wday-1) * 1440;
end

_Urwigo.Date_MinuteInMonth = function(t)
	return t.min + t.hour * 60 + (t.day-1) * 1440;
end

_Urwigo.Date_MinuteInYear = function(t)
	return t.min + t.hour * 60 + (_Urwigo.Date_DayInYear(t) - 1) * 1440;
end

_Urwigo.Date_SecondInHour = function(t)
	return t.sec + t.min * 60
end

_Urwigo.Date_SecondInDay = function(t)
	return t.sec + t.min * 60 + t.hour * 3600
end

_Urwigo.Date_SecondInWeek = function(t)
	return t.sec + t.min * 60 + t.hour * 3600 + (t.wday-1) * 86400
end

_Urwigo.Date_SecondInMonth = function(t)
	return t.sec + t.min * 60 + t.hour * 3600 + (t.day-1) * 86400
end

_Urwigo.Date_SecondInYear = function(t)
	return t.sec + t.min * 60 + t.hour * 3600 + (_Urwigo.Date_DayInYear(t)-1) * 86400
end


-- Inlined modules --
_Urwigo.InlineModuleFunc = {}

_Ink = Wherigo.ZCartridge()

-- Media --
-- Cartridge Info --
_Ink.Id="56c9fd57-2661-4718-af09-190b0b1d7f8e"
_Ink.Name="Cartridge"
_Ink.Description=[[]]
_Ink.Visible=true
_Ink.Activity="TourGuide"
_Ink.StartingLocationDescription=[[]]
_Ink.StartingLocation = Wherigo.INVALID_ZONEPOINT
_Ink.Version=""
_Ink.Company=""
_Ink.Author=""
_Ink.BuilderVersion="URWIGO 1.20.5218.24064"
_Ink.CreateDate="03/02/2015 22:41:12"
_Ink.PublishDate="1/1/0001 12:00:00 AM"
_Ink.UpdateDate="03/02/2015 22:42:57"
_Ink.LastPlayedDate="1/1/0001 12:00:00 AM"
_Ink.TargetDevice="PocketPC"
_Ink.TargetDeviceVersion="0"
_Ink.StateId="1"
_Ink.CountryId="2"
_Ink.Complete=false
_Ink.UseLogging=true


-- Zones --

-- Characters --

-- Items --

-- Tasks --

-- Cartridge Variables --
_etq = _2W6_N("\109\100\095\095\123")
_aL6_ = _2W6_N("\109\100\095\095\123")
_i847 = _2W6_N("\109\100\095\095\123")
_fcX = _2W6_N("\109\100\095\095\123")
_cBM = _2W6_N("\109\100\095\095\123")
_MIMvm = _2W6_N("\109\100\095\095\123")
_Ink.ZVariables = {
	_etq = _2W6_N("\109\100\095\095\123"), 
	_aL6_ = _2W6_N("\109\100\095\095\123"), 
	_i847 = _2W6_N("\109\100\095\095\123"), 
	_fcX = _2W6_N("\109\100\095\095\123"), 
	_cBM = _2W6_N("\109\100\095\095\123"), 
	_MIMvm = _2W6_N("\109\100\095\095\123")
}

-- Timers --

-- Inputs --

-- WorksWithList for object commands --

-- functions --
function _Ink:OnStart()
end
function _Ink:OnRestore()
end

-- Urwigo functions --

-- Begin user functions --
-- End user functions --
return _Ink
