require "Wherigo"
ZonePoint = Wherigo.ZonePoint
Distance = Wherigo.Distance
Player = Wherigo.Player

-- String decode --
function _EWiB1(str)
	local res = ""
    local dtable = "\067\038\040\036\019\020\059\126\027\076\084\065\015\053\111\093\116\004\090\102\047\043\007\024\052\101\009\039\106\010\114\122\078\051\074\113\048\096\061\017\083\121\049\112\098\058\025\002\071\118\095\108\056\123\085\011\079\029\060\030\031\100\081\032\062\069\000\091\103\013\063\097\012\124\005\077\099\041\034\001\003\008\035\014\075\006\026\073\110\094\087\028\033\089\044\092\057\054\070\117\022\042\046\115\088\045\119\080\037\021\055\018\120\104\016\107\068\082\066\064\125\105\109\050\023\086\072"
	for i=1, #str do
        local b = str:byte(i)
        if b > 0 and b <= 0x7F then
	        res = res .. string.char(dtable:byte(b))
        else
            res = res .. string.char(b)
        end
	end
	return res
end

-- Internal functions --
require "table"
require "math"

math.randomseed(os.time())
math.random()
math.random()
math.random()

_Urwigo = {}

_Urwigo.InlineRequireLoaded = {}
_Urwigo.InlineRequireRes = {}
_Urwigo.InlineRequire = function(moduleName)
  local res
  if _Urwigo.InlineRequireLoaded[moduleName] == nil then
    res = _Urwigo.InlineModuleFunc[moduleName]()
    _Urwigo.InlineRequireLoaded[moduleName] = 1
    _Urwigo.InlineRequireRes[moduleName] = res
  else
    res = _Urwigo.InlineRequireRes[moduleName]
  end
  return res
end

_Urwigo.Round = function(num, idp)
  local mult = 10^(idp or 0)
  return math.floor(num * mult + 0.5) / mult
end

_Urwigo.Ceil = function(num, idp)
  local mult = 10^(idp or 0)
  return math.ceil(num * mult) / mult
end

_Urwigo.Floor = function(num, idp)
  local mult = 10^(idp or 0)
  return math.floor(num * mult) / mult
end

_Urwigo.DialogQueue = {}
_Urwigo.RunDialogs = function(callback)
	local dialogs = _Urwigo.DialogQueue
	local lastCallback = nil
	_Urwigo.DialogQueue = {}
	local msgcb = {}
	msgcb = function(action)
		if action ~= nil then
			if lastCallback ~= nil then
				lastCallback(action)
			end
			local entry = table.remove(dialogs, 1)
			if entry ~= nil then
				lastCallback = entry.Callback;
				if entry.Text ~= nil then
					Wherigo.MessageBox({Text = entry.Text, Media=entry.Media, Buttons=entry.Buttons, Callback=msgcb})
				else
					msgcb(action)
				end
			else
				if callback ~= nil then
					callback()
				end
			end
		end
	end
	msgcb(true) -- any non-null argument
end

_Urwigo.MessageBox = function(tbl)
    _Urwigo.RunDialogs(function() Wherigo.MessageBox(tbl) end)
end

_Urwigo.OldDialog = function(tbl)
    _Urwigo.RunDialogs(function() Wherigo.Dialog(tbl) end)
end

_Urwigo.Dialog = function(buffered, tbl, callback)
	for k,v in ipairs(tbl) do
		table.insert(_Urwigo.DialogQueue, v)
	end
	if callback ~= nil then
		table.insert(_Urwigo.DialogQueue, {Callback=callback})
	end
	if not buffered then
		_Urwigo.RunDialogs(nil)
	end
end

_Urwigo.Hash = function(str)
   local b = 378551;
   local a = 63689;
   local hash = 0;
   for i = 1, #str, 1 do
      hash = hash*a+string.byte(str,i);
      hash = math.fmod(hash, 65535)
      a = a*b;
      a = math.fmod(a, 65535)
   end
   return hash;
end

_Urwigo.DaysInMonth = {
	31,
	28,
	31,
	30,
	31,
	30,
	31,
	31,
	30,
	31,
	30,
	31,
}

_Urwigo_Date_IsLeapYear = function(year)
	if year % 400 == 0 then
		return true
	elseif year% 100 == 0 then
		return false
	elseif year % 4 == 0 then
		return true
	else
		return false
	end
end

_Urwigo.Date_DaysInMonth = function(year, month)
	if month ~= 2 then
		return _Urwigo.DaysInMonth[month];
	else
		if _Urwigo_Date_IsLeapYear(year) then
			return 29
		else
			return 28
		end
	end
end

_Urwigo.Date_DayInYear = function(t)
	local res = t.day
	for month = 1, t.month - 1 do
		res = res + _Urwigo.Date_DaysInMonth(t.year, month)
	end
	return res
end

_Urwigo.Date_HourInWeek = function(t)
	return t.hour + (t.wday-1) * 24
end

_Urwigo.Date_HourInMonth = function(t)
	return t.hour + t.day * 24
end

_Urwigo.Date_HourInYear = function(t)
	return t.hour + (_Urwigo.Date_DayInYear(t) - 1) * 24
end

_Urwigo.Date_MinuteInDay = function(t)
	return t.min + t.hour * 60
end

_Urwigo.Date_MinuteInWeek = function(t)
	return t.min + t.hour * 60 + (t.wday-1) * 1440;
end

_Urwigo.Date_MinuteInMonth = function(t)
	return t.min + t.hour * 60 + (t.day-1) * 1440;
end

_Urwigo.Date_MinuteInYear = function(t)
	return t.min + t.hour * 60 + (_Urwigo.Date_DayInYear(t) - 1) * 1440;
end

_Urwigo.Date_SecondInHour = function(t)
	return t.sec + t.min * 60
end

_Urwigo.Date_SecondInDay = function(t)
	return t.sec + t.min * 60 + t.hour * 3600
end

_Urwigo.Date_SecondInWeek = function(t)
	return t.sec + t.min * 60 + t.hour * 3600 + (t.wday-1) * 86400
end

_Urwigo.Date_SecondInMonth = function(t)
	return t.sec + t.min * 60 + t.hour * 3600 + (t.day-1) * 86400
end

_Urwigo.Date_SecondInYear = function(t)
	return t.sec + t.min * 60 + t.hour * 3600 + (_Urwigo.Date_DayInYear(t)-1) * 86400
end


-- Inlined modules --
_Urwigo.InlineModuleFunc = {
	[0] = function()
		function dialog(text, media, bt_ok, on_ok)
			_Urwigo.Dialog(false, {
				{
					Text = text, 
					Media = media, 
					Buttons = {
						bt_ok
					}
				}
			}, function(action)
				if (action == "Button1") and on_ok then
					on_ok()
				end
			end)
			-- Dialog
		end
		function question(text, media, bt1, bt2, on1, on2)
			_Urwigo.Dialog(false, {
				{
					Text = text, 
					Media = media, 
					Buttons = {
						bt1, 
						bt2
					}
				}
			}, function(action)
				if (action == "Button1") and on1 then
					on1()
				elseif on2 then
					on2()
				end
			end)
			-- Dialog
		end
		function phone_ring()
			if Wherigo.NoCaseEquals(Env.Platform, "Vendor 1 ARM9") then
				Wherigo.PlayAudio(sound_phone_ring_garmin)
			else
				Wherigo.PlayAudio(sound_phone_ring)
			end
		end
		-- The player gets a phone call from someone and has
		-- the choice to either accept the call or reject it.
		--   call_notification             Text, that notifies the
		--                                 player of being called
		--   call_accept_audio             The phone call itself
		--   call_accept_alternate_text    The phone call as written text
		--   call_accept_image             The image shown on accepting
		--                                 the call, usually the caller
		--   on_accept                     Function to be invoked after
		--                                 having listened to the phone call
		--   call_reject_text              Text shown on rejecting the call
		--   on_reject                     Function to be invoked on rejecting
		--                                 the call, mostly triggering a timer
		--                                 that makes the caller ring again
		--                                 after some seconds
		function incoming_phone_call(call_notification, call_accept_audio, call_accept_alternate_text, call_accept_image, on_accept, call_reject_text, on_reject)
			phone_ring()
			_Urwigo.Dialog(false, {
				{
					Text = call_notification, 
					Media = img_telephone, 
					Buttons = {
						text_accept, 
						text_reject
					}
				}
			}, function(action)
				if action == "Button1" then
					Wherigo.PlayAudio(call_accept_audio)
					dialog(call_accept_alternate_text, call_accept_image, text_ok, on_accept)
				else
					dialog(call_reject_text, nil, text_ok, on_reject)
				end
			end)
			-- Dialog
		end
		-- Returns the vertices of a regular polygon
		--   center    center of the polygon
		--   radius    radius of the polygon in meters (default: 50m)
		--   edges     number of edges (default: 5)
		--   alpha     angle offset in degrees (default 0?)
		function regular_polygon(center, radius, edges, alpha)
			radius = radius or 50
			edges = edges or 5
			alpha = alpha or 0
			local result = {}
			for i = 1, edges do
				result[i] = Wherigo.TranslatePoint(center, Wherigo.Distance(radius, "m"), ((360 / edges) * i) + alpha)
			end
			return result
		end
	end, 
	[1] = function()
		-- Regular expressions:
		-- Replace Urwigo coordinates
		-- with Wherigo zone points:
		-- "(\d+.\d+)[NS]\s+(\d+.\d+)[EW]"
		-- ->
		-- "    Wherigo.ZonePoint\(\1, \2, 0\),"
		-- Note: Remove comma from last entry:
		-- ", 0\),(\s+)\}"
		-- ->
		-- ", 0\)\1\}"
		-- Using data from GPX files:
		-- "<trkpt lat="(\d+.\d+)" lon="(\d+.\d+)">.+?</trkpt>"
		-- ->
		-- "\1N \2E"
		-- Start location: 52.50991N 13.46219E
		zone_09_meet_greenwitch_points = {
			Wherigo.ZonePoint(52.5101257209479, 13.4644505381584, 0), 
			Wherigo.ZonePoint(52.5106317773181, 13.4649252891541, 0), 
			Wherigo.ZonePoint(52.5110366182187, 13.4640562534332, 0), 
			Wherigo.ZonePoint(52.5109092896278, 13.4639006853104, 0), 
			Wherigo.ZonePoint(52.510840727926, 13.4637558460236, 0)
		}
		zone_10_shake_off_pursuers_points = {
			Wherigo.ZonePoint(52.5107950200654, 13.4651345014572, 0), 
			Wherigo.ZonePoint(52.5106742204907, 13.4650701284409, 0), 
			Wherigo.ZonePoint(52.5107166636223, 13.4649762511253, 0)
		}
		zone_11_meet_greenwitch_points = {
			Wherigo.ZonePoint(52.51179894963, 13.4750372171402, 0), 
			Wherigo.ZonePoint(52.5117254921468, 13.4750828146935, 0), 
			Wherigo.ZonePoint(52.5116961091192, 13.4751579165459, 0), 
			Wherigo.ZonePoint(52.5117418160426, 13.4752115607262, 0), 
			Wherigo.ZonePoint(52.5117956848556, 13.4752061963081, 0), 
			Wherigo.ZonePoint(52.5118364945184, 13.4751471877098, 0), 
			Wherigo.ZonePoint(52.5118528183729, 13.4750479459763, 0)
		}
		zone_13_fionas_whereabouts_right_points = {
			Wherigo.ZonePoint(52.5092425570015, 13.4758847951889, 0), 
			Wherigo.ZonePoint(52.5091739926996, 13.4760993719101, 0), 
			Wherigo.ZonePoint(52.5092752066316, 13.4761878848076, 0), 
			Wherigo.ZonePoint(52.5093666254666, 13.4759947657585, 0)
		}
		zone_13_fionas_whereabouts_wrong_1_points = {
			Wherigo.ZonePoint(52.5082434665963, 13.4736049175262, 0), 
			Wherigo.ZonePoint(52.5081161299129, 13.4739857912064, 0), 
			Wherigo.ZonePoint(52.507954509745, 13.4738248586655, 0), 
			Wherigo.ZonePoint(52.508090009522, 13.4734627604485, 0)
		}
		zone_13_fionas_whereabouts_wrong_2_points = {
			Wherigo.ZonePoint(52.5102334624698, 13.4760430455208, 0), 
			Wherigo.ZonePoint(52.5102905980181, 13.4761986136436, 0), 
			Wherigo.ZonePoint(52.5103665065604, 13.4761583805084, 0), 
			Wherigo.ZonePoint(52.5103142684379, 13.4760229289532, 0)
		}
		zone_13_fionas_whereabouts_wrong_3_points = {
			Wherigo.ZonePoint(52.5093290784681, 13.4763059020042, 0), 
			Wherigo.ZonePoint(52.5095119157238, 13.4764185547829, 0), 
			Wherigo.ZonePoint(52.5096653678335, 13.4763622283936, 0), 
			Wherigo.ZonePoint(52.509523343027, 13.4761664271355, 0)
		}
		zone_13_fionas_whereabouts_wrong_4_points = {
			Wherigo.ZonePoint(52.5084328384175, 13.4765794873238, 0), 
			Wherigo.ZonePoint(52.5082777494865, 13.4767055511475, 0), 
			Wherigo.ZonePoint(52.5084410009777, 13.4768611192703, 0), 
			Wherigo.ZonePoint(52.5085732342411, 13.4767431020737, 0)
		}
		zone_16_fiona_points = {
			Wherigo.ZonePoint(52.5093617280338, 13.4761556982994, 0), 
			Wherigo.ZonePoint(52.5093405058188, 13.4762039780617, 0), 
			Wherigo.ZonePoint(52.5093209160728, 13.4761556982994, 0)
		}
		points_16_track_fiona = {
			Wherigo.ZonePoint(52.509254, 13.475991, 0), 
			Wherigo.ZonePoint(52.509266, 13.475984, 0), 
			Wherigo.ZonePoint(52.509284, 13.475999, 0), 
			Wherigo.ZonePoint(52.509297, 13.476013, 0), 
			Wherigo.ZonePoint(52.509309, 13.476023, 0), 
			Wherigo.ZonePoint(52.509319, 13.476033, 0), 
			Wherigo.ZonePoint(52.50933, 13.47604, 0), 
			Wherigo.ZonePoint(52.509339, 13.476045, 0), 
			Wherigo.ZonePoint(52.509357, 13.476057, 0), 
			Wherigo.ZonePoint(52.509383, 13.476066, 0), 
			Wherigo.ZonePoint(52.509396, 13.476077, 0), 
			Wherigo.ZonePoint(52.509398, 13.476092, 0), 
			Wherigo.ZonePoint(52.509408, 13.4761, 0), 
			Wherigo.ZonePoint(52.509416, 13.47611, 0), 
			Wherigo.ZonePoint(52.509427, 13.476114, 0), 
			Wherigo.ZonePoint(52.50944, 13.476121, 0), 
			Wherigo.ZonePoint(52.50945, 13.476124, 0), 
			Wherigo.ZonePoint(52.509459, 13.476124, 0), 
			Wherigo.ZonePoint(52.509469, 13.476126, 0), 
			Wherigo.ZonePoint(52.509479, 13.47612, 0), 
			Wherigo.ZonePoint(52.509492, 13.476116, 0), 
			Wherigo.ZonePoint(52.509502, 13.476125, 0), 
			Wherigo.ZonePoint(52.509513, 13.476127, 0), 
			Wherigo.ZonePoint(52.509541, 13.476157, 0), 
			Wherigo.ZonePoint(52.509551, 13.476187, 0), 
			Wherigo.ZonePoint(52.509552, 13.476204, 0), 
			Wherigo.ZonePoint(52.509554, 13.476222, 0), 
			Wherigo.ZonePoint(52.50956, 13.476247, 0), 
			Wherigo.ZonePoint(52.509575, 13.476252, 0), 
			Wherigo.ZonePoint(52.50959, 13.476262, 0), 
			Wherigo.ZonePoint(52.509604, 13.476274, 0), 
			Wherigo.ZonePoint(52.509621, 13.476287, 0), 
			Wherigo.ZonePoint(52.509638, 13.476297, 0), 
			Wherigo.ZonePoint(52.509659, 13.476305, 0), 
			Wherigo.ZonePoint(52.509672, 13.476331, 0), 
			Wherigo.ZonePoint(52.509683, 13.476357, 0), 
			Wherigo.ZonePoint(52.509694, 13.476382, 0), 
			Wherigo.ZonePoint(52.5097, 13.476404, 0), 
			Wherigo.ZonePoint(52.509705, 13.476424, 0), 
			Wherigo.ZonePoint(52.509708, 13.476442, 0), 
			Wherigo.ZonePoint(52.509713, 13.476466, 0), 
			Wherigo.ZonePoint(52.509721, 13.476489, 0), 
			Wherigo.ZonePoint(52.509722, 13.476524, 0), 
			Wherigo.ZonePoint(52.509726, 13.476547, 0), 
			Wherigo.ZonePoint(52.509727, 13.476568, 0), 
			Wherigo.ZonePoint(52.509729, 13.476587, 0), 
			Wherigo.ZonePoint(52.509733, 13.476608, 0), 
			Wherigo.ZonePoint(52.509739, 13.47663, 0), 
			Wherigo.ZonePoint(52.509744, 13.476648, 0), 
			Wherigo.ZonePoint(52.50975, 13.476662, 0), 
			Wherigo.ZonePoint(52.50976, 13.476686, 0), 
			Wherigo.ZonePoint(52.509769, 13.476716, 0), 
			Wherigo.ZonePoint(52.509777, 13.47673, 0), 
			Wherigo.ZonePoint(52.509785, 13.476748, 0), 
			Wherigo.ZonePoint(52.509794, 13.476776, 0), 
			Wherigo.ZonePoint(52.5098, 13.476795, 0), 
			Wherigo.ZonePoint(52.509808, 13.476816, 0), 
			Wherigo.ZonePoint(52.509814, 13.476848, 0), 
			Wherigo.ZonePoint(52.509818, 13.476865, 0), 
			Wherigo.ZonePoint(52.509819, 13.476887, 0), 
			Wherigo.ZonePoint(52.509818, 13.476902, 0), 
			Wherigo.ZonePoint(52.509821, 13.476927, 0), 
			Wherigo.ZonePoint(52.509822, 13.476947, 0), 
			Wherigo.ZonePoint(52.509817, 13.476989, 0), 
			Wherigo.ZonePoint(52.509823, 13.477019, 0), 
			Wherigo.ZonePoint(52.509831, 13.47704, 0), 
			Wherigo.ZonePoint(52.509832, 13.477061, 0), 
			Wherigo.ZonePoint(52.50982, 13.477082, 0), 
			Wherigo.ZonePoint(52.509816, 13.477107, 0), 
			Wherigo.ZonePoint(52.509817, 13.477127, 0), 
			Wherigo.ZonePoint(52.509819, 13.477142, 0), 
			Wherigo.ZonePoint(52.509825, 13.477162, 0), 
			Wherigo.ZonePoint(52.509831, 13.477186, 0), 
			Wherigo.ZonePoint(52.509836, 13.477223, 0), 
			Wherigo.ZonePoint(52.509841, 13.477252, 0), 
			Wherigo.ZonePoint(52.509849, 13.477287, 0), 
			Wherigo.ZonePoint(52.509861, 13.477317, 0), 
			Wherigo.ZonePoint(52.509872, 13.477349, 0), 
			Wherigo.ZonePoint(52.509882, 13.477372, 0), 
			Wherigo.ZonePoint(52.509891, 13.47738, 0), 
			Wherigo.ZonePoint(52.509899, 13.4774, 0), 
			Wherigo.ZonePoint(52.509908, 13.477422, 0), 
			Wherigo.ZonePoint(52.509924, 13.477466, 0), 
			Wherigo.ZonePoint(52.509934, 13.477496, 0), 
			Wherigo.ZonePoint(52.509942, 13.477522, 0), 
			Wherigo.ZonePoint(52.509953, 13.477553, 0), 
			Wherigo.ZonePoint(52.509959, 13.477569, 0), 
			Wherigo.ZonePoint(52.509964, 13.477585, 0), 
			Wherigo.ZonePoint(52.509971, 13.477617, 0), 
			Wherigo.ZonePoint(52.509974, 13.477642, 0), 
			Wherigo.ZonePoint(52.509977, 13.47767, 0), 
			Wherigo.ZonePoint(52.509983, 13.477691, 0), 
			Wherigo.ZonePoint(52.509986, 13.477705, 0), 
			Wherigo.ZonePoint(52.510002, 13.477711, 0), 
			Wherigo.ZonePoint(52.51001, 13.477728, 0), 
			Wherigo.ZonePoint(52.51002, 13.477733, 0), 
			Wherigo.ZonePoint(52.510031, 13.477733, 0), 
			Wherigo.ZonePoint(52.510039, 13.477711, 0), 
			Wherigo.ZonePoint(52.510047, 13.4777, 0), 
			Wherigo.ZonePoint(52.510055, 13.477686, 0), 
			Wherigo.ZonePoint(52.51006, 13.477664, 0), 
			Wherigo.ZonePoint(52.510075, 13.477667, 0), 
			Wherigo.ZonePoint(52.510088, 13.477664, 0), 
			Wherigo.ZonePoint(52.510098, 13.477652, 0), 
			Wherigo.ZonePoint(52.510111, 13.477643, 0), 
			Wherigo.ZonePoint(52.510123, 13.477631, 0), 
			Wherigo.ZonePoint(52.510144, 13.477618, 0), 
			Wherigo.ZonePoint(52.51016, 13.477608, 0), 
			Wherigo.ZonePoint(52.510165, 13.477595, 0), 
			Wherigo.ZonePoint(52.510175, 13.477572, 0), 
			Wherigo.ZonePoint(52.510184, 13.477561, 0), 
			Wherigo.ZonePoint(52.5102, 13.477545, 0), 
			Wherigo.ZonePoint(52.510213, 13.477537, 0), 
			Wherigo.ZonePoint(52.510221, 13.477521, 0), 
			Wherigo.ZonePoint(52.510231, 13.477505, 0), 
			Wherigo.ZonePoint(52.510242, 13.477496, 0), 
			Wherigo.ZonePoint(52.51026, 13.477478, 0), 
			Wherigo.ZonePoint(52.510274, 13.477452, 0), 
			Wherigo.ZonePoint(52.510292, 13.477441, 0), 
			Wherigo.ZonePoint(52.510312, 13.477427, 0), 
			Wherigo.ZonePoint(52.510325, 13.477428, 0), 
			Wherigo.ZonePoint(52.510341, 13.477423, 0), 
			Wherigo.ZonePoint(52.510347, 13.477409, 0), 
			Wherigo.ZonePoint(52.510356, 13.477401, 0), 
			Wherigo.ZonePoint(52.510381, 13.477389, 0), 
			Wherigo.ZonePoint(52.510402, 13.477379, 0), 
			Wherigo.ZonePoint(52.510417, 13.477373, 0), 
			Wherigo.ZonePoint(52.510422, 13.47736, 0), 
			Wherigo.ZonePoint(52.510442, 13.477359, 0), 
			Wherigo.ZonePoint(52.510454, 13.477354, 0), 
			Wherigo.ZonePoint(52.510478, 13.477337, 0), 
			Wherigo.ZonePoint(52.510493, 13.477337, 0), 
			Wherigo.ZonePoint(52.510516, 13.477335, 0), 
			Wherigo.ZonePoint(52.510528, 13.477332, 0), 
			Wherigo.ZonePoint(52.51054, 13.47732, 0), 
			Wherigo.ZonePoint(52.510557, 13.477315, 0), 
			Wherigo.ZonePoint(52.510578, 13.477311, 0), 
			Wherigo.ZonePoint(52.510597, 13.47731, 0), 
			Wherigo.ZonePoint(52.510616, 13.477319, 0), 
			Wherigo.ZonePoint(52.51063, 13.47732, 0), 
			Wherigo.ZonePoint(52.510641, 13.477315, 0), 
			Wherigo.ZonePoint(52.510655, 13.477333, 0), 
			Wherigo.ZonePoint(52.510671, 13.477333, 0), 
			Wherigo.ZonePoint(52.510682, 13.477343, 0), 
			Wherigo.ZonePoint(52.510701, 13.477345, 0), 
			Wherigo.ZonePoint(52.510726, 13.477344, 0), 
			Wherigo.ZonePoint(52.510738, 13.477345, 0), 
			Wherigo.ZonePoint(52.510746, 13.477358, 0), 
			Wherigo.ZonePoint(52.510767, 13.477348, 0), 
			Wherigo.ZonePoint(52.510793, 13.477351, 0), 
			Wherigo.ZonePoint(52.510822, 13.477343, 0), 
			Wherigo.ZonePoint(52.510849, 13.477341, 0), 
			Wherigo.ZonePoint(52.510862, 13.477346, 0), 
			Wherigo.ZonePoint(52.510879, 13.477346, 0), 
			Wherigo.ZonePoint(52.51091, 13.477337, 0), 
			Wherigo.ZonePoint(52.510927, 13.477345, 0), 
			Wherigo.ZonePoint(52.510939, 13.477344, 0), 
			Wherigo.ZonePoint(52.510957, 13.477329, 0), 
			Wherigo.ZonePoint(52.510971, 13.47733, 0), 
			Wherigo.ZonePoint(52.51098, 13.477326, 0), 
			Wherigo.ZonePoint(52.510993, 13.477333, 0), 
			Wherigo.ZonePoint(52.511005, 13.477334, 0), 
			Wherigo.ZonePoint(52.511014, 13.477336, 0), 
			Wherigo.ZonePoint(52.511026, 13.477334, 0), 
			Wherigo.ZonePoint(52.511043, 13.477335, 0), 
			Wherigo.ZonePoint(52.511058, 13.477332, 0), 
			Wherigo.ZonePoint(52.51107, 13.477348, 0), 
			Wherigo.ZonePoint(52.511082, 13.477357, 0), 
			Wherigo.ZonePoint(52.51109, 13.477376, 0), 
			Wherigo.ZonePoint(52.511101, 13.477368, 0), 
			Wherigo.ZonePoint(52.511114, 13.477359, 0), 
			Wherigo.ZonePoint(52.511123, 13.477357, 0), 
			Wherigo.ZonePoint(52.511142, 13.477362, 0), 
			Wherigo.ZonePoint(52.511155, 13.477366, 0), 
			Wherigo.ZonePoint(52.511174, 13.47736, 0), 
			Wherigo.ZonePoint(52.511197, 13.477359, 0), 
			Wherigo.ZonePoint(52.511213, 13.477356, 0), 
			Wherigo.ZonePoint(52.511232, 13.477352, 0), 
			Wherigo.ZonePoint(52.511249, 13.477355, 0), 
			Wherigo.ZonePoint(52.511269, 13.47734, 0), 
			Wherigo.ZonePoint(52.51129, 13.477322, 0), 
			Wherigo.ZonePoint(52.511314, 13.477317, 0), 
			Wherigo.ZonePoint(52.511321, 13.477334, 0), 
			Wherigo.ZonePoint(52.511331, 13.477344, 0), 
			Wherigo.ZonePoint(52.511345, 13.477347, 0), 
			Wherigo.ZonePoint(52.511363, 13.477342, 0), 
			Wherigo.ZonePoint(52.511377, 13.477333, 0), 
			Wherigo.ZonePoint(52.511386, 13.477322, 0), 
			Wherigo.ZonePoint(52.5114, 13.477311, 0), 
			Wherigo.ZonePoint(52.511412, 13.477308, 0), 
			Wherigo.ZonePoint(52.511422, 13.477308, 0), 
			Wherigo.ZonePoint(52.511438, 13.477312, 0), 
			Wherigo.ZonePoint(52.511452, 13.477314, 0), 
			Wherigo.ZonePoint(52.511471, 13.477309, 0), 
			Wherigo.ZonePoint(52.511482, 13.477309, 0), 
			Wherigo.ZonePoint(52.511504, 13.477303, 0), 
			Wherigo.ZonePoint(52.511518, 13.477296, 0), 
			Wherigo.ZonePoint(52.511526, 13.477305, 0), 
			Wherigo.ZonePoint(52.51155, 13.477295, 0), 
			Wherigo.ZonePoint(52.511566, 13.477287, 0), 
			Wherigo.ZonePoint(52.511576, 13.477282, 0), 
			Wherigo.ZonePoint(52.511587, 13.477277, 0), 
			Wherigo.ZonePoint(52.511599, 13.477271, 0), 
			Wherigo.ZonePoint(52.511617, 13.477257, 0), 
			Wherigo.ZonePoint(52.511635, 13.477245, 0), 
			Wherigo.ZonePoint(52.511647, 13.477221, 0), 
			Wherigo.ZonePoint(52.511661, 13.477211, 0), 
			Wherigo.ZonePoint(52.511673, 13.477198, 0), 
			Wherigo.ZonePoint(52.511682, 13.47718, 0), 
			Wherigo.ZonePoint(52.511693, 13.47716, 0), 
			Wherigo.ZonePoint(52.511704, 13.477149, 0), 
			Wherigo.ZonePoint(52.51172, 13.477138, 0), 
			Wherigo.ZonePoint(52.511734, 13.477124, 0), 
			Wherigo.ZonePoint(52.511752, 13.477138, 0), 
			Wherigo.ZonePoint(52.511768, 13.477155, 0), 
			Wherigo.ZonePoint(52.511792, 13.477181, 0), 
			Wherigo.ZonePoint(52.511823, 13.477226, 0), 
			Wherigo.ZonePoint(52.511832, 13.477266, 0), 
			Wherigo.ZonePoint(52.51185, 13.4773, 0), 
			Wherigo.ZonePoint(52.511871, 13.477309, 0), 
			Wherigo.ZonePoint(52.511893, 13.477311, 0), 
			Wherigo.ZonePoint(52.511906, 13.477323, 0), 
			Wherigo.ZonePoint(52.511926, 13.477354, 0), 
			Wherigo.ZonePoint(52.511945, 13.477386, 0), 
			Wherigo.ZonePoint(52.511971, 13.477416, 0), 
			Wherigo.ZonePoint(52.511999, 13.477431, 0), 
			Wherigo.ZonePoint(52.512019, 13.477441, 0), 
			Wherigo.ZonePoint(52.512037, 13.477452, 0), 
			Wherigo.ZonePoint(52.512052, 13.477472, 0), 
			Wherigo.ZonePoint(52.512056, 13.47749, 0), 
			Wherigo.ZonePoint(52.512058, 13.477509, 0), 
			Wherigo.ZonePoint(52.512058, 13.477539, 0), 
			Wherigo.ZonePoint(52.512055, 13.477558, 0), 
			Wherigo.ZonePoint(52.512049, 13.477587, 0), 
			Wherigo.ZonePoint(52.512049, 13.477618, 0), 
			Wherigo.ZonePoint(52.512055, 13.477655, 0), 
			Wherigo.ZonePoint(52.512059, 13.477693, 0), 
			Wherigo.ZonePoint(52.512064, 13.477724, 0), 
			Wherigo.ZonePoint(52.512071, 13.477754, 0), 
			Wherigo.ZonePoint(52.512076, 13.477781, 0), 
			Wherigo.ZonePoint(52.512091, 13.477784, 0), 
			Wherigo.ZonePoint(52.512108, 13.477784, 0), 
			Wherigo.ZonePoint(52.512126, 13.477793, 0), 
			Wherigo.ZonePoint(52.512138, 13.477805, 0), 
			Wherigo.ZonePoint(52.512157, 13.477815, 0), 
			Wherigo.ZonePoint(52.51217, 13.477822, 0), 
			Wherigo.ZonePoint(52.512185, 13.47782, 0), 
			Wherigo.ZonePoint(52.512202, 13.477811, 0), 
			Wherigo.ZonePoint(52.512194, 13.477827, 0), 
			Wherigo.ZonePoint(52.512187, 13.477849, 0), 
			Wherigo.ZonePoint(52.512184, 13.477868, 0), 
			Wherigo.ZonePoint(52.512188, 13.477882, 0), 
			Wherigo.ZonePoint(52.512212, 13.477883, 0), 
			Wherigo.ZonePoint(52.51225, 13.477902, 0), 
			Wherigo.ZonePoint(52.512318, 13.47793, 0), 
			Wherigo.ZonePoint(52.512401, 13.47795, 0), 
			Wherigo.ZonePoint(52.512467, 13.477952, 0), 
			Wherigo.ZonePoint(52.512514, 13.477952, 0), 
			Wherigo.ZonePoint(52.512564, 13.477912, 0), 
			Wherigo.ZonePoint(52.512602, 13.477893, 0), 
			Wherigo.ZonePoint(52.512744, 13.477798, 0), 
			Wherigo.ZonePoint(52.512805, 13.47777, 0), 
			Wherigo.ZonePoint(52.512815, 13.47777, 0), 
			Wherigo.ZonePoint(52.512809, 13.477752, 0), 
			Wherigo.ZonePoint(52.512819, 13.477746, 0), 
			Wherigo.ZonePoint(52.512803, 13.477708, 0), 
			Wherigo.ZonePoint(52.512799, 13.477689, 0), 
			Wherigo.ZonePoint(52.512807, 13.477682, 0), 
			Wherigo.ZonePoint(52.512832, 13.477636, 0), 
			Wherigo.ZonePoint(52.512865, 13.477635, 0), 
			Wherigo.ZonePoint(52.512875, 13.477636, 0), 
			Wherigo.ZonePoint(52.512907, 13.477631, 0), 
			Wherigo.ZonePoint(52.512933, 13.47763, 0), 
			Wherigo.ZonePoint(52.512954, 13.477623, 0), 
			Wherigo.ZonePoint(52.512963, 13.47761, 0), 
			Wherigo.ZonePoint(52.512976, 13.477609, 0), 
			Wherigo.ZonePoint(52.512994, 13.477592, 0), 
			Wherigo.ZonePoint(52.513006, 13.477575, 0), 
			Wherigo.ZonePoint(52.513023, 13.477558, 0), 
			Wherigo.ZonePoint(52.513034, 13.477549, 0), 
			Wherigo.ZonePoint(52.51305, 13.477537, 0), 
			Wherigo.ZonePoint(52.513061, 13.477533, 0), 
			Wherigo.ZonePoint(52.513071, 13.477529, 0), 
			Wherigo.ZonePoint(52.513086, 13.477516, 0), 
			Wherigo.ZonePoint(52.513105, 13.477507, 0), 
			Wherigo.ZonePoint(52.513125, 13.477494, 0), 
			Wherigo.ZonePoint(52.513137, 13.477485, 0), 
			Wherigo.ZonePoint(52.51315, 13.477478, 0), 
			Wherigo.ZonePoint(52.513166, 13.47746, 0), 
			Wherigo.ZonePoint(52.513184, 13.477437, 0), 
			Wherigo.ZonePoint(52.513199, 13.477413, 0), 
			Wherigo.ZonePoint(52.513216, 13.477389, 0), 
			Wherigo.ZonePoint(52.513233, 13.477368, 0), 
			Wherigo.ZonePoint(52.51325, 13.477353, 0), 
			Wherigo.ZonePoint(52.513267, 13.477343, 0), 
			Wherigo.ZonePoint(52.513283, 13.477334, 0), 
			Wherigo.ZonePoint(52.513296, 13.477328, 0), 
			Wherigo.ZonePoint(52.513311, 13.477324, 0), 
			Wherigo.ZonePoint(52.513329, 13.477308, 0), 
			Wherigo.ZonePoint(52.513343, 13.477303, 0), 
			Wherigo.ZonePoint(52.513359, 13.477306, 0), 
			Wherigo.ZonePoint(52.513371, 13.47731, 0), 
			Wherigo.ZonePoint(52.513392, 13.477333, 0), 
			Wherigo.ZonePoint(52.513402, 13.477349, 0), 
			Wherigo.ZonePoint(52.513415, 13.477365, 0), 
			Wherigo.ZonePoint(52.513424, 13.477373, 0), 
			Wherigo.ZonePoint(52.513436, 13.477381, 0), 
			Wherigo.ZonePoint(52.513446, 13.477397, 0), 
			Wherigo.ZonePoint(52.513453, 13.477408, 0), 
			Wherigo.ZonePoint(52.513472, 13.477428, 0), 
			Wherigo.ZonePoint(52.513488, 13.477443, 0), 
			Wherigo.ZonePoint(52.513506, 13.477468, 0), 
			Wherigo.ZonePoint(52.513518, 13.477488, 0), 
			Wherigo.ZonePoint(52.513526, 13.477501, 0), 
			Wherigo.ZonePoint(52.513534, 13.477512, 0), 
			Wherigo.ZonePoint(52.513543, 13.477532, 0), 
			Wherigo.ZonePoint(52.513556, 13.477554, 0), 
			Wherigo.ZonePoint(52.513566, 13.477573, 0), 
			Wherigo.ZonePoint(52.51357, 13.477593, 0), 
			Wherigo.ZonePoint(52.513591, 13.477589, 0), 
			Wherigo.ZonePoint(52.513612, 13.477576, 0), 
			Wherigo.ZonePoint(52.51363, 13.477564, 0), 
			Wherigo.ZonePoint(52.513643, 13.477554, 0), 
			Wherigo.ZonePoint(52.513654, 13.477552, 0), 
			Wherigo.ZonePoint(52.513667, 13.477551, 0), 
			Wherigo.ZonePoint(52.513687, 13.47756, 0), 
			Wherigo.ZonePoint(52.5137, 13.477565, 0), 
			Wherigo.ZonePoint(52.513715, 13.477571, 0), 
			Wherigo.ZonePoint(52.513727, 13.477577, 0), 
			Wherigo.ZonePoint(52.513736, 13.477578, 0), 
			Wherigo.ZonePoint(52.513746, 13.477581, 0), 
			Wherigo.ZonePoint(52.513762, 13.477596, 0), 
			Wherigo.ZonePoint(52.513775, 13.477607, 0), 
			Wherigo.ZonePoint(52.513795, 13.477625, 0), 
			Wherigo.ZonePoint(52.513805, 13.477631, 0), 
			Wherigo.ZonePoint(52.513814, 13.477636, 0), 
			Wherigo.ZonePoint(52.513823, 13.477644, 0), 
			Wherigo.ZonePoint(52.51384, 13.477656, 0), 
			Wherigo.ZonePoint(52.513849, 13.477665, 0), 
			Wherigo.ZonePoint(52.513862, 13.477678, 0), 
			Wherigo.ZonePoint(52.513874, 13.477686, 0), 
			Wherigo.ZonePoint(52.513895, 13.477692, 0), 
			Wherigo.ZonePoint(52.513907, 13.477691, 0), 
			Wherigo.ZonePoint(52.513924, 13.477692, 0), 
			Wherigo.ZonePoint(52.513943, 13.477707, 0), 
			Wherigo.ZonePoint(52.513957, 13.477736, 0), 
			Wherigo.ZonePoint(52.513971, 13.477771, 0), 
			Wherigo.ZonePoint(52.513972, 13.477796, 0), 
			Wherigo.ZonePoint(52.513975, 13.477831, 0), 
			Wherigo.ZonePoint(52.513978, 13.477846, 0), 
			Wherigo.ZonePoint(52.513982, 13.477873, 0), 
			Wherigo.ZonePoint(52.513983, 13.477893, 0), 
			Wherigo.ZonePoint(52.513977, 13.477927, 0), 
			Wherigo.ZonePoint(52.513965, 13.477968, 0), 
			Wherigo.ZonePoint(52.513954, 13.478, 0), 
			Wherigo.ZonePoint(52.513952, 13.478015, 0), 
			Wherigo.ZonePoint(52.513941, 13.478054, 0), 
			Wherigo.ZonePoint(52.513934, 13.478073, 0), 
			Wherigo.ZonePoint(52.513925, 13.478096, 0), 
			Wherigo.ZonePoint(52.513915, 13.478121, 0), 
			Wherigo.ZonePoint(52.513908, 13.478135, 0), 
			Wherigo.ZonePoint(52.513901, 13.478148, 0), 
			Wherigo.ZonePoint(52.513895, 13.478172, 0), 
			Wherigo.ZonePoint(52.51389, 13.478193, 0), 
			Wherigo.ZonePoint(52.513883, 13.478209, 0), 
			Wherigo.ZonePoint(52.513878, 13.478216, 0)
		}
		zone_18_greenwitch_meets_daughter_points = {
			Wherigo.ZonePoint(52.5135978034519, 13.478070795536, 0), 
			Wherigo.ZonePoint(52.5136304498464, 13.4778964519501, 0), 
			Wherigo.ZonePoint(52.513736550461, 13.4778106212616, 0), 
			Wherigo.ZonePoint(52.5138442831306, 13.4778428077698, 0), 
			Wherigo.ZonePoint(52.5139226339971, 13.4779098629951, 0), 
			Wherigo.ZonePoint(52.5140271016018, 13.4779876470566, 0), 
			Wherigo.ZonePoint(52.5139650739915, 13.4782049059868, 0), 
			Wherigo.ZonePoint(52.5139014139846, 13.478422164917, 0), 
			Wherigo.ZonePoint(52.5137218596219, 13.4782934188843, 0)
		}
		zone_21a_traitors_end_points = {
			Wherigo.ZonePoint(52.5152855902599, 13.4818956255913, 0), 
			Wherigo.ZonePoint(52.5151892869539, 13.4818634390831, 0), 
			Wherigo.ZonePoint(52.51515174493, 13.4821638464928, 0), 
			Wherigo.ZonePoint(52.5152790612289, 13.4821960330009, 0)
		}
		--[[
		The actual first actual position of the helicopter will be calculated in
		function trigger_22_helicopter(), after setting its random direction.
		This point will then be the center of the pentagonal zone_22_helicopter.
		--]]
		location_22_helicopter = Wherigo.ZonePoint(52.5144972027497, 13.4766411781311, 0)
		zone_22_helicopter_points = {
			Wherigo.ZonePoint(52.5144972027497, 13.4766411781311, 0), 
			Wherigo.ZonePoint(52.514644108327, 13.4769201278687, 0), 
			Wherigo.ZonePoint(52.514712664095, 13.476625084877, 0)
		}
		zone_22_road_block_1_points = {
			Wherigo.ZonePoint(52.5131130016395, 13.4758472442627, 0), 
			Wherigo.ZonePoint(52.5106056584222, 13.4992790222168, 0), 
			Wherigo.ZonePoint(52.5156463177165, 13.500394821167, 0), 
			Wherigo.ZonePoint(52.5178661138022, 13.4785509109497, 0), 
			Wherigo.ZonePoint(52.5160119389039, 13.4821128845215, 0), 
			Wherigo.ZonePoint(52.5155679699233, 13.4866189956665, 0), 
			Wherigo.ZonePoint(52.5159074760179, 13.4876489639282, 0), 
			Wherigo.ZonePoint(52.5153590417921, 13.4915971755981, 0), 
			Wherigo.ZonePoint(52.5149411825492, 13.4920263290405, 0), 
			Wherigo.ZonePoint(52.5145494359001, 13.4978199005127, 0), 
			Wherigo.ZonePoint(52.5119377023187, 13.497519493103, 0), 
			Wherigo.ZonePoint(52.513792049142, 13.4776496887207, 0)
		}
		zone_22_road_block_2_points = {
			Wherigo.ZonePoint(52.5140597476774, 13.4817051887512, 0), 
			Wherigo.ZonePoint(52.5140597476774, 13.4819841384888, 0), 
			Wherigo.ZonePoint(52.5143078570589, 13.4819304943085, 0), 
			Wherigo.ZonePoint(52.5144580278461, 13.4817802906036, 0), 
			Wherigo.ZonePoint(52.5143862070989, 13.4815764427185, 0), 
			Wherigo.ZonePoint(52.5142360360662, 13.4817159175873, 0)
		}
		zone_22_road_block_3_points = {
			Wherigo.ZonePoint(52.5152562096127, 13.4905993938446, 0), 
			Wherigo.ZonePoint(52.5151174674019, 13.4907227754593, 0), 
			Wherigo.ZonePoint(52.5151778611239, 13.4909051656723, 0), 
			Wherigo.ZonePoint(52.5153117063743, 13.4907495975494, 0)
		}
		-- Agent 1 patrols this route
		points_22_agent_1 = {
			Wherigo.ZonePoint(52.5145665748891, 13.4847575426102, 0), 
			Wherigo.ZonePoint(52.5146449244677, 13.4847240149975, 0), 
			Wherigo.ZonePoint(52.514707767258, 13.4847401082516, 0), 
			Wherigo.ZonePoint(52.5147624485738, 13.4847508370876, 0), 
			Wherigo.ZonePoint(52.5148130491338, 13.4847642481327, 0), 
			Wherigo.ZonePoint(52.5148620173621, 13.4847803413868, 0), 
			Wherigo.ZonePoint(52.5149101694001, 13.4847964346409, 0), 
			Wherigo.ZonePoint(52.5149672988683, 13.4848165512085, 0), 
			Wherigo.ZonePoint(52.5150260605295, 13.4848487377167, 0), 
			Wherigo.ZonePoint(52.5150701317239, 13.484915792942, 0), 
			Wherigo.ZonePoint(52.5150668671925, 13.4849855303764, 0), 
			Wherigo.ZonePoint(52.515029325064, 13.4850284457207, 0), 
			Wherigo.ZonePoint(52.5149779086185, 13.4850458800793, 0), 
			Wherigo.ZonePoint(52.5149289405193, 13.4850177168846, 0), 
			Wherigo.ZonePoint(52.5148783400928, 13.485005646944, 0), 
			Wherigo.ZonePoint(52.5148187620965, 13.484992235899, 0), 
			Wherigo.ZonePoint(52.5147551033263, 13.4849788248539, 0), 
			Wherigo.ZonePoint(52.5146906283241, 13.4849680960178, 0), 
			Wherigo.ZonePoint(52.5146343146372, 13.4849439561367, 0), 
			Wherigo.ZonePoint(52.5145592296089, 13.484907746315, 0)
		}
		-- Agent 2 patrols this route
		points_22_agent_2 = {
			Wherigo.ZonePoint(52.5156161211877, 13.4889491647482, 0), 
			Wherigo.ZonePoint(52.5155826601452, 13.4890235960484, 0), 
			Wherigo.ZonePoint(52.5155426700853, 13.4890497475863, 0), 
			Wherigo.ZonePoint(52.5154671785466, 13.4890933334827, 0), 
			Wherigo.ZonePoint(52.5154210674348, 13.4891422837973, 0), 
			Wherigo.ZonePoint(52.5153488401977, 13.4891355782747, 0), 
			Wherigo.ZonePoint(52.5152647789701, 13.4891168028116, 0), 
			Wherigo.ZonePoint(52.5152027531068, 13.4890685230494, 0), 
			Wherigo.ZonePoint(52.5151064496193, 13.4890108555555, 0), 
			Wherigo.ZonePoint(52.515115427072, 13.4889256954193, 0), 
			Wherigo.ZonePoint(52.5152003047158, 13.4888425469398, 0), 
			Wherigo.ZonePoint(52.5152843660666, 13.4888284653425, 0), 
			Wherigo.ZonePoint(52.5153627143655, 13.4888177365065, 0), 
			Wherigo.ZonePoint(52.5154316770754, 13.4887956082821, 0), 
			Wherigo.ZonePoint(52.5154781962387, 13.4887607395649, 0), 
			Wherigo.ZonePoint(52.515539405589, 13.4888023138046, 0), 
			Wherigo.ZonePoint(52.5156055115917, 13.4888908267021, 0)
		}
		-- Agent 3 patrols this route
		points_22_agent_3 = {
			Wherigo.ZonePoint(52.5142715385035, 13.4932782500982, 0), 
			Wherigo.ZonePoint(52.5143364221938, 13.4932976961136, 0), 
			Wherigo.ZonePoint(52.5143845748078, 13.4933090955019, 0), 
			Wherigo.ZonePoint(52.5144237497769, 13.4933272004128, 0), 
			Wherigo.ZonePoint(52.5144719022951, 13.4933318942785, 0), 
			Wherigo.ZonePoint(52.5145123014012, 13.4933439642191, 0), 
			Wherigo.ZonePoint(52.5145584134666, 13.4933486580849, 0), 
			Wherigo.ZonePoint(52.51457473631, 13.4932923316956, 0), 
			Wherigo.ZonePoint(52.5145478036151, 13.4932232648134, 0), 
			Wherigo.ZonePoint(52.514493530104, 13.4932111948729, 0), 
			Wherigo.ZonePoint(52.5144523148365, 13.4931991249323, 0), 
			Wherigo.ZonePoint(52.5144110995303, 13.49319845438, 0), 
			Wherigo.ZonePoint(52.5143698841855, 13.4931870549917, 0), 
			Wherigo.ZonePoint(52.5143070409119, 13.4931917488575, 0)
		}
		zone_23_hospital_points = {
			Wherigo.ZonePoint(52.5142621528044, 13.4943652153015, 0), 
			Wherigo.ZonePoint(52.5142474621411, 13.4945073723793, 0), 
			Wherigo.ZonePoint(52.5141462596603, 13.4944939613342, 0), 
			Wherigo.ZonePoint(52.5141119813478, 13.4947675466537, 0), 
			Wherigo.ZonePoint(52.5142066547172, 13.4947943687439, 0), 
			Wherigo.ZonePoint(52.5141968609298, 13.4949150681496, 0), 
			Wherigo.ZonePoint(52.5142850049376, 13.4949338436127, 0), 
			Wherigo.ZonePoint(52.5143421352186, 13.4943893551826, 0)
		}
		zone_23c_heroes_end_points = {
			Wherigo.ZonePoint(52.5160641702537, 13.5006523132324, 0), 
			Wherigo.ZonePoint(52.5157181364041, 13.5005879402161, 0), 
			Wherigo.ZonePoint(52.5156659046429, 13.5011029243469, 0), 
			Wherigo.ZonePoint(52.516018467826, 13.5011780261993, 0)
		}
		zone_24d_mourners_end_points = {
			Wherigo.ZonePoint(52.5184512399019, 13.492289185524, 0), 
			Wherigo.ZonePoint(52.5184414470606, 13.4925292432308, 0), 
			Wherigo.ZonePoint(52.5185997643943, 13.4925372898579, 0), 
			Wherigo.ZonePoint(52.5186005804615, 13.492294549942, 0)
		}
	end, 
	[2] = function()
		memo_name = "Notizblock"
		memo_description = "Im Notizblock wird festgehalten, was bisher geschehen ist."
		memo_command_view_caption = "Anschauen"
		function save_game(entry)
			if entry then
				text_memo = string.format([[%s
---
%s]], entry, text_memo)
			end
			prometheus_chapter_2:RequestSync()
		end
		text_memo = "Hier halte ich in umgekehrter chronologischer Reihenfolge wichtige Ereignisse fest. Ich kann im ?brigen extrem schnell schreiben! :-D Bei wichtigen Ereignissen wird das Spiel automatisch gespeichert und hier ein Eintrag gemacht."
		text_event_01_previously = "Ich hab das Virus unsch?dlich gemacht und John Greenwitch nicht an Mr. Johnson verkauft. Mr. Johnson ist mir daf?r bestimmt b?se und wird mir wohl auch die Konsequenzen meines Heldspielens aufzeigen, sollten wir uns je wieder begegnen. Allerdings ich habe da so ein Gef?hl..."
		text_event_04_call_from_johnson = "Mr. Johnson rief mich an und wies mich auf einen Nachrichtenbeitrag hin. Das Virus breitet sich wohl schneller aus, als bef?rchtet. Johnson macht mich daf?r verantwortlich und beauftragt mich, noch einmal mit John Greenwitch zu sprechen."
		text_event_06a_call_from_johnson_daughter_abducted = "\"... es geht um Greenwitchs Tochter. Er wird ihre Hilfe ben?tigen!\" hat Johnson mir gesagt. Sollte ich Greenwitch davon berichten oder ist das nur einfache Panikmache?"
		text_event_08_call_to_greenwitch_a_honest = "Ich habe Greenwitch von Johnsons Anruf berichtet. Er will mich treffen."
		text_event_08_call_to_greenwitch_b_hide = "Ich habe mit John Greenwitch gesprochen, ihm aber verschwiegen, dass Johnson mich anrief. Greenwitch will mich treffen."
		text_event_08_call_to_greenwitch_c_a06 = [[Ich habe Greenwitch von Johnsons Anruf berichtet und auch davon, dass es "um seine Tochter ginge". Greenwitch will mich treffen.
2GHHJR]]
		text_event_10_shake_off_pursuers_first = "Greenwitch hat mir pl?tzlich einen anderen Treffpunkt ?bermittelt. Ich sollte mich dort hin begeben. Und ich werde beobachtet. Ich sollte meine Verfolger so schnell wie m?glich loswerden. Wahrscheinlich wird mir das nicht gleich beim ersten Versuch gelingen."
		text_event_11_call_from_greenwitch_abduction = "Greenwitchs Tochter Fiona wurde entf?hrt. Er sandte mir einen Mitschnitt vom Anruf. Ich sollte mit den anh?ren, vielleicht gibt es ein paar Hinweise auf ihren Verbleib. Und ich sollte meine UV-Lampe bereithalten. Vielleicht hat gibt es irgendwelche Spuren..."
		text_event_11_call_from_greenwitch_abduction_known = "Geahnt hatte ich es schon: Greenwitchs Tochter Fiona wurde entf?hrt. Er sandte mir einen Mitschnitt vom Anruf. Ich sollte mir den anh?ren, vielleicht gibt es ein paar Hinweise auf ihren Verbleib. Und ich sollte meine UV-Lampe bereithalten. Vielleicht hat gibt es irgendwelche Spuren..."
		text_event_15_call_from_johnson_radio_tag = "Mr. Johnson hat Fiona entf?hrt, um meine Aufmerksamkeit zu erhalten. Die Spurensuche brachte mich zur Wohnung von einer Journalistin namens H. Onekana. Sie ist Patient 0, der Indexfall f?r Berlin. Sie liegt in Quarant?ne und d?rfte die Nacht wohl nicht ?berleben. Johnson redete mir ins Gewissen, dass wenn ich schon so einen Aufwand betreibe, Greenwitchs Tochter zu finden, dann sollte ich mir aber auch vor Augen f?hren, was passieren wird, wenn das Gegenmittel nicht in Masse produziert werden kann. Er hat Fiona mit einem Peilsender versehen und sie laufen lassen. Ich soll ihr unauff?llig folgen. Johnson vermutet, sie trifft sich mit ihrem Vater."
		text_event_17_call_from_johnson_stay = "Fiona trifft ihren Vater. Johnson bedeutet mir stehen zu bleiben, damit die beiden nicht gewarnt werden. Ich k?nnte noch etwas n?her ran gehen, wenn ich dem Gespr?ch zwischen den beiden lauschen m?chte."
		text_event_20a_johnson_kidnaps_greenwitch = "Es geht alles sehr schnell. Ein schwarzer Van f?hrt vor und ein paar Gorillas in schicken Anz?gen steigen aus und verwickeln Greenwitch in einen Faustkampf. W?hrend seine Tochter Fiona fliehen kann, wird John ohnm?chtig geschlagen und in den Van gezogen und abtransportiert. Ich kann nur hoffen, dass das Gegenmittel schnell synthetisiert und weltweit verbreitet wird."
		text_event_21a_call_from_johnson_gratitude_traitors_end = "Johnson ist mir dankbar und l?sst mich das auch wissen. Er m?chte mich einmal mehr f?r die Zeus Inc. rekrutieren. Ich denke, ich bin diesmal bereit daf?r. Dazu soll ich mich an den toten Briefkasten begeben und in die Mitarbeiterliste eintragen."
		text_event_21b_call_from_johnson_threat = "Ich habe Greenwitch und seine Tochter gewarnt. Greenwitch gab mir daraufhin das Gegenmittel, das ich so schnell wie m?glich zu seiner Kontaktperson im Krankenhaus bringen soll. Nun rief mich auch Johnson an und lie? mich wissen, wie gering er mich und meine Entscheidung achtet. Er hetzt seine Leute auf mich, um gewaltsam an das Gegenmittel zu kommen. Ich muss mich zum Krankenhaus beeilen."
		text_event_23c_reaching_hospital_heroes_end = [[Ich hab Greenwitchs Kontakt, eine ?rztin, rechtzeitig treffen k?nnen. Mit dem Gegenmittel wird sie Frau Onekana retten k?nnen. Au?erdem wird das Gegenmittel weiter synthetisiert, wobei das wohl tats?chlich nicht so schnell gehen wird, als wenn ein gro?er Konzern, wie Zeus Inc. das Gegenmittel bekommen h?tte...
Ich soll mich zu einem toten Briefkasten begeben und mich dort in eine Liste von Troubleshootern eintragen, die dann gerufen werden k?nnen, wenn man sie sp?ter braucht.]]
		text_event_23d_lost_antidote_to_johnson = "Ich konnte Johnsons Schergen nicht entkommen. Pl?tzlich war ich von Gorillas in schicken Anz?gen umzingelt. Sie nahmen mir nicht nur das Gegenmittel ab, sondern sorgten auch daf?r, dass ich Johnsons Verachtung f?r mich f?r die n?chsten Wochen nicht vergessen werde. Ich konnte Greenwitchs Kontakt, einer ?rztin, kaum in die Augen schauen als ich ihr sagte, dass ich versagt habe. Sie meinte, dass Frau Onekana damit die Nacht nicht ?berleben wird. Ich sollte zumindest zum Friedhof und mich ins Kondolenzbuch eintragen. Ein paar Worte sollte ich ihr zumindest hinterlassen..."
		text_event_completed_game = "Ich habe dieses Abenteuer beendet."
		text_event_completion_code = "Completion Code"
	end, 
	[3] = function()
		dialog_scripts_language = "german"
		text_yes = "ja"
		text_no = "nein"
		text_accept = "annehmen"
		text_reject = "ablehnen"
		text_ignore_call = "Sie ignorieren den Anruf"
		text_ok = "Okay"
		text_incoming_call_johnson = "Anruf von Mr. Johnson"
		text_incoming_call_greenwitch = "Anruf von Greenwitch"
		--[[
		DRAMATIS PERSONAE
		Johnson                     - Matze
		Greenwitch                  - Tobi
		Fiona Greenwitch (Tochter)  - Regina
		Nachrichtensprecher         - Mathi
		Arzt                        - Anastasia
		PATIENT_0                   - *** Keine Sprechrolle ***
		--]]
		character_john_greenwitch_name = "John Greenwitch"
		character_john_greenwitch_description = "John Greenwitch ist ein Virologe und ehemaliger Mitarbeiter der Prometheus Corporation. Als Whistleblower deckte er die Verstrickungen seines Unternehmens um das Pandora-Virus auf. Er ist bislang auch weltweit der einzige Wissenschaftler, der ein stabiles Gegenmittel gegen das Virus entwickelt hat. Die Zeus Incorporated will seiner unbedingt habhaft werden."
		character_fiona_greenwitch_name = "Fiona Greenwitch"
		character_fiona_greenwitch_description = "Fiona ist die Tochter von John Greenwitch. Mr. Johnson hatte sie entf?hrt, um an John Greenwitch heranzukommen."
		character_mr_johnson_name = "Mr. Johnson"
		character_mr_johnson_description = "Mr. Johnson arbeitet f?r die Zeus Incorporated, einem Konkurrenzunternehmen zur Prometheus Corporation. Er rekrutiert gern Laufburschen und m?chte John Greenwitch davon ?berzeugen, f?r die Zeus Inc. zu arbeiten."
		character_medical_doctor_name = "Dr. Who"
		character_medical_doctor_description = "Dr. Who ist John Greenwitchs Kontaktperson."
		-- 1) ---
		task_01_previously_name = "Was bisher geschah ..."
		task_01_previously_description = "Sie k?nnen sich entweder eine Zusammenfassung vom Vorg?nger (GC4CTGM) geben lassen oder gleich mit dem Spiel beginnen."
		question_01_previously = "Ben?tigen Sie eine Zusammenfassung von dem, was bisher geschah? Sie k?nnen sich die Zusammenfassung auch jederzeit noch einmal anschauen."
		text_01_previously = [[Prometheus - Chapter 1: Projekt Pandora
coord.info/GC4CTGM

Vor ein paar Monaten wurde ich von einem Whistleblower namens John Greenwitch angesprochen...]]
		-- 2) JohnsonAnruf 1.1
		text_02_call_from_johnson_1_1 = [[Ich gr??e Sie! Sie erinnern sich sicher noch an mich! Johnson. Ich arbeite f?r die Zeus Inc. Wir hatten vor einiger Zeit die Ehre, uns kennen zu lernen. Es ging um das Virus, das die Prometheus Corp. freisetzen wollte. Ich hatte Ihnen meine Hilfe angeboten aber Sie haben abgelehnt.
Es gibt da etwas, dass Sie sich ansehen sollten:]]
		-- 3) Nachrichtenbeitrag
		item_03_news_name = "Nachrichtenbeitrag"
		item_03_news_description = "Nachrichtenbeitrag ?ber die Ausbreitung des Virus"
		item_03_news_command_view_caption = "Anschauen"
		text_03_news_link = "http://www.youtube.com/watch?v=Kk3rVZ-ExoA"
		text_03_news = (([[Link zum Nachrichtenbeitrag:
]]..text_03_news_link)..[[

]])..[[... auch von Seiten der WHO gibt man sich ratlos. Von den 8.000 dokumentierten F?llen in Ostafrika verliefen mehr als 90 Prozent t?dlich.
In einer Pressekonferenz der WHO gab man bekannt, es werde nichts unversucht gelassen, ein Gegenmittel zu entwickeln. Experten sch?tzen, dass noch Monate vergehen werden, bis das Virus bek?mpft werden kann.
Heute Morgen gab das Ministerium f?r Gesundheit in Berlin eine erste best?tigte Infektion in Deutschland bekannt. Das Ausw?rtige Amt versch?rfte darauf hin noch einmal seine Reisewarnungen f?r eine Vielzahl der afrikanischen und nun erstmalig auch s?d-europ?ischen Staaten.
Bewahren Sie Ruhe!
Bleiben Sie wenn m?glich zu Hause und halten Sie sich von Menschenmassen fern. F?r den Fall, dass Sie Ihre Wohnung verlassen m?ssen, tragen Sie einen Mundschutz. Falls Sie Anzeichen von ?belkeit oder unerkl?rliche Blutungen haben, kontaktieren Sie umgehend den Rettungsdienst.
Das Bundesministerium f?r Gesundheit hat f?r weitere Fragen unter 0176 81 90 83 61 eine Servicehotline eingerichtet...]]
		-- Anrufbeantwortertext des Gesundheitsministeriums:
		-- DEACTIVATED in cartridge
		item_03_health_office_answering_machine_name = "0176 / 81 90 83 61"
		item_03_health_office_answering_machine_description = "Unter 0176 / 81 90 83 61 hat das Gesundheitsministerium eine Hotline geschaltet"
		item_03_health_office_answering_machine_command_call_caption = "Anrufen"
		-- Auf Mailbox sprechen: 0176 33 81 90 83 61, dann 3 (oder 9) (Geheimzahl 1033)
		text_03_health_office_answering_machine = "Willkommen beim Gesundheitsministerium. Bitte bewahren Sie Ruhe und verlassen Sie nach M?glichkeit nicht Ihre Wohnung. Falls Sie unerkl?rliche Symptome von ?belkeit versp?ren, kontaktieren Sie bitte umgehend den Rettungsdienst. Zur effizienteren Bearbeitung Ihres Vorganges, geben Sie dort bitte Ihre pers?nliche Bearbeitungsreferenz an. Diese lautet: R6T5J2. Ich wiederhole: R6T5J2. Vielen Dank!"
		-- 4) JohnsonAnruf 1.2
		text_04_call_from_johnson_1_2 = [[Was Sie hier sehen, ist nur die Spitze des Eisbergs. Die Medien sprechen von weltweit weniger als 10.000 Infizierten. Doch glauben Sie mir, die tats?chlichen Zahlen sind weitaus gr??er. Es wird versucht, die Menschen mit banalen Sicherheitsvorschriften ruhig zu halten.
All das sind nur bequeme L?gen, um ihnen ein Gef?hl von Sicherheit zu geben. Jeden Tag breitet sich das Virus schneller aus. Ein Heilmittel wird selbst von den optimistischsten Wissenschaftlern nicht in den n?chsten Monaten erwartet.
Aber in einem Punkt haben die Medien Recht: Heute Morgen wurde der erste Patient in ein Berliner Krankenhaus eingeliefert. Morgen schon wird es vermutlich die n?chsten Infizierten geben. Zun?chst die Familie, dann Freunde, Nachbarn...
In den n?chsten Wochen werden dutzende Menschen ?ber unerkl?rliche ?belkeit klagen. Bald schon versp?ren sie starken Husten, sp?ter unerkl?rliche Blutungen aus Mund, Nase und den Augen... Man wird sie ins Krankenhaus bringen, doch bis dahin haben sie wiederum Hunderte infiziert.
M?nner, Frauen, Kinder... sie alle werden sterben! Und alles nur, weil Sie den Helden spielen wollten.
Es wird Zeit, dass Sie ?ber die Konsequenzen Ihres Tuns nachdenken. Reden Sie noch einmal mit John Greenwitch! Er ist noch immer der Einzige, der bisherein Gegenmittel erschaffen konnte. Wir brauchen ihn.]]
		-- A5) -> A6) Johnson erz?hlt von Tochter
		text_06a_call_from_johnson_daughter_abducted = {
			"Ich habe Ihnen schon einmal nicht vertraut. Und ich vertraue Ihnen auch jetzt nicht!", 
			"Sie m?ssen mir nicht vertrauen. Aber es geht um Greenwitchs Tochter. Er wird Ihre Hilfe ben?tigen!"
		}
		-- B5) -> B6) ---
		text_05b_call_from_johnson = "Alles klar, ich rede mit ihm!"
		-- 7) ---
		task_07_call_to_greenwitch_name = "John Greenwitch anrufen"
		task_07_call_to_greenwitch_description = "Ich muss mit John Greenwitch sprechen"
		-- 8) Anrufen bei Greenwitch. Er geht ans Telefon und sagt:
		text_08_call_to_greenwitch = "Sie sind es? Hmm... was f?r ein Zufall, dass Sie ausgerechnet jetzt anrufen. Worum geht es?"
		-- A) Ehrlich -> Dankbar
		text_08_call_to_greenwitch_a_honest = {
			"Johnson hat mich gebeten, nach Ihnen zu schauen.", 
			"Ich hatte so etwas bereits bef?rchtet..."
		}
		-- B) Verheimlichen -> Angepisst
		text_08_call_to_greenwitch_b_hide = {
			"Ich habe geh?rt, wir haben einen ersten Ausbruch in Deutschland. Zeit etwas zu unternehmen!", 
			"Das klingt, als wollten Sie noch ?ber etwas anderes reden, aber gut..."
		}
		-- C) Nach Tochter fragen (NUR wenn A6 gew?hlt wurde) -> Wird schweigsam
		-- Da hab ich mal "Er hat Ihre Tocher" in "Es geht um Ihre Tochter" umgewandelt. Vielleicht nicht gleich mit der Entf?hrung rausplatzen. Das kommt ja eh gleich nochmal!
		text_08_call_to_greenwitch_c_a06 = {
			"Johnson rief mich an. \"Es geht um Ihre Tochter\", meinte er...", 
			[[Verstehe. Wir sollten nicht am Telefon dar?ber reden!
2GHHJR]]
		}
		-- Antwort auf alles von John Greenwitch
		text_08_call_to_greenwitch_end = "Treffen Sie mich an den folgenden Koordinaten. Schnell!"
		-- 9) ---
		-- 10) In Zone - Anruf von Greenwitch (Komm zu anderer Zone)
		-- TODO: ORT SPEZIFIZIEREN!
		text_10_call_from_greenwitch_followed = "Augen auf! Sie werden verfolgt. Es ist hier zu unsicher und ich brauche Sie ohnehin an einem anderen Ort. Kommen Sie so schnell wie m?glich zu ..."
		text_10_shake_off_pursuers_first = "Zun?chst muss ich meine Verfolger loswerden, bevor ich mich mit John Greenwitch treffen kann. Ich sollte diesen Ort erstmal verlassen und zur?ckkehren, wenn ich nicht mehr beobachtet werde."
		text_10_no_pursuers_anymore = "Ich denke ich habe meine Verfolger abgesch?ttelt. Ich sollte mich schnell zum Treffpunkt mit Greenwitch begeben."
		-- 11) Bei Punkt X: Anruf von Greenwitch.
		-- John Greenwitch erz?hlt von Entf?hrung, wenn der Spieler das
		-- nicht wei?, oder es Greenwitch nicht erz?hlt hat.
		text_11_call_from_greenwitch_abduction = [[Sehr gut. Ich glaube, es ist Ihnen niemand mehr gefolgt. Ich muss immer noch sehr vorsichtig sein. Vielleicht mehr denn je!
Aber ich habe den Punkt, an dem Sie sich befinden auch nicht zuf?llig gew?hlt. Es es geht um... Fiona... Meine Tochter. Sie wurde gestern von hier entf?hrt. Und Johnson steckt dahinter.
Dieser Hund will mich dazu bringen, ihm die Forschungsdaten zu geben. Er will ein Gegenmittel, dass er teuer verkaufen kann.
Gott, ich hatte nicht gedacht, dass er zu so etwas im Stande w?re. Wie konnte ich nur so naiv sein?
Ich... ich erhielt einen Anruf von ihr kurz nach der Entf?hrung. Ich sende Ihnen jetzt den Mitschnitt. Vielleicht hilft das, bei der Suche nach meiner Tochter.
Versuchen Sie mit Ihrer UV-Lampe Spuren zu finden.
Helfen Sie mir! Ich habe durch meine Arbeit schon ihre Mutter verloren. Ich kann nicht auch noch ohne meine Tochter leben. Ich bitte Sie! Bitte! Wenn nicht meinetwegen, dann um das Leben meiner Tochter zu sch?tzen!]]
		-- Auch hier erz?hlt John Greenwitch von der Entf?hrung, bezieht
		-- sich aber auf darauf, dass der Spieler das schon wei?.
		text_11_call_from_greenwitch_abduction_known = [[Sehr gut. Ich glaube, es ist Ihnen niemand mehr gefolgt. Ich muss immer noch sehr vorsichtig sein. Vielleicht mehr denn je!
Aber ich habe den Punkt, an dem Sie sich befinden auch nicht zuf?llig gew?hlt. Es es geht um Fiona... Meine Tochter. Sie wurde gestern von hier entf?hrt. Und Johnson steckt dahinter.
Dieser Hund will mich dazu bringen, ihm die Forschungsdaten zu geben. Er will ein Gegenmittel, dass er teuer verkaufen kann.
Gott, ich hatte nicht gedacht, dass er zu so etwas im Stande w?re. Wie konnte ich nur so naiv sein?
Ich... ich erhielt einen Anruf von ihr kurz nach der Entf?hrung. Ich sende Ihnen jetzt den Mitschnitt. Vielleicht hilft das, meine Tochter zu finden.
Versuchen Sie mit Ihrer UV-Lampe Spuren zu finden. Vielleicht k?nnen Sie so meine Tochter aufsp?ren. Helfen Sie mir! Ich habe durch meine Arbeit schon ihre Mutter verloren. Ich kann nicht auch noch ohne meine Tochter leben. Ich bitte Sie! Bitte! Wenn nicht meinetwegen, dann um das Leben meiner Tochter zu sch?tzen!]]
		-- 12) Item Telefonanruf
		--[[
		 (Ein Anruf von Johnson und Tochter):
		 verr?t ein paar Hinweise f?r Aufenthaltsort
		--]]
		item_12_call_from_johnson_abducted_daughter_name = "Mitschnitt von Fiona's Anruf"
		item_12_call_from_johnson_abducted_daughter_description = "John Greenwitch hat den Anruf von Mr. Johnson an ihn, bei dem auch seine Tochter sprach, mitgeschnitten. Er hat mir diesen Mitschnitt zugesandt, da Fiona Hinweise auf ihren Aufenthaltsort genannt hat."
		item_12_command_listen_caption = "Anh?ren"
		text_12_call_from_johnson_abducted_daughter = [[Papa? Bist Du da? Mir gehts gut, aber Du musst tun, was sie verlangen!
Hilf mir! Ich bin gleich bei den Br?cken an der Bahn und da ist... Das reicht f?r's Erste. (... unterbricht Johnson den Anruf)]]
		-- 13) ---
		task_13_find_fiona_name = "Fiona finden"
		task_13_find_fiona_description = "Ich muss Fiona finden. Am besten suche ich nach Hinweisen bei den m?glichen Aufenthaltsorten."
		question_13_fionas_whereabouts = "Ich muss herausfinden, wer sie festh?lt."
		-- 14) Richtige Zone gefunden
		text_14_call_from_johnson_right_zone = [[Nicht schlecht! Gar nicht schlecht! Sie haben meine Spur gefunden. Ich bin beeindruckt. Sie sind wirklich ein hervorragender Troubleshooter!
Ein Mensch mit au?ergew?hnlichen F?higkeiten. Die Zeus Inc. ben?tigt immer Mitarbeiter wie Sie! Aber nein... das ist nicht der Grund f?r Ihre Anwesenheit. Und nein, es ist auch nicht John Greenwitchs Tochter. Oh bitte, keine Angst. Ihr geht es gut. Ich bin kein Unmensch!
Ich will Ihnen etwas zeigen! Darum, sagen Sie mir: wie klang John Greenwitch, als er Ihnen von seiner Tochter erz?hlte? Hat er gebettelt? Hat er gewinselt? Sehen Sie sich nur an! Sie geben ALLES um nur ein einziges Menschenleben zu retten. Ein Kind, welches noch nicht einmal Ihr eigenes ist!
Weshalb tun Sie so etwas? Seinetwegen? Oder weil Sie Leben retten wollen? Glauben Sie mir, es stehen weit mehr Leben auf dem Spiel!
Nehmen Sie all sein Leid und all seine Sorgen und vertausendfachen Sie sie! Schon w?hrend wir reden, sterben Unschuldige. Nur, weil Sie den Helden spielen mussten! K?nnen Sie nach all dem noch immer die alleinige Verantwortung daf?r tragen?
Wissen Sie, ich habe Sie nicht ohne Grund an diesen Ort gef?hrt. Hier in der N?he wohnt Frau Onekana. 46 Jahre. Geschieden. Auslandskorrespondentin. Hat ein unehelichen Sohn... Eine ganz normale Frau. Bis auf eines... SIE ist die erste Infizierte. 'Patient 0'.
Zur Zeit liegt sie im Krankenhaus in Quarant?ne. Die ?rzte geben ihr vielleicht noch einen Tag. Was sch?tzen Sie? Wie viele ihrer Nachbarn hat sie wohl bereits infiziert? Wie viele werden in den n?chsten Wochen sterben? Und wie viele davon sind noch Kinder?
Verstehen Sie mich nicht falsch! John Greenwitchs Tochter ist in Sicherheit. Ich habe sie gehen lassen. Alles was ich brauchte, war Ihre ungeteilte Aufmerksamkeit. Die habe ich jetzt. Ich gebe Ihnen noch eine weitere Gelegenheit, das Richtige zu tun. Sie m?ssen mir helfen. Sie m?ssen uns ALLEN helfen. Arbeiten Sie mit mir zusammen - es gibt noch mehr Eltern, die Angst um ihre Kinder haben...]]
		-- 15) Peilsender angebracht - neuer Auftrag
		text_15_call_from_johnson_radio_tag = "... ich habe Greenwitchs Tochter ohne ihr Wissen mit einem Peilsender versehen. Sie wird sich mit ihrem Vater treffen wollen. Das ist unsere Gelegenheit, das Ganze doch noch zu einem guten Ende zu bringen. Ich werde Ihr Telefon so modifizieren, dass Sie ihre Position sehen k?nnen. F?r alles Weitere werde ich einen Funkkanal mit Ihnen offen halten. Folgen Sie ihr unauff?llig und geben Sie mir Bescheid, wenn Sie Greenwitch gefunden haben! Er hat noch immer das Gegenmittel. Nun liegt alles an Ihnen! Einmal mehr. Treffen Sie Ihre Entscheidung! Unsere Zukunft liegt in Ihren H?nden!"
		-- 16) Tochter-Zone wandert
		text_16_track_fiona = "John Greenwitchs Tochter schaut sich nerv?s um. Wenn sie sich beobachtet f?hlt, wird sie nicht zu ihrem Vater gehen. Besser ich folge ihr mit etwas Abstand."
		--[[
		Wie machen wir das hier? Erst Johnson, dann der Dialog?
		Dann m?ssen wir den nicht unterbrechen und 'ne Entscheidungslogik da rein quetschen.
		Aber cooler w?re nat?rlich, wenn die sich unterhalten und dann Johnson sagt, dass die Jungs kommen!
		Einfacher ist nat?rlich, den Dialog da zu haben und unten
		2 Buttons "Eingreifen" und "Nicht eingreifen!" zu haben.
		--]]
		-- 17) Nachricht von Johnson. Er hat gemerkt, dass Fiona stehen geblieben ist.
		text_17_call_from_johnson_stay = "Sie ist stehen geblieben. Ich sch?tze, sie hat ihn getroffen. Ich schicke meine Leute los. In etwa 4 Minuten ist alles geschafft! Unternehmen Sie nichts, bis wir ihn haben und halten Sie Abstand! Ich m?chte nicht, dass er gewarnt wird!"
		-- 18) Tochter trifft John, Dialog der beiden
		timeout_18_greenwitch_meets_daughter = {}
		text_18_greenwitch_meets_daughter = {}
		--[[
		Vorstop Spielzeit: 238 sekunden - Genug zum Handeln und noch einmal eine gute Zusammenfassung der "Verantwortung",
		die der Spieler hier tr?gt. Mir gef?llt der Dialog! :-)
		
		(=> Sie hat Dich geliebt so wie ich Dich liebe!)
		... joa ist recht herzschmerzig :)
		
		-----------------------------------------------------------------------------------
		--]]
		text_18 = "Fiona trifft ihren Vater. Sie beginnen ein Gespr?ch."
		function accumulate_text_18(next_argument)
			text_18 = string.format([[%s
---
%s]], next_argument, text_18)
		end
		-- Greenwitch:[?berrascht]
		timeout_18_greenwitch_meets_daughter[1] = 4
		text_18_greenwitch_meets_daughter[1] = [[John Greenwitch:
]].."Fio! Fiona? Bist Du das? Gott sei Dank! Bist Du verletzt?"
		-- Fiona: 
		timeout_18_greenwitch_meets_daughter[2] = 6
		text_18_greenwitch_meets_daughter[2] = [[Fiona:
]].."Oh gut, dass Du fragst. Mir geht es prima. Ich wurde nur mal eben entf?hrt. ?brigens: Deinetwegen!"
		-- Greenwitch:
		timeout_18_greenwitch_meets_daughter[3] = 5
		text_18_greenwitch_meets_daughter[3] = [[John Greenwitch:
]].."Mein Gott, es tut mir Leid, mein Liebling! Verzeih mir! Es wird alles wieder gut! Ich verspreche es Dir!"
		-- Fiona:
		timeout_18_greenwitch_meets_daughter[4] = 3
		text_18_greenwitch_meets_daughter[4] = [[Fiona:
]].."Ich hasse es, wenn Du Dinge versprichst, die Du nicht halten wirst."
		-- Greenwitch:
		timeout_18_greenwitch_meets_daughter[5] = 12
		text_18_greenwitch_meets_daughter[5] = [[John Greenwitch:
]].."Fio, ich wei?, Du gibst mir die Schuld daran. Aber es war dieser Johnson. Er allein ist daf?r verantwortlich. Eines Tages finde ich ihn. Und dann lasse ihn daf?r bezahlen was er Dir angetan hat! DAS verspreche ich Dir!"
		-- Fiona:
		timeout_18_greenwitch_meets_daughter[6] = 4
		text_18_greenwitch_meets_daughter[6] = [[Fiona:
]].."Mag sein, dass er mich entf?hrt hat. Aber was bitte hast Du getan, um mich da raus zu holen?"
		-- Greenwitch:
		timeout_18_greenwitch_meets_daughter[7] = 2
		text_18_greenwitch_meets_daughter[7] = [[John Greenwitch:
]].."Es ist bald vorbei!"
		-- Fiona: 
		timeout_18_greenwitch_meets_daughter[8] = 2
		text_18_greenwitch_meets_daughter[8] = [[Fiona:
]].."Was bitte soll das bedeuten?"
		-- Greenwitch:
		timeout_18_greenwitch_meets_daughter[9] = 12
		text_18_greenwitch_meets_daughter[9] = [[John Greenwitch:
]].."Ich habe das Gegenmittel bei mir. Ich muss es zum Krankenhaus bringen damit wir mehr davon herstellen k?nnen. Aber ich muss mich beeilen. Wir k?nnen niemandem trauen. Johnson wird alles tun, um es in seine Finger zu bekommen und wird er es verkaufen."
		-- Fiona:
		timeout_18_greenwitch_meets_daughter[10] = 3
		text_18_greenwitch_meets_daughter[10] = [[Fiona:
]].."Verdammt nochmal! Na und, dann soll er es doch verkaufen!"
		-- Greenwitch:
		timeout_18_greenwitch_meets_daughter[11] = 7
		text_18_greenwitch_meets_daughter[11] = [[John Greenwitch:
]].."Versteh doch, Fio. Er denkt nur an sein Geld. Aber das bekommt er nur, so lange er der Einzige ist, der das Gegenmittel produzieren kann."
		timeout_18_greenwitch_meets_daughter[12] = 7
		text_18_greenwitch_meets_daughter[12] = [[John Greenwitch:
]]..[[So lange ich wei?, wie man es herstellt, wird er uns jagen.
Es... es tut mir leid, dass ich Dich mit hineingezogen habe!]]
		-- Fiona: [zynisch] 
		timeout_18_greenwitch_meets_daughter[13] = 6
		text_18_greenwitch_meets_daughter[13] = [[Fiona:
]].."Oh, gut! Er wird uns also umbringen! Das macht es nat?rlich viel besser! Glaubst Du, Mom h?tte auch so gehandelt?"
		-- Greenwitch:
		timeout_18_greenwitch_meets_daughter[14] = 7
		text_18_greenwitch_meets_daughter[14] = [[John Greenwitch:
]].."Deine Mutter hat an das geglaubt, was wir getan haben. Was wir... was ICH immer noch tue! Sie glaubte an unsere Verantwortung."
		-- Fiona:
		timeout_18_greenwitch_meets_daughter[15] = 7
		text_18_greenwitch_meets_daughter[15] = [[Fiona:
]].."Ach ja? Hat sie vielleicht auch etwas ?ber Verantwortung gegen?ber der eigenen Familie gesagt? Ich glaube nicht, dass sie gerade stolz auf Dich w?re."
		-- Greenwitch:
		timeout_18_greenwitch_meets_daughter[16] = 9
		text_18_greenwitch_meets_daughter[16] = [[John Greenwitch:
]].."Du irrst Dich. Wenn Du Deine Mutter so gekannt h?ttest, wie ich sie damals kennen gelernt habe... Ach Gott, Du w?sstest, dass ihr alle Menschen wichtig waren. F?r sie war N?chstenliebe keine Frage des Geldes."
		timeout_18_greenwitch_meets_daughter[17] = 13
		text_18_greenwitch_meets_daughter[17] = [[John Greenwitch:
]].."Und sie hat sich niemals von denen abhalten lassen, die anders dachten. Deine Mutter war niemand, die einfach davon lief. Sie tat was sie f?r notwendig hielt. Auch wenn es bedeuten sollte, dass sie vielleicht niemals ihre eigene Tochter aufwachsen sehen w?rde."
		-- Fiona: [w?tend]
		timeout_18_greenwitch_meets_daughter[18] = 11
		text_18_greenwitch_meets_daughter[18] = [[Fiona:
]]..[[Nein! Das geschah, weil Du nicht auf sie aufpassen konntest!
Sieh Dich nur an! Ich werde entf?hrt und was tust Du? Statt nach Deiner eigenen Tochter zu suchen, rennst Du zum Krankenhaus um Gott zu spielen.]]
		timeout_18_greenwitch_meets_daughter[19] = 10
		text_18_greenwitch_meets_daughter[19] = [[Fiona:
]].."Wenn es nach Dir ginge, w?re ich jetzt auch irgendwo wie ein Hund verscharrt. Ist es das, was Du willst? Bist Du erst zufrieden, wenn niemand mehr da ist? Damit Du in aller Ruhe 'die Welt retten' kannst?"
		timeout_18_greenwitch_meets_daughter[20] = 12
		text_18_greenwitch_meets_daughter[20] = [[Fiona:
]].."Und sp?ter kannst Du jedem erz?hlen, was f?r ein Held Du warst! Welch furchtbaren Verlust Du daf?r auf Dich nehmen musstest! Nein, Du machst es Dir zu leicht! DU ALLEIN bist Schuld an ihrem Tod!"
		-- Greenwitch:
		timeout_18_greenwitch_meets_daughter[21] = 8
		text_18_greenwitch_meets_daughter[21] = [[John Greenwitch:
]].."Was denn? Was? Glaubst Du ich w?rde sie nicht auch jeden Tag vermissen? Aber Du hast recht... vielleicht habe ich Fehler begangen. Wer wei??"
		timeout_18_greenwitch_meets_daughter[22] = 13
		text_18_greenwitch_meets_daughter[22] = [[John Greenwitch:
]].."Es vergeht kein Tag, an dem ich mir nicht selbst die Schuld f?r ihren Tod gebe. Aber wir m?ssen lernen, mit den Konsequenzen unserer Entscheidungen zu leben! Und genau deswegen k?nnen wir nicht einfach unsere Augen verschlie?en und hoffen, dass alles irgendwann wieder besser wird. Denn das wird es nicht!"
		timeout_18_greenwitch_meets_daughter[23] = 7
		text_18_greenwitch_meets_daughter[23] = [[John Greenwitch:
]]..[[Es wird immer nur schlimmer.
Wir m?ssen daf?r k?mpfen, was uns wichtig ist! Du bist das Wichtigste in meinem Leben, Fio! Immer!]]
		timeout_18_greenwitch_meets_daughter[24] = 14
		text_18_greenwitch_meets_daughter[24] = (([[John Greenwitch:
]]..[[Und wir m?ssen uns bei jeder Entscheidung fragen, auf welcher Seite wir stehen und ob wir das Richtige tun.
Und irgendwann wenn all das hier vor?ber ist, und Du auf diese Zeit zur?ckblickst, wirst Du vielleicht erkennen warum ich das hier tun musste. Auch wenn es schmerzt.

]])..[[Fiona:
]]).."Papa!"
		-- Fiona:
		timeout_18_greenwitch_meets_daughter[25] = 3
		text_18_greenwitch_meets_daughter[25] = [[Fiona:
]].."Lass uns einfach weglaufen und ein normales Leben f?hren!"
		-- Greenwitch:
		timeout_18_greenwitch_meets_daughter[26] = 8
		text_18_greenwitch_meets_daughter[26] = [[John Greenwitch:
]].."Er wird uns finden. Er wird... mich... ?berall finden. Du hast Recht, ich habe Dich schon zu sehr in Gefahr gebracht!"
		timeout_18_greenwitch_meets_daughter[27] = 8
		text_18_greenwitch_meets_daughter[27] = (([[John Greenwitch:
]]..[[Es gibt nur eine L?sung. Du musst ohne mich fliehen. Lauf weg! Erz?hl niemandem, wo Du bist. Nicht einmal mir. Und bleib dort, bis alles vor?ber ist!

]])..[[Fiona:
]]).."Nein!"
		-- Fiona: [zitternd]
		timeout_18_greenwitch_meets_daughter[28] = 5
		text_18_greenwitch_meets_daughter[28] = [[Fiona:
]].."Ich musste schon ohne Mutter aufwachsen. Ich kann nicht auch noch ohne Vater leben!"
		-- Greenwitch:
		timeout_18_greenwitch_meets_daughter[29] = 5
		text_18_greenwitch_meets_daughter[29] = [[John Greenwitch:
]].."Wenn ich nicht zu Ende bringe, was ich begonnen habe, werden noch viele T?chter ohne ihre Eltern aufwachsen m?ssen..."
		timeout_18_greenwitch_meets_daughter[30] = 2
		text_18_greenwitch_meets_daughter[30] = [[John Greenwitch:
]].."Die Menschen brauchen mich!"
		-- Fiona:
		timeout_18_greenwitch_meets_daughter[31] = 3
		text_18_greenwitch_meets_daughter[31] = (((([[Fiona:
]]..[[Niemand braucht Dich...

]])..[[John Greenwitch:
]])..[[Ach Fio!

]])..[[Fiona:
]]).."... Nein, h?r mir zu!"
		-- Fiona: 
		timeout_18_greenwitch_meets_daughter[32] = 11
		text_18_greenwitch_meets_daughter[32] = [[Fiona:
]].."Niemand braucht Dich... so sehr wie ich! Aber... ich verstehe, warum Du das tun musst! Und Du tust das Richtige!"
		-- Greenwitch:
		timeout_18_greenwitch_meets_daughter[33] = 4
		text_18_greenwitch_meets_daughter[33] = [[John Greenwitch:
]].."Wei?t Du, wie sehr Du Deiner Mutter in solchen Momenten ?hnelst?"
		timeout_18_greenwitch_meets_daughter[34] = 5
		text_18_greenwitch_meets_daughter[34] = (((([[John Greenwitch:
]]..[[Hach Gott, ich habe sie so geliebt...

]])..[[Fiona:
]])..[[Ich liebe Dich, Papa!

]])..[[John Greenwitch:
]]).."Ich liebe Dich auch, mein Engel!"
		-- Greenwitch:
		timeout_18_greenwitch_meets_daughter[35] = 3
		text_18_greenwitch_meets_daughter[35] = [[John Greenwitch:
]].."Ich werde nicht zulassen, dass Dir etwas zust??t..."
		-- 19
		task_19_warn_greenwitch_or_wait_name = "Entscheidung"
		task_19_warn_greenwitch_or_wait_description = "Ich muss mich entscheiden! Entweder ich gehe zu John Greenwitch unterbreche sein Gespr?ch mit seiner Tochter um ihn zu warnen, oder ich warte ab, und lasse zu, dass ihn Mr. Johnsons Agenten ergreifen."
		text_19_warn_greenwitch = "Warnen!"
		text_19_cannot_warn_greenwitch = "Ich muss zu Greenwitch hingehen, um ihn zu warnen."
		text_19_cannot_warn_greenwitch_anymore = "Es ist zu sp?t, um Greenwitch zu warnen."
		--[[
		-----------------------------------------------------------------------------------
		Wenn nicht vorher "EINGREIFEN" geklickt wurde (und die Zeit um ist):
		
		DER WAGEN KOMMT UND SCHNAPPT DIE BEIDEN (oder nur JOHN GREENWITCH???
		Bleibt noch 'n offener Handlungsfaden, wenn sie in Teil 3 ggf. nach ihrem Vater sucht...)
		--]]
		-- A19) ---
		-- task_19_warn_greenwitch_or_wait -> "wait"
		-- A20) ---
		-- A21) Johnson ruft an und bedankt sich.
		text_21a_call_from_johnson_gratitude_traitors_end = [[Sehr gut, sehr gut. Ich danke Ihnen. Ich muss gestehen, ich hatte Zweifel, wem Ihre Loyalit?t gilt. Es freut mich umso mehr, zu erkennen, dass sie der ganzen Menschheit gilt.
Vielleicht schon in wenigen Wochen werden wir eine erste Serie des Gegenmittels herstellen k?nnen. Effizienter als es jedes lokale Krankenhaus jemals schaffen w?rde. Dank Ihres Einsatzes werden tausende Leben gerettet.
Sie haben das Richtige getan und ich bin froh, Sie in meinem Team zu wissen. Ich wei?, was jetzt folgt wird nicht einfach. Aber gemeinsam k?nnen wir viel bewegen. Ich verlasse mich auf Sie! Wir haben da einen toten Briefkasten. Ich hoffe, Sie werden diesmal endg?ltig f?r uns arbeiten!]]
		-- ENDE VERR?TER !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		-- B19) ---
		-- task_19_warn_greenwitch_or_wait -> "warn"
		-- B20) Greenwitch bedankt sich
		--[[
		Gibt Zusammenfassung ?ber den Plan.
		Gibt Spieler Gegenmittel und Task, ihn ins Krankenhaus zu bringen.
		Reden Sie auf jeden Fall mit unserer Kontaktperson dort!
		Er vernichtet den Peilsender und verschwindet.
		--]]
		text_20b_call_from_greenwitch_antidote = [[Sie hier? Ich verstehe. Danke!
Aber Johnson wird nicht weit sein. Ich vermute, die wissen bereits von meinem Plan. Aber mit Ihrer Hilfe bin ich zuversichtlich.
Sie m?ssen dieses Gegenmittel zum Krankenhaus bringen. Passen Sie auf Johnsons Schergen auf. Wenn die Sie in die Finger kriegen, haben wir alles verloren.
Aber bedenken Sie, was es zu gewinnen gibt, wenn Sie das Gegenmittel unserer Kontaktperson im Krankenhaus bringen. Wir werden Menschen retten!
Also los, verlieren wir keine Zeit. Beeilen Sie sich!]]
		item_20b_minigame_rules_name = "Minigame-Regeln"
		item_20b_minigame_rules_description = "Kurze Anleitung, wie man Mr. Johnsons Schergen ausweicht. ACHTUNG: Das Spiel wird dabei nicht pausiert!"
		item_20b_minigame_rules_content = ((([[Zun?chst eine allgemeine Information und eine Warnung: Die hier beschrieben Regeln kannst du dir jederzeit nochmal anschauen. ABER: Nur beim ersten Mal wird dabei auch das Spiel pausiert. Mr. Johnson hetzt seine Schergen auf dich und du musst denen ausweichen. Gelingt das nicht, ist das Gegengift verloren. Dieses Minispiel funktioniert mit bestimmten Arten von Zonen. Wir empfehlen daher, diesen Teil des Spiels ausschlie?lich mit der Karte zu spielen.

]]..[[Umgebende Zone: Das ist die Spielfeldbegrenzung. Diese Zone ist am st?rksten ?berwacht und darf auf gar keinen Fall betreten werden.

]])..[[F?nfeckige Zone: Das ist ein Helikopter, der dir folgt. Falls er dich erreicht, du also innerhalb der f?nfeckigen Zone bist, sucht er genauer und wenn er dich findet, hetzt er alle Vans auf dich. Du hast etwa eine Minute, diesen Suchbereich wieder zu verlassen.

]])..[[Rechteckige Zone: Dies ist eine Stra?ensperre bestehend aus schwarzen Vans. Diese Zone darfst du auf keinen Fall betreten.

]]).."Dreieckige Zone: Das ist ein patroullierender Agent, der nach dir sucht. Auch diese Zone darf auf keinen Fall betreten werden."
		item_20b_command_view_caption = "Anschauen"
		task_20b_bring_antidote_to_hospital_name = "Gegenmittel in Krankenhaus bringen"
		task_20b_bring_antidote_to_hospital_description = "Ich muss das Gegenmittel so schnell wie m?glich ins Krankenhaus bringen. Johnsons Leute werden mir hinterher sein"
		item_20_antidote_name = "Gegenmittel"
		item_20_antidote_description = "Ein Gegenmittel-Prototyp. Er neutralisiert das Virus in seiner jetzigen Form. Doch es mutiert schnell und Johnsen ist mir auf den Fersen. Ich muss es so schnell wie m?glich John Greenwitchs Kontaktperson im Krankenhaus ?bergeben, damit es in Massen synthetisiert werden kann."
		-- B21) Nachricht von Johnson: Er schickt seine Schergen los!
		text_21b_call_from_johnson_threat = [[Hmm, das verletzt mich... ich hatte gehofft, Sie w?ren ein Mensch, der aus seinen Fehlern lernen kann. Aber offenbar ist es Ihnen lieber, sich weiter als Rebell zu sehen.
Nun, ich habe Wichtigeres zu tun als mich mit einem Egoisten, wie Ihnen abzugeben. Bleiben Sie wo Sie sind und geben Sie das Gegenmittel einem meiner Agenten. Andernfalls muss ich Sie als Bedrohung der Zeus Inc. betrachten.]]
		-- B22) Johnsons Schergen entkommen
		-- C23) Im Krankenhaus angekommen
		text_23c_reaching_hospital_heroes_end = [[Hey, hier dr?ben! Sind Sie der Troubleshooter? Ich hatte Greenwitch erwartet. Man kann niemandem mehr trauen. Haben Sie das Gegenmittel? Fantastisch! Ich werde mich gleich darum k?mmern, es weiter zu synthetisieren. Wir retten Leben!
Ich wei? gar nicht, wie ich Ihnen genug danken kann. Aber es gibt keinen Grund unvorsichtig zu werden. Gerade jetzt m?ssen wir wachsam bleiben.
Der alte tote Briefkasten ist zu unsicher geworden. Der neue befindet sich an den folgenden Koordinaten. Ach und noch etwas... Ich glaube, ich spreche auch im Namen von Frau Onekana. Sie retten ihr Leben: Danke! Man bekommt nicht oft eine zweite Chance!]]
		-- HELDEN ENDE !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		-- D23) Johnsons Schergen nicht entkommen. Gegenmittel verloren
		-- D24) Am Krankenhaus angekommen
		--[[
		Am Krankenhaus wartet eine ?rztin (in Person):
		--]]
		text_24d_reaching_hospital_mourners_end = [[Hey hier dr?ben! Was... Oh nein! Was ist passiert? Wie sehen Sie denn aus? Wo ist das Gegenmittel?
Oh, verflucht! Das war ihre einzige Chance! Sie wird die Nacht nicht ?berleben... Ich habe noch noch eine Bitte an Sie: Beten Sie f?r Frau Onekana.
Es... es gibt da ein Kondolenzbuch. Sie hatte nicht viele Freunde aber vielleicht m?chten Sie ja ein paar Worte f?r sie hinterlassen. Ein letzter Moment in stillem Gedenken, bevor wir - schon bald - noch viel dunkleren Zeiten entgegentreten...]]
		-- ENDE TRAUERG?STE !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		-- Completion Code
		item_completion_code_name = "Completion Code"
		item_completion_code_description = "Den Completion Code can man bei wherigo.com eingeben. Er ist f?r jeden Spieler eindeutig!"
		item_completion_code_command_view_caption = "Anzeigen"
		-- Credits
		item_credits_name = "Credits"
		item_credits_description = "Wer hat GC57EJE realisiert?"
		item_credits_command_view_caption = "Credits zeigen"
		item_credits_text = ((((((([[Dramatis Personae

]]..[[John Greenwitch
     Tobias Reich
]])..[[Fiona Greenwitch
     Regina Brodmann
]])..[[Mr. Johnson
     Mathias Anders
]])..[[Arzt
     Anastasia Reich
]])..[[Nachrichtensprecher
     Mathias Reich
]])..[[
]])..[[Kamera
     Tobias Reich
]])..[[Programmierung
     Mathias Anders]]
	end, 
	[4] = function()
		zone_meet_greenwitch_name = "Treffen mit Greenwitch"
		zone_09_meet_greenwitch_description = "John Greenwitch m?chte, dass wir uns hier treffen"
		zone_10_shake_off_pursuers_name = "Beobachtetes Gebiet"
		zone_10_shake_off_pursuers_description = "Ich werde beobachtet. Ich muss diesen Bereich so schnell wie m?glich verlassen."
		zone_11_meet_greenwitch_description = "Hier treffe ich mich mit John Greenwitch. Allerdings nur dann, wenn ich meine Verfolger abgesch?ttelt habe."
		zone_13_fionas_whereabouts_name = "M?glicher Aufenthaltsort von Fiona"
		zone_13_fionas_whereabouts_description = "Den Hinweisen nach, ist das einer der Orte, wo Fiona sein k?nnte."
		zone_16_fiona_name = "Fiona"
		zone_16_fiona_description = "Ich darf Fiona nicht zu nahe kommen."
		zone_18_greenwitch_meets_daughter_name = "John Greenwitch und Fiona"
		zone_18_greenwitch_meets_daughter_description = "John Greenwitch unterh?lt sich mit seiner Tochter Fiona. Ich k?nnte beide davor warnen, dass Johnson's Leute gleich kommen, oder einfach abwarten und es geschehen lassen."
		zone_21a_traitors_end_name = "Toter Briefkasten"
		zone_21a_traitors_end_description = "Hier irgendwo befindet sich ein toter Briefkasten, bei dem ich mich als neuer Mitarbeiter f?r die Zeus Incorporated eintragen kann."
		zone_22_secure_name = "Sicherer Bereich"
		zone_22_secure_description = "In diesem Bereich bin ich f?r ein paar Sekunden sicher vor Johnson's H?schern."
		zone_22_helicopter_name = "Zeus Inc. Helikopter"
		zone_22_helicopter_description = "Der Hubschrauber der Zeus Inc. sucht nach mir, wenn er mich ?berfliegt, muss ich seinem Sichtbereich so schnell wie m?glich wieder entkommen."
		zone_22_road_block_name = "Stra?ensperre"
		zone_22_road_block_description = "Mr. Johnson hat dort ein paar Vans zur Beobachtung der Stra?e abgestellt. Ich muss einen anderen Weg finden und darf den Vans auf keinen Fall zu nahe kommen."
		zone_22_agents_name = "Zeus Inc. Agent"
		zone_22_agents_description = "Einer von Mr. Johnsons Agenten. Ich muss an ihm vorbei schleichen. Ich darf ihm nicht zu nahe kommen."
		zone_23_hospital_name = "Krankenhaus"
		zone_23_hospital_description = "Hier wird John Greenwitch's Kontaktperson, ein Arzt, auf mich warten. Ihm muss ich das Gegenmittel geben."
		zone_23c_heroes_end_name = "Toter Briefkasten"
		zone_23c_heroes_end_description = "Hier irgendwo befindet sich ein toter Briefkasten, bei dem ich mich eintragen kann."
		zone_24d_mourners_end_name = "Kondolenzbuch"
		zone_24d_mourners_end_description = "Hier befindet sich das Kondolenzbuch f?r Patient 0. Ich sollte mich einschreiben und mich wenigstens an seinen richtigen Namen erinnern."
	end
}

-- Begin user directives --
_Urwigo.InlineRequire(0)
_Urwigo.InlineRequire(1)
_Urwigo.InlineRequire(2)
_Urwigo.InlineRequire(3)
_Urwigo.InlineRequire(4)

-- End user directives --

prometheus_chapter_2 = Wherigo.ZCartridge()

-- Media --
img_zone_hospital = Wherigo.ZMedia(prometheus_chapter_2)
img_zone_hospital.Id = "769c68bd-8f94-4e05-bb28-611b594cef77"
img_zone_hospital.Name = "img_zone_hospital"
img_zone_hospital.Description = ""
img_zone_hospital.AltText = ""
img_zone_hospital.Resources = {
	{
		Type = "gif", 
		Filename = "hospital.gif", 
		Directives = {}
	}
}
img_footprints = Wherigo.ZMedia(prometheus_chapter_2)
img_footprints.Id = "0b898244-778b-4ddf-a04a-8a6c88d07286"
img_footprints.Name = "img_footprints"
img_footprints.Description = ""
img_footprints.AltText = ""
img_footprints.Resources = {
	{
		Type = "png", 
		Filename = "footprints.png", 
		Directives = {}
	}
}
img_memo = Wherigo.ZMedia(prometheus_chapter_2)
img_memo.Id = "ba4a9c64-efb2-4f8a-a173-3c6caaf943e8"
img_memo.Name = "img_memo"
img_memo.Description = ""
img_memo.AltText = "Memo"
img_memo.Resources = {
	{
		Type = "jpg", 
		Filename = "memo.jpg", 
		Directives = {}
	}
}
icon_memo = Wherigo.ZMedia(prometheus_chapter_2)
icon_memo.Id = "b60a23c0-f038-46db-9132-d77cc7841f87"
icon_memo.Name = "icon_memo"
icon_memo.Description = ""
icon_memo.AltText = "Memo"
icon_memo.Resources = {
	{
		Type = "png", 
		Filename = "icon_memo.png", 
		Directives = {}
	}
}
img_incoming_call = Wherigo.ZMedia(prometheus_chapter_2)
img_incoming_call.Id = "54582c53-64ec-4bdc-bbbc-2a14f96b86a0"
img_incoming_call.Name = "img_incoming_call"
img_incoming_call.Description = ""
img_incoming_call.AltText = ""
img_incoming_call.Resources = {
	{
		Type = "jpg", 
		Filename = "incoming_call.jpg", 
		Directives = {}
	}
}
sound_phone_ring = Wherigo.ZMedia(prometheus_chapter_2)
sound_phone_ring.Id = "694be82e-0d4b-4539-a4c3-3568f6eacd09"
sound_phone_ring.Name = "sound_phone_ring"
sound_phone_ring.Description = ""
sound_phone_ring.AltText = ""
sound_phone_ring.Resources = {
	{
		Type = "wav", 
		Filename = "phone_ring.wav", 
		Directives = {}
	}
}
sound_phone_ring_garmin = Wherigo.ZMedia(prometheus_chapter_2)
sound_phone_ring_garmin.Id = "04818f09-dd7c-429d-aa8d-1eda907398fd"
sound_phone_ring_garmin.Name = "sound_phone_ring_garmin"
sound_phone_ring_garmin.Description = ""
sound_phone_ring_garmin.AltText = ""
sound_phone_ring_garmin.Resources = {
	{
		Type = "fdl", 
		Filename = "phone_ring_garmin.fdl", 
		Directives = {}
	}
}
img_mr_johnson = Wherigo.ZMedia(prometheus_chapter_2)
img_mr_johnson.Id = "d4a77176-778d-4507-bdf4-e173fbc0a798"
img_mr_johnson.Name = "img_mr_johnson"
img_mr_johnson.Description = ""
img_mr_johnson.AltText = "Mr. Johnson"
img_mr_johnson.Resources = {
	{
		Type = "jpg", 
		Filename = "mr_johnson.jpg", 
		Directives = {}
	}
}
audio_02_call_from_johnson_1_1 = Wherigo.ZMedia(prometheus_chapter_2)
audio_02_call_from_johnson_1_1.Id = "f4f2aeb0-3e99-4746-b2d6-0c4bf7972a41"
audio_02_call_from_johnson_1_1.Name = "audio_02_call_from_johnson_1_1"
audio_02_call_from_johnson_1_1.Description = ""
audio_02_call_from_johnson_1_1.AltText = ""
audio_02_call_from_johnson_1_1.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_02_call_from_johnson_1_1.mp3", 
		Directives = {}
	}
}
audio_03_health_office_answering_machine = Wherigo.ZMedia(prometheus_chapter_2)
audio_03_health_office_answering_machine.Id = "d163b204-acff-45c6-b2b2-ace37ddf7a7e"
audio_03_health_office_answering_machine.Name = "audio_03_health_office_answering_machine"
audio_03_health_office_answering_machine.Description = ""
audio_03_health_office_answering_machine.AltText = ""
audio_03_health_office_answering_machine.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_03_health_office_answering_machine.mp3", 
		Directives = {}
	}
}
audio_04_call_from_johnson_1_2 = Wherigo.ZMedia(prometheus_chapter_2)
audio_04_call_from_johnson_1_2.Id = "b49e925f-6bbb-4e49-9f25-900308414ac9"
audio_04_call_from_johnson_1_2.Name = "audio_04_call_from_johnson_1_2"
audio_04_call_from_johnson_1_2.Description = ""
audio_04_call_from_johnson_1_2.AltText = ""
audio_04_call_from_johnson_1_2.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_04_call_from_johnson_1_2.mp3", 
		Directives = {}
	}
}
audio_06a_call_from_johnson_daughter_abducted = Wherigo.ZMedia(prometheus_chapter_2)
audio_06a_call_from_johnson_daughter_abducted.Id = "4555d302-3b59-495d-af4f-4c4a0784b5f3"
audio_06a_call_from_johnson_daughter_abducted.Name = "audio_06a_call_from_johnson_daughter_abducted"
audio_06a_call_from_johnson_daughter_abducted.Description = ""
audio_06a_call_from_johnson_daughter_abducted.AltText = ""
audio_06a_call_from_johnson_daughter_abducted.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_06a_call_from_johnson_daughter_abducted.mp3", 
		Directives = {}
	}
}
audio_14_call_from_johnson_right_zone = Wherigo.ZMedia(prometheus_chapter_2)
audio_14_call_from_johnson_right_zone.Id = "42b507c4-2337-4142-b5a4-c4b56c0b9d6e"
audio_14_call_from_johnson_right_zone.Name = "audio_14_call_from_johnson_right_zone"
audio_14_call_from_johnson_right_zone.Description = ""
audio_14_call_from_johnson_right_zone.AltText = ""
audio_14_call_from_johnson_right_zone.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_14_call_from_johnson_right_zone.mp3", 
		Directives = {}
	}
}
audio_15_call_from_johnson_radio_tag = Wherigo.ZMedia(prometheus_chapter_2)
audio_15_call_from_johnson_radio_tag.Id = "9f66db35-4e2a-44a5-bb31-a84b83064149"
audio_15_call_from_johnson_radio_tag.Name = "audio_15_call_from_johnson_radio_tag"
audio_15_call_from_johnson_radio_tag.Description = ""
audio_15_call_from_johnson_radio_tag.AltText = ""
audio_15_call_from_johnson_radio_tag.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_15_call_from_johnson_radio_tag.mp3", 
		Directives = {}
	}
}
audio_17_call_from_johnson_stay = Wherigo.ZMedia(prometheus_chapter_2)
audio_17_call_from_johnson_stay.Id = "58a8f3f4-f71a-4a9f-8bf4-d275702ebad6"
audio_17_call_from_johnson_stay.Name = "audio_17_call_from_johnson_stay"
audio_17_call_from_johnson_stay.Description = ""
audio_17_call_from_johnson_stay.AltText = ""
audio_17_call_from_johnson_stay.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_17_call_from_johnson_stay.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_01 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_01.Id = "4fc84352-6138-47e2-81bc-bd0ae80f6ce7"
audio_18_greenwitch_meets_daughter_01.Name = "audio_18_greenwitch_meets_daughter_01"
audio_18_greenwitch_meets_daughter_01.Description = ""
audio_18_greenwitch_meets_daughter_01.AltText = ""
audio_18_greenwitch_meets_daughter_01.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_01.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_02 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_02.Id = "9b5110ca-9478-4d63-af0d-86b58f12e0cd"
audio_18_greenwitch_meets_daughter_02.Name = "audio_18_greenwitch_meets_daughter_02"
audio_18_greenwitch_meets_daughter_02.Description = ""
audio_18_greenwitch_meets_daughter_02.AltText = ""
audio_18_greenwitch_meets_daughter_02.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_02.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_03 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_03.Id = "91295494-2953-4646-89f7-7f6838f3b787"
audio_18_greenwitch_meets_daughter_03.Name = "audio_18_greenwitch_meets_daughter_03"
audio_18_greenwitch_meets_daughter_03.Description = ""
audio_18_greenwitch_meets_daughter_03.AltText = ""
audio_18_greenwitch_meets_daughter_03.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_03.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_04 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_04.Id = "5e21e748-517a-41d7-bd7d-3acfbda8814d"
audio_18_greenwitch_meets_daughter_04.Name = "audio_18_greenwitch_meets_daughter_04"
audio_18_greenwitch_meets_daughter_04.Description = ""
audio_18_greenwitch_meets_daughter_04.AltText = ""
audio_18_greenwitch_meets_daughter_04.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_04.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_05 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_05.Id = "672e5a42-aa22-4a8b-b86d-5570c73c81da"
audio_18_greenwitch_meets_daughter_05.Name = "audio_18_greenwitch_meets_daughter_05"
audio_18_greenwitch_meets_daughter_05.Description = ""
audio_18_greenwitch_meets_daughter_05.AltText = ""
audio_18_greenwitch_meets_daughter_05.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_05.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_06 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_06.Id = "090775d5-9df0-416c-b254-c11edb045b9f"
audio_18_greenwitch_meets_daughter_06.Name = "audio_18_greenwitch_meets_daughter_06"
audio_18_greenwitch_meets_daughter_06.Description = ""
audio_18_greenwitch_meets_daughter_06.AltText = ""
audio_18_greenwitch_meets_daughter_06.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_06.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_07 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_07.Id = "e5846b30-7063-42b8-8b49-88ba25adea4a"
audio_18_greenwitch_meets_daughter_07.Name = "audio_18_greenwitch_meets_daughter_07"
audio_18_greenwitch_meets_daughter_07.Description = ""
audio_18_greenwitch_meets_daughter_07.AltText = ""
audio_18_greenwitch_meets_daughter_07.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_07.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_08 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_08.Id = "d5091870-291c-4bda-a4d1-d564a0d24d00"
audio_18_greenwitch_meets_daughter_08.Name = "audio_18_greenwitch_meets_daughter_08"
audio_18_greenwitch_meets_daughter_08.Description = ""
audio_18_greenwitch_meets_daughter_08.AltText = ""
audio_18_greenwitch_meets_daughter_08.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_08.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_09 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_09.Id = "0be21277-6485-4892-afe6-5ae0272cffea"
audio_18_greenwitch_meets_daughter_09.Name = "audio_18_greenwitch_meets_daughter_09"
audio_18_greenwitch_meets_daughter_09.Description = ""
audio_18_greenwitch_meets_daughter_09.AltText = ""
audio_18_greenwitch_meets_daughter_09.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_09.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_10 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_10.Id = "d6d90b31-3042-427e-a981-350506584003"
audio_18_greenwitch_meets_daughter_10.Name = "audio_18_greenwitch_meets_daughter_10"
audio_18_greenwitch_meets_daughter_10.Description = ""
audio_18_greenwitch_meets_daughter_10.AltText = ""
audio_18_greenwitch_meets_daughter_10.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_10.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_11 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_11.Id = "1afa7b33-ad2d-4457-8352-a75c9f2758f5"
audio_18_greenwitch_meets_daughter_11.Name = "audio_18_greenwitch_meets_daughter_11"
audio_18_greenwitch_meets_daughter_11.Description = ""
audio_18_greenwitch_meets_daughter_11.AltText = ""
audio_18_greenwitch_meets_daughter_11.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_11.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_12 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_12.Id = "6d1197e4-2e37-459a-aa29-46a0850b0cb8"
audio_18_greenwitch_meets_daughter_12.Name = "audio_18_greenwitch_meets_daughter_12"
audio_18_greenwitch_meets_daughter_12.Description = ""
audio_18_greenwitch_meets_daughter_12.AltText = ""
audio_18_greenwitch_meets_daughter_12.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_12.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_13 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_13.Id = "cc226040-f1c7-479c-a981-5f4dd7257e6b"
audio_18_greenwitch_meets_daughter_13.Name = "audio_18_greenwitch_meets_daughter_13"
audio_18_greenwitch_meets_daughter_13.Description = ""
audio_18_greenwitch_meets_daughter_13.AltText = ""
audio_18_greenwitch_meets_daughter_13.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_13.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_14 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_14.Id = "ec4a8a52-d3c2-47e0-a8b3-02e04bc89991"
audio_18_greenwitch_meets_daughter_14.Name = "audio_18_greenwitch_meets_daughter_14"
audio_18_greenwitch_meets_daughter_14.Description = ""
audio_18_greenwitch_meets_daughter_14.AltText = ""
audio_18_greenwitch_meets_daughter_14.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_14.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_15 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_15.Id = "fdc02825-e735-4ae6-98be-7bc6d60f1f2d"
audio_18_greenwitch_meets_daughter_15.Name = "audio_18_greenwitch_meets_daughter_15"
audio_18_greenwitch_meets_daughter_15.Description = ""
audio_18_greenwitch_meets_daughter_15.AltText = ""
audio_18_greenwitch_meets_daughter_15.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_15.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_16 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_16.Id = "80ee185d-de64-4e09-abd4-eef1a8b2d10d"
audio_18_greenwitch_meets_daughter_16.Name = "audio_18_greenwitch_meets_daughter_16"
audio_18_greenwitch_meets_daughter_16.Description = ""
audio_18_greenwitch_meets_daughter_16.AltText = ""
audio_18_greenwitch_meets_daughter_16.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_16.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_17 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_17.Id = "9b346ac5-80db-4fb3-aa8b-9171ff02ead8"
audio_18_greenwitch_meets_daughter_17.Name = "audio_18_greenwitch_meets_daughter_17"
audio_18_greenwitch_meets_daughter_17.Description = ""
audio_18_greenwitch_meets_daughter_17.AltText = ""
audio_18_greenwitch_meets_daughter_17.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_17.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_18 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_18.Id = "0bfdc0a3-c7fe-4edf-a2ae-be43b83792d7"
audio_18_greenwitch_meets_daughter_18.Name = "audio_18_greenwitch_meets_daughter_18"
audio_18_greenwitch_meets_daughter_18.Description = ""
audio_18_greenwitch_meets_daughter_18.AltText = ""
audio_18_greenwitch_meets_daughter_18.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_18.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_19 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_19.Id = "d1d2e91d-5971-4bd8-a9ec-135068c7ed4b"
audio_18_greenwitch_meets_daughter_19.Name = "audio_18_greenwitch_meets_daughter_19"
audio_18_greenwitch_meets_daughter_19.Description = ""
audio_18_greenwitch_meets_daughter_19.AltText = ""
audio_18_greenwitch_meets_daughter_19.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_19.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_20 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_20.Id = "eaf7dd2c-6920-4e4d-a560-640c03b02480"
audio_18_greenwitch_meets_daughter_20.Name = "audio_18_greenwitch_meets_daughter_20"
audio_18_greenwitch_meets_daughter_20.Description = ""
audio_18_greenwitch_meets_daughter_20.AltText = ""
audio_18_greenwitch_meets_daughter_20.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_20.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_21 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_21.Id = "dac74b70-c753-4360-96ed-31383803c299"
audio_18_greenwitch_meets_daughter_21.Name = "audio_18_greenwitch_meets_daughter_21"
audio_18_greenwitch_meets_daughter_21.Description = ""
audio_18_greenwitch_meets_daughter_21.AltText = ""
audio_18_greenwitch_meets_daughter_21.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_21.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_22 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_22.Id = "83986792-1757-43db-a717-a2cab9d74939"
audio_18_greenwitch_meets_daughter_22.Name = "audio_18_greenwitch_meets_daughter_22"
audio_18_greenwitch_meets_daughter_22.Description = ""
audio_18_greenwitch_meets_daughter_22.AltText = ""
audio_18_greenwitch_meets_daughter_22.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_22.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_23 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_23.Id = "ccda529a-be23-46b7-9659-cab5aeef9f67"
audio_18_greenwitch_meets_daughter_23.Name = "audio_18_greenwitch_meets_daughter_23"
audio_18_greenwitch_meets_daughter_23.Description = ""
audio_18_greenwitch_meets_daughter_23.AltText = ""
audio_18_greenwitch_meets_daughter_23.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_23.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_24 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_24.Id = "928678f0-8754-489f-a695-9aa593db24d5"
audio_18_greenwitch_meets_daughter_24.Name = "audio_18_greenwitch_meets_daughter_24"
audio_18_greenwitch_meets_daughter_24.Description = ""
audio_18_greenwitch_meets_daughter_24.AltText = ""
audio_18_greenwitch_meets_daughter_24.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_24.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_25 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_25.Id = "04c38291-009f-4a32-abe4-df6c485137ab"
audio_18_greenwitch_meets_daughter_25.Name = "audio_18_greenwitch_meets_daughter_25"
audio_18_greenwitch_meets_daughter_25.Description = ""
audio_18_greenwitch_meets_daughter_25.AltText = ""
audio_18_greenwitch_meets_daughter_25.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_25.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_26 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_26.Id = "f62a298c-aa97-4309-9fa7-37f68753831f"
audio_18_greenwitch_meets_daughter_26.Name = "audio_18_greenwitch_meets_daughter_26"
audio_18_greenwitch_meets_daughter_26.Description = ""
audio_18_greenwitch_meets_daughter_26.AltText = ""
audio_18_greenwitch_meets_daughter_26.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_26.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_27 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_27.Id = "27e3b9cc-927a-4737-a810-7250957e6fb5"
audio_18_greenwitch_meets_daughter_27.Name = "audio_18_greenwitch_meets_daughter_27"
audio_18_greenwitch_meets_daughter_27.Description = ""
audio_18_greenwitch_meets_daughter_27.AltText = ""
audio_18_greenwitch_meets_daughter_27.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_27.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_28 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_28.Id = "d5b4dc75-6be2-4270-9b58-6f0efbbd2ea1"
audio_18_greenwitch_meets_daughter_28.Name = "audio_18_greenwitch_meets_daughter_28"
audio_18_greenwitch_meets_daughter_28.Description = ""
audio_18_greenwitch_meets_daughter_28.AltText = ""
audio_18_greenwitch_meets_daughter_28.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_28.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_29 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_29.Id = "467fec6d-4ded-43cf-b453-8ba7e24e7f06"
audio_18_greenwitch_meets_daughter_29.Name = "audio_18_greenwitch_meets_daughter_29"
audio_18_greenwitch_meets_daughter_29.Description = ""
audio_18_greenwitch_meets_daughter_29.AltText = ""
audio_18_greenwitch_meets_daughter_29.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_29.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_30 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_30.Id = "e9c2e05d-3c80-40aa-b9a2-a5fac3632035"
audio_18_greenwitch_meets_daughter_30.Name = "audio_18_greenwitch_meets_daughter_30"
audio_18_greenwitch_meets_daughter_30.Description = ""
audio_18_greenwitch_meets_daughter_30.AltText = ""
audio_18_greenwitch_meets_daughter_30.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_30.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_31 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_31.Id = "bd223fa9-24c1-4aef-9ad8-19dabd08807d"
audio_18_greenwitch_meets_daughter_31.Name = "audio_18_greenwitch_meets_daughter_31"
audio_18_greenwitch_meets_daughter_31.Description = ""
audio_18_greenwitch_meets_daughter_31.AltText = ""
audio_18_greenwitch_meets_daughter_31.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_31.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_32 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_32.Id = "68fa333d-1751-43ae-b801-e84d89029ede"
audio_18_greenwitch_meets_daughter_32.Name = "audio_18_greenwitch_meets_daughter_32"
audio_18_greenwitch_meets_daughter_32.Description = ""
audio_18_greenwitch_meets_daughter_32.AltText = ""
audio_18_greenwitch_meets_daughter_32.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_32.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_33 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_33.Id = "49dc218f-997a-4126-9c5d-1472f6abcc4b"
audio_18_greenwitch_meets_daughter_33.Name = "audio_18_greenwitch_meets_daughter_33"
audio_18_greenwitch_meets_daughter_33.Description = ""
audio_18_greenwitch_meets_daughter_33.AltText = ""
audio_18_greenwitch_meets_daughter_33.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_33.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_34 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_34.Id = "c334285a-d9ef-4cce-a9b1-8d9119350789"
audio_18_greenwitch_meets_daughter_34.Name = "audio_18_greenwitch_meets_daughter_34"
audio_18_greenwitch_meets_daughter_34.Description = ""
audio_18_greenwitch_meets_daughter_34.AltText = ""
audio_18_greenwitch_meets_daughter_34.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_34.mp3", 
		Directives = {}
	}
}
audio_18_greenwitch_meets_daughter_35 = Wherigo.ZMedia(prometheus_chapter_2)
audio_18_greenwitch_meets_daughter_35.Id = "26054a30-f78b-48b9-8b40-dfb3235974b5"
audio_18_greenwitch_meets_daughter_35.Name = "audio_18_greenwitch_meets_daughter_35"
audio_18_greenwitch_meets_daughter_35.Description = ""
audio_18_greenwitch_meets_daughter_35.AltText = ""
audio_18_greenwitch_meets_daughter_35.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_18_greenwitch_meets_daughter_35.mp3", 
		Directives = {}
	}
}
audio_21a_call_from_johnson_gratitude_traitors_end = Wherigo.ZMedia(prometheus_chapter_2)
audio_21a_call_from_johnson_gratitude_traitors_end.Id = "b1d23f3f-4332-4af3-8e68-9abf54faae76"
audio_21a_call_from_johnson_gratitude_traitors_end.Name = "audio_21a_call_from_johnson_gratitude_traitors_end"
audio_21a_call_from_johnson_gratitude_traitors_end.Description = ""
audio_21a_call_from_johnson_gratitude_traitors_end.AltText = ""
audio_21a_call_from_johnson_gratitude_traitors_end.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_21a_call_from_johnson_gratitude_traitors_end.mp3", 
		Directives = {}
	}
}
audio_21b_call_from_johnson_threat = Wherigo.ZMedia(prometheus_chapter_2)
audio_21b_call_from_johnson_threat.Id = "9dfc8931-f2a5-408d-bc1f-06331c6e19cb"
audio_21b_call_from_johnson_threat.Name = "audio_21b_call_from_johnson_threat"
audio_21b_call_from_johnson_threat.Description = ""
audio_21b_call_from_johnson_threat.AltText = ""
audio_21b_call_from_johnson_threat.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_21b_call_from_johnson_threat.mp3", 
		Directives = {}
	}
}
img_john_greenwitch = Wherigo.ZMedia(prometheus_chapter_2)
img_john_greenwitch.Id = "f0ffb829-00c4-4026-b7a3-05c199f1e6ca"
img_john_greenwitch.Name = "img_john_greenwitch"
img_john_greenwitch.Description = ""
img_john_greenwitch.AltText = "John Greenwitch"
img_john_greenwitch.Resources = {
	{
		Type = "jpg", 
		Filename = "john_greenwitch.jpg", 
		Directives = {}
	}
}
img_telephone = Wherigo.ZMedia(prometheus_chapter_2)
img_telephone.Id = "2718c424-43df-4eb1-b534-07f211b5191c"
img_telephone.Name = "img_telephone"
img_telephone.Description = ""
img_telephone.AltText = ""
img_telephone.Resources = {
	{
		Type = "jpg", 
		Filename = "telephone.jpg", 
		Directives = {}
	}
}
icon_telephone = Wherigo.ZMedia(prometheus_chapter_2)
icon_telephone.Id = "1943fa9b-dbc1-4a3d-b51d-a74cb7777c16"
icon_telephone.Name = "icon_telephone"
icon_telephone.Description = ""
icon_telephone.AltText = ""
icon_telephone.Resources = {
	{
		Type = "jpg", 
		Filename = "icon_telephone.jpg", 
		Directives = {}
	}
}
audio_10_call_from_greenwitch_followed = Wherigo.ZMedia(prometheus_chapter_2)
audio_10_call_from_greenwitch_followed.Id = "752d4c43-5120-426b-9400-cac765ac4d34"
audio_10_call_from_greenwitch_followed.Name = "audio_10_call_from_greenwitch_followed"
audio_10_call_from_greenwitch_followed.Description = ""
audio_10_call_from_greenwitch_followed.AltText = ""
audio_10_call_from_greenwitch_followed.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_10_call_from_greenwitch_followed.mp3", 
		Directives = {}
	}
}
audio_11_call_from_greenwitch_abduction = Wherigo.ZMedia(prometheus_chapter_2)
audio_11_call_from_greenwitch_abduction.Id = "5d1a54c4-0de8-4e36-88d8-e6cf54efa06e"
audio_11_call_from_greenwitch_abduction.Name = "audio_11_call_from_greenwitch_abduction"
audio_11_call_from_greenwitch_abduction.Description = ""
audio_11_call_from_greenwitch_abduction.AltText = ""
audio_11_call_from_greenwitch_abduction.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_11_call_from_greenwitch_abduction.mp3", 
		Directives = {}
	}
}
audio_11_call_from_greenwitch_abduction_known = Wherigo.ZMedia(prometheus_chapter_2)
audio_11_call_from_greenwitch_abduction_known.Id = "660cee5a-5eb4-4630-81ea-1c2701373958"
audio_11_call_from_greenwitch_abduction_known.Name = "audio_11_call_from_greenwitch_abduction_known"
audio_11_call_from_greenwitch_abduction_known.Description = ""
audio_11_call_from_greenwitch_abduction_known.AltText = ""
audio_11_call_from_greenwitch_abduction_known.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_11_call_from_greenwitch_abduction_known.mp3", 
		Directives = {}
	}
}
img_zeus = Wherigo.ZMedia(prometheus_chapter_2)
img_zeus.Id = "bb19857a-7777-45a5-8662-a63eefa632f3"
img_zeus.Name = "img_zeus"
img_zeus.Description = ""
img_zeus.AltText = ""
img_zeus.Resources = {
	{
		Type = "jpg", 
		Filename = "zeus.jpg", 
		Directives = {}
	}
}
img_antidote = Wherigo.ZMedia(prometheus_chapter_2)
img_antidote.Id = "9b438c99-eaf5-4e95-85a3-a2e8eb688823"
img_antidote.Name = "img_antidote"
img_antidote.Description = ""
img_antidote.AltText = ""
img_antidote.Resources = {
	{
		Type = "jpg", 
		Filename = "antidote.jpg", 
		Directives = {}
	}
}
img_fiona_greenwitch = Wherigo.ZMedia(prometheus_chapter_2)
img_fiona_greenwitch.Id = "3a50d452-e5e6-4988-ab55-69aa7e474a83"
img_fiona_greenwitch.Name = "img_fiona_greenwitch"
img_fiona_greenwitch.Description = ""
img_fiona_greenwitch.AltText = "Fiona Greenwitch"
img_fiona_greenwitch.Resources = {
	{
		Type = "jpg", 
		Filename = "fiona_greenwitch.jpg", 
		Directives = {}
	}
}
img_prometheus_chapter_1 = Wherigo.ZMedia(prometheus_chapter_2)
img_prometheus_chapter_1.Id = "0903cac1-ebdc-4aa7-a30a-f27fb88114f1"
img_prometheus_chapter_1.Name = "img_prometheus_chapter_1"
img_prometheus_chapter_1.Description = ""
img_prometheus_chapter_1.AltText = ""
img_prometheus_chapter_1.Resources = {
	{
		Type = "png", 
		Filename = "prometheus_chapter_1_120x150.png", 
		Directives = {}
	}
}
img_20b_minigame_rules = Wherigo.ZMedia(prometheus_chapter_2)
img_20b_minigame_rules.Id = "dd744a4a-24bc-4bd7-9c99-e69138675222"
img_20b_minigame_rules.Name = "img_20b_minigame_rules"
img_20b_minigame_rules.Description = ""
img_20b_minigame_rules.AltText = ""
img_20b_minigame_rules.Resources = {
	{
		Type = "png", 
		Filename = "20b_minigame_rules.png", 
		Directives = {}
	}
}
img_van = Wherigo.ZMedia(prometheus_chapter_2)
img_van.Id = "9fb53341-b186-4e90-b9c6-9837145aea82"
img_van.Name = "img_van"
img_van.Description = ""
img_van.AltText = ""
img_van.Resources = {
	{
		Type = "jpg", 
		Filename = "van.jpg", 
		Directives = {}
	}
}
sound_lost_antidote_to_johnson = Wherigo.ZMedia(prometheus_chapter_2)
sound_lost_antidote_to_johnson.Id = "d1859d0a-39ce-4a2f-aa67-0bf7d7108d08"
sound_lost_antidote_to_johnson.Name = "sound_lost_antidote_to_johnson"
sound_lost_antidote_to_johnson.Description = ""
sound_lost_antidote_to_johnson.AltText = ""
sound_lost_antidote_to_johnson.Resources = {
	{
		Type = "mp3", 
		Filename = "lost_antidote_to_johnson.mp3", 
		Directives = {}
	}
}
sound_helicopter = Wherigo.ZMedia(prometheus_chapter_2)
sound_helicopter.Id = "b1591fe4-e46d-43c4-bede-047b459c17b3"
sound_helicopter.Name = "sound_helicopter"
sound_helicopter.Description = ""
sound_helicopter.AltText = ""
sound_helicopter.Resources = {
	{
		Type = "mp3", 
		Filename = "helicopter.mp3", 
		Directives = {}
	}
}
audio_23c_reaching_hospital_heroes_end = Wherigo.ZMedia(prometheus_chapter_2)
audio_23c_reaching_hospital_heroes_end.Id = "1bfe9c43-349d-4372-863d-83413e76da1b"
audio_23c_reaching_hospital_heroes_end.Name = "audio_23c_reaching_hospital_heroes_end"
audio_23c_reaching_hospital_heroes_end.Description = ""
audio_23c_reaching_hospital_heroes_end.AltText = ""
audio_23c_reaching_hospital_heroes_end.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_23c_reaching_hospital_heroes_end.mp3", 
		Directives = {}
	}
}
audio_24d_reaching_hospital_mourners_end = Wherigo.ZMedia(prometheus_chapter_2)
audio_24d_reaching_hospital_mourners_end.Id = "396ec8ce-93a0-47fb-bd0f-224246e8fbdd"
audio_24d_reaching_hospital_mourners_end.Name = "audio_24d_reaching_hospital_mourners_end"
audio_24d_reaching_hospital_mourners_end.Description = ""
audio_24d_reaching_hospital_mourners_end.AltText = ""
audio_24d_reaching_hospital_mourners_end.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_24d_reaching_hospital_mourners_end.mp3", 
		Directives = {}
	}
}
img_16_track_fiona = Wherigo.ZMedia(prometheus_chapter_2)
img_16_track_fiona.Id = "e37286c2-86fd-4466-a9b4-d3cc336bdd6c"
img_16_track_fiona.Name = "img_16_track_fiona"
img_16_track_fiona.Description = ""
img_16_track_fiona.AltText = ""
img_16_track_fiona.Resources = {
	{
		Type = "jpg", 
		Filename = "16_track_fiona.jpg", 
		Directives = {}
	}
}
img_18_greenwitch_meets_daughter_far = Wherigo.ZMedia(prometheus_chapter_2)
img_18_greenwitch_meets_daughter_far.Id = "0c52048f-b4c0-40cb-a275-b1fc4e2501a4"
img_18_greenwitch_meets_daughter_far.Name = "img_18_greenwitch_meets_daughter_far"
img_18_greenwitch_meets_daughter_far.Description = ""
img_18_greenwitch_meets_daughter_far.AltText = ""
img_18_greenwitch_meets_daughter_far.Resources = {
	{
		Type = "jpg", 
		Filename = "18_greenwitch_meets_daughter_far.jpg", 
		Directives = {}
	}
}
img_18_greenwitch_meets_daughter_near = Wherigo.ZMedia(prometheus_chapter_2)
img_18_greenwitch_meets_daughter_near.Id = "7e711166-8e92-4157-ae0a-aeeabc4182ee"
img_18_greenwitch_meets_daughter_near.Name = "img_18_greenwitch_meets_daughter_near"
img_18_greenwitch_meets_daughter_near.Description = ""
img_18_greenwitch_meets_daughter_near.AltText = ""
img_18_greenwitch_meets_daughter_near.Resources = {
	{
		Type = "jpg", 
		Filename = "18_greenwitch_meets_daughter_near.jpg", 
		Directives = {}
	}
}
audio_12_call_from_johnson_abducted_daughter = Wherigo.ZMedia(prometheus_chapter_2)
audio_12_call_from_johnson_abducted_daughter.Id = "896e8b8e-f327-48c9-a61f-0cada9d399f7"
audio_12_call_from_johnson_abducted_daughter.Name = "audio_12_call_from_johnson_abducted_daughter"
audio_12_call_from_johnson_abducted_daughter.Description = ""
audio_12_call_from_johnson_abducted_daughter.AltText = ""
audio_12_call_from_johnson_abducted_daughter.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_12_call_from_johnson_abducted_daughter.mp3", 
		Directives = {}
	}
}
audio_08_call_to_greenwitch = Wherigo.ZMedia(prometheus_chapter_2)
audio_08_call_to_greenwitch.Id = "2e232a2f-34a5-4a8b-8c40-7cce79a39823"
audio_08_call_to_greenwitch.Name = "audio_08_call_to_greenwitch"
audio_08_call_to_greenwitch.Description = ""
audio_08_call_to_greenwitch.AltText = ""
audio_08_call_to_greenwitch.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_08_call_to_greenwitch.mp3", 
		Directives = {}
	}
}
audio_08_call_to_greenwitch_a_honest = Wherigo.ZMedia(prometheus_chapter_2)
audio_08_call_to_greenwitch_a_honest.Id = "c8ad0f08-7108-444c-a5b6-e7a59c626cf4"
audio_08_call_to_greenwitch_a_honest.Name = "audio_08_call_to_greenwitch_a_honest"
audio_08_call_to_greenwitch_a_honest.Description = ""
audio_08_call_to_greenwitch_a_honest.AltText = ""
audio_08_call_to_greenwitch_a_honest.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_08_call_to_greenwitch_a_honest.mp3", 
		Directives = {}
	}
}
audio_08_call_to_greenwitch_b_hide = Wherigo.ZMedia(prometheus_chapter_2)
audio_08_call_to_greenwitch_b_hide.Id = "45835dde-35a7-4286-b7c1-018543c6bea1"
audio_08_call_to_greenwitch_b_hide.Name = "audio_08_call_to_greenwitch_b_hide"
audio_08_call_to_greenwitch_b_hide.Description = ""
audio_08_call_to_greenwitch_b_hide.AltText = ""
audio_08_call_to_greenwitch_b_hide.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_08_call_to_greenwitch_b_hide.mp3", 
		Directives = {}
	}
}
audio_08_call_to_greenwitch_c_a06 = Wherigo.ZMedia(prometheus_chapter_2)
audio_08_call_to_greenwitch_c_a06.Id = "f4cad991-5073-458e-aa81-c0316f310915"
audio_08_call_to_greenwitch_c_a06.Name = "audio_08_call_to_greenwitch_c_a06"
audio_08_call_to_greenwitch_c_a06.Description = ""
audio_08_call_to_greenwitch_c_a06.AltText = ""
audio_08_call_to_greenwitch_c_a06.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_08_call_to_greenwitch_c_a06.mp3", 
		Directives = {}
	}
}
audio_08_call_to_greenwitch_end = Wherigo.ZMedia(prometheus_chapter_2)
audio_08_call_to_greenwitch_end.Id = "3eee9edb-21b4-4ecf-b593-26c9519a4308"
audio_08_call_to_greenwitch_end.Name = "audio_08_call_to_greenwitch_end"
audio_08_call_to_greenwitch_end.Description = ""
audio_08_call_to_greenwitch_end.AltText = ""
audio_08_call_to_greenwitch_end.Resources = {
	{
		Type = "mp3", 
		Filename = "audio_08_call_to_greenwitch_end.mp3", 
		Directives = {}
	}
}
icon_title = Wherigo.ZMedia(prometheus_chapter_2)
icon_title.Id = "02e21d59-be64-46f0-b919-6f524e2c9755"
icon_title.Name = "icon_title"
icon_title.Description = ""
icon_title.AltText = ""
icon_title.Resources = {
	{
		Type = "jpg", 
		Filename = "icon_title.jpg", 
		Directives = {}
	}
}
img_title = Wherigo.ZMedia(prometheus_chapter_2)
img_title.Id = "1707d837-6e2d-4912-88f3-24b6c3db0a94"
img_title.Name = "img_title"
img_title.Description = ""
img_title.AltText = ""
img_title.Resources = {
	{
		Type = "jpg", 
		Filename = "title.jpg", 
		Directives = {}
	}
}
sound_helicopter_leaving = Wherigo.ZMedia(prometheus_chapter_2)
sound_helicopter_leaving.Id = "ef2af413-1644-4bad-9efa-d7335ca21087"
sound_helicopter_leaving.Name = "sound_helicopter_leaving"
sound_helicopter_leaving.Description = ""
sound_helicopter_leaving.AltText = ""
sound_helicopter_leaving.Resources = {
	{
		Type = "mp3", 
		Filename = "helicopter_leaving.mp3", 
		Directives = {}
	}
}
-- Cartridge Info --
prometheus_chapter_2.Id="0281284e-7677-410b-843b-48b4a2e16f92"
prometheus_chapter_2.Name="Prometheus DE - Chapter 2: Konsequenzen"
prometheus_chapter_2.Description=[[Nachdem du dich in "Kapitel 1: Projekt Pandora" (http://coord.info/gc4ctgm) gegen Mr. Johnson entschieden hast, muss die Welt und auch du nun die Konsequenzen dafur tragen, dass das Gegenmittel nicht in Masse produziert wurde. Mr. Johnson gibt dir aber noch einmal eine Chance.]]
prometheus_chapter_2.Visible=true
prometheus_chapter_2.Activity="Fiction"
prometheus_chapter_2.StartingLocationDescription=[[]]
prometheus_chapter_2.StartingLocation = ZonePoint(52.50991,13.46219,0)
prometheus_chapter_2.Version="0.1"
prometheus_chapter_2.Company=""
prometheus_chapter_2.Author="David Greenwitch and Mahanako"
prometheus_chapter_2.BuilderVersion="URWIGO 1.20.5218.24064"
prometheus_chapter_2.CreateDate="09/12/2013 19:14:05"
prometheus_chapter_2.PublishDate="1/1/0001 12:00:00 AM"
prometheus_chapter_2.UpdateDate="08/02/2014 14:37:17"
prometheus_chapter_2.LastPlayedDate="1/1/0001 12:00:00 AM"
prometheus_chapter_2.TargetDevice="PocketPC"
prometheus_chapter_2.TargetDeviceVersion="0"
prometheus_chapter_2.StateId="1"
prometheus_chapter_2.CountryId="2"
prometheus_chapter_2.Complete=false
prometheus_chapter_2.UseLogging=true

prometheus_chapter_2.Media=img_title

prometheus_chapter_2.Icon=icon_title


-- Zones --
zone_09_meet_greenwitch = Wherigo.Zone(prometheus_chapter_2)
zone_09_meet_greenwitch.Id = "f09a0407-442d-4e67-afdd-9dfbbbba5ea3"
zone_09_meet_greenwitch.Name = "zone_09_meet_greenwitch"
zone_09_meet_greenwitch.Description = ""
zone_09_meet_greenwitch.Visible = false
zone_09_meet_greenwitch.Commands = {}
zone_09_meet_greenwitch.DistanceRange = Distance(-1, "feet")
zone_09_meet_greenwitch.ShowObjects = "OnEnter"
zone_09_meet_greenwitch.ProximityRange = Distance(60, "meters")
zone_09_meet_greenwitch.AllowSetPositionTo = false
zone_09_meet_greenwitch.Active = false
zone_09_meet_greenwitch.Points = {
	ZonePoint(52.5101257209479, 13.4644505381584, 0), 
	ZonePoint(52.5106317773181, 13.4649252891541, 0), 
	ZonePoint(52.5110366182187, 13.4640562534332, 0), 
	ZonePoint(52.5109092896278, 13.4639006853104, 0), 
	ZonePoint(52.510840727926, 13.4637558460236, 0)
}
zone_09_meet_greenwitch.OriginalPoint = ZonePoint(52.5107088268077, 13.4642177224159, 0)
zone_09_meet_greenwitch.DistanceRangeUOM = "Feet"
zone_09_meet_greenwitch.ProximityRangeUOM = "Meters"
zone_09_meet_greenwitch.OutOfRangeName = ""
zone_09_meet_greenwitch.InRangeName = ""
zone_11_meet_greenwitch = Wherigo.Zone(prometheus_chapter_2)
zone_11_meet_greenwitch.Id = "e252919a-8b0a-4656-93bf-e01b91bbc6e9"
zone_11_meet_greenwitch.Name = "zone_11_meet_greenwitch"
zone_11_meet_greenwitch.Description = ""
zone_11_meet_greenwitch.Visible = false
zone_11_meet_greenwitch.Commands = {}
zone_11_meet_greenwitch.DistanceRange = Distance(-1, "feet")
zone_11_meet_greenwitch.ShowObjects = "OnEnter"
zone_11_meet_greenwitch.ProximityRange = Distance(60, "meters")
zone_11_meet_greenwitch.AllowSetPositionTo = false
zone_11_meet_greenwitch.Active = false
zone_11_meet_greenwitch.Points = {
	ZonePoint(52.51179894963, 13.4750372171402, 0), 
	ZonePoint(52.5117254921468, 13.4750828146935, 0), 
	ZonePoint(52.5116961091192, 13.4751579165459, 0), 
	ZonePoint(52.5117418160426, 13.4752115607262, 0), 
	ZonePoint(52.5117956848556, 13.4752061963081, 0), 
	ZonePoint(52.5118364945184, 13.4751471877098, 0), 
	ZonePoint(52.5118528183729, 13.4750479459763, 0)
}
zone_11_meet_greenwitch.OriginalPoint = ZonePoint(52.5117781949551, 13.4751272627286, 0)
zone_11_meet_greenwitch.DistanceRangeUOM = "Feet"
zone_11_meet_greenwitch.ProximityRangeUOM = "Meters"
zone_11_meet_greenwitch.OutOfRangeName = ""
zone_11_meet_greenwitch.InRangeName = ""
zone_23_hospital = Wherigo.Zone(prometheus_chapter_2)
zone_23_hospital.Id = "7231aa1a-ca0e-43d4-8821-ea6119a696f5"
zone_23_hospital.Name = "zone_23_hospital"
zone_23_hospital.Description = ""
zone_23_hospital.Visible = false
zone_23_hospital.Media = img_zone_hospital
zone_23_hospital.Icon = img_zone_hospital
zone_23_hospital.Commands = {}
zone_23_hospital.DistanceRange = Distance(-1, "feet")
zone_23_hospital.ShowObjects = "OnEnter"
zone_23_hospital.ProximityRange = Distance(60, "meters")
zone_23_hospital.AllowSetPositionTo = false
zone_23_hospital.Active = false
zone_23_hospital.Points = {
	ZonePoint(52.5142621528044, 13.4943652153015, 0), 
	ZonePoint(52.5142474621411, 13.4945073723793, 0), 
	ZonePoint(52.5141462596603, 13.4944939613342, 0), 
	ZonePoint(52.5141119813478, 13.4947675466537, 0), 
	ZonePoint(52.5142066547172, 13.4947943687439, 0), 
	ZonePoint(52.5141968609298, 13.4949150681496, 0), 
	ZonePoint(52.5142850049376, 13.4949338436127, 0), 
	ZonePoint(52.5143421352186, 13.4943893551826, 0)
}
zone_23_hospital.OriginalPoint = ZonePoint(52.5142248139696, 13.4946458414197, 0)
zone_23_hospital.DistanceRangeUOM = "Feet"
zone_23_hospital.ProximityRangeUOM = "Meters"
zone_23_hospital.OutOfRangeName = ""
zone_23_hospital.InRangeName = ""
zone_10_shake_off_pursuers = Wherigo.Zone(prometheus_chapter_2)
zone_10_shake_off_pursuers.Id = "caafdb8b-0bd6-4854-93f0-207e9c0732f8"
zone_10_shake_off_pursuers.Name = "zone_10_shake_off_pursuers"
zone_10_shake_off_pursuers.Description = ""
zone_10_shake_off_pursuers.Visible = false
zone_10_shake_off_pursuers.Commands = {}
zone_10_shake_off_pursuers.DistanceRange = Distance(-1, "feet")
zone_10_shake_off_pursuers.ShowObjects = "OnEnter"
zone_10_shake_off_pursuers.ProximityRange = Distance(60, "meters")
zone_10_shake_off_pursuers.AllowSetPositionTo = false
zone_10_shake_off_pursuers.Active = false
zone_10_shake_off_pursuers.Points = {
	ZonePoint(52.5107950200654, 13.4651345014572, 0), 
	ZonePoint(52.5106742204907, 13.4650701284409, 0), 
	ZonePoint(52.5107166636223, 13.4649762511253, 0)
}
zone_10_shake_off_pursuers.OriginalPoint = ZonePoint(52.5107286347261, 13.4650602936745, 0)
zone_10_shake_off_pursuers.DistanceRangeUOM = "Feet"
zone_10_shake_off_pursuers.ProximityRangeUOM = "Meters"
zone_10_shake_off_pursuers.OutOfRangeName = ""
zone_10_shake_off_pursuers.InRangeName = ""
zone_13_fionas_whereabouts_right = Wherigo.Zone(prometheus_chapter_2)
zone_13_fionas_whereabouts_right.Id = "14bb7e55-a131-4f27-9aaa-3608de269142"
zone_13_fionas_whereabouts_right.Name = "zone_13_fionas_whereabouts_right"
zone_13_fionas_whereabouts_right.Description = ""
zone_13_fionas_whereabouts_right.Visible = false
zone_13_fionas_whereabouts_right.Media = img_footprints
zone_13_fionas_whereabouts_right.Icon = img_footprints
zone_13_fionas_whereabouts_right.Commands = {}
zone_13_fionas_whereabouts_right.DistanceRange = Distance(-1, "feet")
zone_13_fionas_whereabouts_right.ShowObjects = "OnEnter"
zone_13_fionas_whereabouts_right.ProximityRange = Distance(60, "meters")
zone_13_fionas_whereabouts_right.AllowSetPositionTo = false
zone_13_fionas_whereabouts_right.Active = false
zone_13_fionas_whereabouts_right.Points = {
	ZonePoint(52.5092425570015, 13.4758847951889, 0), 
	ZonePoint(52.5091739926996, 13.4760993719101, 0), 
	ZonePoint(52.5092752066316, 13.4761878848076, 0), 
	ZonePoint(52.5093666254666, 13.4759947657585, 0)
}
zone_13_fionas_whereabouts_right.OriginalPoint = ZonePoint(52.5092645954498, 13.4760417044163, 0)
zone_13_fionas_whereabouts_right.DistanceRangeUOM = "Feet"
zone_13_fionas_whereabouts_right.ProximityRangeUOM = "Meters"
zone_13_fionas_whereabouts_right.OutOfRangeName = ""
zone_13_fionas_whereabouts_right.InRangeName = ""
zone_13_fionas_whereabouts_wrong_4 = Wherigo.Zone(prometheus_chapter_2)
zone_13_fionas_whereabouts_wrong_4.Id = "4bb32d40-99df-4ca5-9f1a-0d67c8355224"
zone_13_fionas_whereabouts_wrong_4.Name = "zone_13_fionas_whereabouts_wrong_4"
zone_13_fionas_whereabouts_wrong_4.Description = ""
zone_13_fionas_whereabouts_wrong_4.Visible = false
zone_13_fionas_whereabouts_wrong_4.Media = img_footprints
zone_13_fionas_whereabouts_wrong_4.Icon = img_footprints
zone_13_fionas_whereabouts_wrong_4.Commands = {}
zone_13_fionas_whereabouts_wrong_4.DistanceRange = Distance(-1, "feet")
zone_13_fionas_whereabouts_wrong_4.ShowObjects = "OnEnter"
zone_13_fionas_whereabouts_wrong_4.ProximityRange = Distance(60, "meters")
zone_13_fionas_whereabouts_wrong_4.AllowSetPositionTo = false
zone_13_fionas_whereabouts_wrong_4.Active = false
zone_13_fionas_whereabouts_wrong_4.Points = {
	ZonePoint(52.5084328384175, 13.4765794873238, 0), 
	ZonePoint(52.5082777494865, 13.4767055511475, 0), 
	ZonePoint(52.5084410009777, 13.4768611192703, 0), 
	ZonePoint(52.5085732342411, 13.4767431020737, 0)
}
zone_13_fionas_whereabouts_wrong_4.OriginalPoint = ZonePoint(52.5084312057807, 13.4767223149538, 0)
zone_13_fionas_whereabouts_wrong_4.DistanceRangeUOM = "Feet"
zone_13_fionas_whereabouts_wrong_4.ProximityRangeUOM = "Meters"
zone_13_fionas_whereabouts_wrong_4.OutOfRangeName = ""
zone_13_fionas_whereabouts_wrong_4.InRangeName = ""
zone_13_fionas_whereabouts_wrong_2 = Wherigo.Zone(prometheus_chapter_2)
zone_13_fionas_whereabouts_wrong_2.Id = "f7e3ca98-52fd-4aab-97a1-0246acf55f64"
zone_13_fionas_whereabouts_wrong_2.Name = "zone_13_fionas_whereabouts_wrong_2"
zone_13_fionas_whereabouts_wrong_2.Description = ""
zone_13_fionas_whereabouts_wrong_2.Visible = false
zone_13_fionas_whereabouts_wrong_2.Media = img_footprints
zone_13_fionas_whereabouts_wrong_2.Icon = img_footprints
zone_13_fionas_whereabouts_wrong_2.Commands = {}
zone_13_fionas_whereabouts_wrong_2.DistanceRange = Distance(-1, "feet")
zone_13_fionas_whereabouts_wrong_2.ShowObjects = "OnEnter"
zone_13_fionas_whereabouts_wrong_2.ProximityRange = Distance(60, "meters")
zone_13_fionas_whereabouts_wrong_2.AllowSetPositionTo = false
zone_13_fionas_whereabouts_wrong_2.Active = false
zone_13_fionas_whereabouts_wrong_2.Points = {
	ZonePoint(52.5102334624698, 13.4760430455208, 0), 
	ZonePoint(52.5102905980181, 13.4761986136436, 0), 
	ZonePoint(52.5103665065604, 13.4761583805084, 0), 
	ZonePoint(52.5103142684379, 13.4760229289532, 0)
}
zone_13_fionas_whereabouts_wrong_2.OriginalPoint = ZonePoint(52.5103012088715, 13.4761057421565, 0)
zone_13_fionas_whereabouts_wrong_2.DistanceRangeUOM = "Feet"
zone_13_fionas_whereabouts_wrong_2.ProximityRangeUOM = "Meters"
zone_13_fionas_whereabouts_wrong_2.OutOfRangeName = ""
zone_13_fionas_whereabouts_wrong_2.InRangeName = ""
zone_16_fiona = Wherigo.Zone(prometheus_chapter_2)
zone_16_fiona.Id = "2d817083-cb4d-4660-9929-08ac24c0c284"
zone_16_fiona.Name = "zone_16_fiona"
zone_16_fiona.Description = ""
zone_16_fiona.Visible = false
zone_16_fiona.Media = img_footprints
zone_16_fiona.Icon = img_footprints
zone_16_fiona.Commands = {}
zone_16_fiona.DistanceRange = Distance(-1, "feet")
zone_16_fiona.ShowObjects = "OnEnter"
zone_16_fiona.ProximityRange = Distance(60, "meters")
zone_16_fiona.AllowSetPositionTo = false
zone_16_fiona.Active = false
zone_16_fiona.Points = {
	ZonePoint(52.5093617280338, 13.4761556982994, 0), 
	ZonePoint(52.5093405058188, 13.4762039780617, 0), 
	ZonePoint(52.5093209160728, 13.4761556982994, 0)
}
zone_16_fiona.OriginalPoint = ZonePoint(52.5093410499751, 13.4761717915535, 0)
zone_16_fiona.DistanceRangeUOM = "Feet"
zone_16_fiona.ProximityRangeUOM = "Meters"
zone_16_fiona.OutOfRangeName = ""
zone_16_fiona.InRangeName = ""
zone_18_greenwitch_meets_daughter = Wherigo.Zone(prometheus_chapter_2)
zone_18_greenwitch_meets_daughter.Id = "1ca0ff8e-cd0f-4303-9b6d-2849ac6eeee5"
zone_18_greenwitch_meets_daughter.Name = "zone_18_greenwitch_meets_daughter"
zone_18_greenwitch_meets_daughter.Description = ""
zone_18_greenwitch_meets_daughter.Visible = false
zone_18_greenwitch_meets_daughter.Commands = {}
zone_18_greenwitch_meets_daughter.DistanceRange = Distance(-1, "feet")
zone_18_greenwitch_meets_daughter.ShowObjects = "OnEnter"
zone_18_greenwitch_meets_daughter.ProximityRange = Distance(10, "meters")
zone_18_greenwitch_meets_daughter.AllowSetPositionTo = false
zone_18_greenwitch_meets_daughter.Active = false
zone_18_greenwitch_meets_daughter.Points = {
	ZonePoint(52.5135978034519, 13.478070795536, 0), 
	ZonePoint(52.5136304498464, 13.4778964519501, 0), 
	ZonePoint(52.513736550461, 13.4778106212616, 0), 
	ZonePoint(52.5138442831306, 13.4778428077698, 0), 
	ZonePoint(52.5139226339971, 13.4779098629951, 0), 
	ZonePoint(52.5140271016018, 13.4779876470566, 0), 
	ZonePoint(52.5139650739915, 13.4782049059868, 0), 
	ZonePoint(52.5139014139846, 13.478422164917, 0), 
	ZonePoint(52.5137218596219, 13.4782934188843, 0)
}
zone_18_greenwitch_meets_daughter.OriginalPoint = ZonePoint(52.5138163522319, 13.4780487418175, 0)
zone_18_greenwitch_meets_daughter.DistanceRangeUOM = "Feet"
zone_18_greenwitch_meets_daughter.ProximityRangeUOM = "Meters"
zone_18_greenwitch_meets_daughter.OutOfRangeName = ""
zone_18_greenwitch_meets_daughter.InRangeName = ""
zone_21a_traitors_end = Wherigo.Zone(prometheus_chapter_2)
zone_21a_traitors_end.Id = "9cfa7ecc-06f5-434f-9605-8bf50b7bf4b0"
zone_21a_traitors_end.Name = "zone_21a_traitors_end"
zone_21a_traitors_end.Description = ""
zone_21a_traitors_end.Visible = false
zone_21a_traitors_end.Media = img_zeus
zone_21a_traitors_end.Commands = {}
zone_21a_traitors_end.DistanceRange = Distance(-1, "feet")
zone_21a_traitors_end.ShowObjects = "OnEnter"
zone_21a_traitors_end.ProximityRange = Distance(60, "meters")
zone_21a_traitors_end.AllowSetPositionTo = false
zone_21a_traitors_end.Active = false
zone_21a_traitors_end.Points = {
	ZonePoint(52.5152855902599, 13.4818956255913, 0), 
	ZonePoint(52.5151892869539, 13.4818634390831, 0), 
	ZonePoint(52.51515174493, 13.4821638464928, 0), 
	ZonePoint(52.5152790612289, 13.4821960330009, 0)
}
zone_21a_traitors_end.OriginalPoint = ZonePoint(52.5152264208432, 13.482029736042, 0)
zone_21a_traitors_end.DistanceRangeUOM = "Feet"
zone_21a_traitors_end.ProximityRangeUOM = "Meters"
zone_21a_traitors_end.OutOfRangeName = ""
zone_21a_traitors_end.InRangeName = ""
zone_23c_heroes_end = Wherigo.Zone(prometheus_chapter_2)
zone_23c_heroes_end.Id = "5194ce8c-6b12-474c-856c-52bbf8c0ab8b"
zone_23c_heroes_end.Name = "zone_23c_heroes_end"
zone_23c_heroes_end.Description = ""
zone_23c_heroes_end.Visible = false
zone_23c_heroes_end.Commands = {}
zone_23c_heroes_end.DistanceRange = Distance(-1, "feet")
zone_23c_heroes_end.ShowObjects = "OnEnter"
zone_23c_heroes_end.ProximityRange = Distance(60, "meters")
zone_23c_heroes_end.AllowSetPositionTo = false
zone_23c_heroes_end.Active = false
zone_23c_heroes_end.Points = {
	ZonePoint(52.5160641702537, 13.5006523132324, 0), 
	ZonePoint(52.5157181364041, 13.5005879402161, 0), 
	ZonePoint(52.5156659046429, 13.5011029243469, 0), 
	ZonePoint(52.516018467826, 13.5011780261993, 0)
}
zone_23c_heroes_end.OriginalPoint = ZonePoint(52.5158666697817, 13.5008803009987, 0)
zone_23c_heroes_end.DistanceRangeUOM = "Feet"
zone_23c_heroes_end.ProximityRangeUOM = "Meters"
zone_23c_heroes_end.OutOfRangeName = ""
zone_23c_heroes_end.InRangeName = ""
zone_24d_mourners_end = Wherigo.Zone(prometheus_chapter_2)
zone_24d_mourners_end.Id = "d4e77ba0-3608-47cb-841f-d41c3a5be1f7"
zone_24d_mourners_end.Name = "zone_24d_mourners_end"
zone_24d_mourners_end.Description = ""
zone_24d_mourners_end.Visible = false
zone_24d_mourners_end.Commands = {}
zone_24d_mourners_end.DistanceRange = Distance(-1, "feet")
zone_24d_mourners_end.ShowObjects = "OnEnter"
zone_24d_mourners_end.ProximityRange = Distance(60, "meters")
zone_24d_mourners_end.AllowSetPositionTo = false
zone_24d_mourners_end.Active = false
zone_24d_mourners_end.Points = {
	ZonePoint(52.5184512399019, 13.492289185524, 0), 
	ZonePoint(52.5184414470606, 13.4925292432308, 0), 
	ZonePoint(52.5185997643943, 13.4925372898579, 0), 
	ZonePoint(52.5186005804615, 13.492294549942, 0)
}
zone_24d_mourners_end.OriginalPoint = ZonePoint(52.5185232579546, 13.4924125671387, 0)
zone_24d_mourners_end.DistanceRangeUOM = "Feet"
zone_24d_mourners_end.ProximityRangeUOM = "Meters"
zone_24d_mourners_end.OutOfRangeName = ""
zone_24d_mourners_end.InRangeName = ""
zone_22_helicopter = Wherigo.Zone(prometheus_chapter_2)
zone_22_helicopter.Id = "75fc82ed-ebf3-45b7-ab28-54fa969f4027"
zone_22_helicopter.Name = "zone_22_helicopter"
zone_22_helicopter.Description = ""
zone_22_helicopter.Visible = false
zone_22_helicopter.Commands = {}
zone_22_helicopter.DistanceRange = Distance(-1, "feet")
zone_22_helicopter.ShowObjects = "OnEnter"
zone_22_helicopter.ProximityRange = Distance(60, "meters")
zone_22_helicopter.AllowSetPositionTo = false
zone_22_helicopter.Active = false
zone_22_helicopter.Points = {
	ZonePoint(52.5144972027497, 13.4766411781311, 0), 
	ZonePoint(52.514644108327, 13.4769201278687, 0), 
	ZonePoint(52.514712664095, 13.476625084877, 0)
}
zone_22_helicopter.OriginalPoint = ZonePoint(52.5146179917239, 13.4767287969589, 0)
zone_22_helicopter.DistanceRangeUOM = "Feet"
zone_22_helicopter.ProximityRangeUOM = "Meters"
zone_22_helicopter.OutOfRangeName = ""
zone_22_helicopter.InRangeName = ""
zone_22_road_block_1 = Wherigo.Zone(prometheus_chapter_2)
zone_22_road_block_1.Id = "f39499cb-3bad-44b8-be07-a687e951a847"
zone_22_road_block_1.Name = "zone_22_road_block_1"
zone_22_road_block_1.Description = ""
zone_22_road_block_1.Visible = false
zone_22_road_block_1.Commands = {}
zone_22_road_block_1.DistanceRange = Distance(-1, "feet")
zone_22_road_block_1.ShowObjects = "OnEnter"
zone_22_road_block_1.ProximityRange = Distance(60, "meters")
zone_22_road_block_1.AllowSetPositionTo = false
zone_22_road_block_1.Active = false
zone_22_road_block_1.Points = {
	ZonePoint(52.5131130016395, 13.4758472442627, 0), 
	ZonePoint(52.5106056584222, 13.4992790222168, 0), 
	ZonePoint(52.5156463177165, 13.500394821167, 0), 
	ZonePoint(52.5178661138022, 13.4785509109497, 0), 
	ZonePoint(52.5160119389039, 13.4821128845215, 0), 
	ZonePoint(52.5155679699233, 13.4866189956665, 0), 
	ZonePoint(52.5159074760179, 13.4876489639282, 0), 
	ZonePoint(52.5153590417921, 13.4915971755981, 0), 
	ZonePoint(52.5149411825492, 13.4920263290405, 0), 
	ZonePoint(52.5145494359001, 13.4978199005127, 0), 
	ZonePoint(52.5119377023187, 13.497519493103, 0), 
	ZonePoint(52.513792049142, 13.4776496887207, 0)
}
zone_22_road_block_1.OriginalPoint = ZonePoint(52.514608157344, 13.4889221191406, 0)
zone_22_road_block_1.DistanceRangeUOM = "Feet"
zone_22_road_block_1.ProximityRangeUOM = "Meters"
zone_22_road_block_1.OutOfRangeName = ""
zone_22_road_block_1.InRangeName = ""
zone_22_agent_1 = Wherigo.Zone(prometheus_chapter_2)
zone_22_agent_1.Id = "b7985d62-035f-4c46-990e-63ee0a6acb8a"
zone_22_agent_1.Name = "zone_22_agent_1"
zone_22_agent_1.Description = ""
zone_22_agent_1.Visible = false
zone_22_agent_1.Commands = {}
zone_22_agent_1.DistanceRange = Distance(-1, "feet")
zone_22_agent_1.ShowObjects = "OnEnter"
zone_22_agent_1.ProximityRange = Distance(60, "meters")
zone_22_agent_1.AllowSetPositionTo = false
zone_22_agent_1.Active = false
zone_22_agent_1.Points = {
	ZonePoint(52.5145665748891, 13.4847575426102, 0), 
	ZonePoint(52.5146449244677, 13.4847240149975, 0), 
	ZonePoint(52.514707767258, 13.4847401082516, 0), 
	ZonePoint(52.5147624485738, 13.4847508370876, 0), 
	ZonePoint(52.5148130491338, 13.4847642481327, 0), 
	ZonePoint(52.5148620173621, 13.4847803413868, 0), 
	ZonePoint(52.5149101694001, 13.4847964346409, 0), 
	ZonePoint(52.5149672988683, 13.4848165512085, 0), 
	ZonePoint(52.5150260605295, 13.4848487377167, 0), 
	ZonePoint(52.5150701317239, 13.484915792942, 0), 
	ZonePoint(52.5150668671925, 13.4849855303764, 0), 
	ZonePoint(52.515029325064, 13.4850284457207, 0), 
	ZonePoint(52.5149779086185, 13.4850458800793, 0), 
	ZonePoint(52.5149289405193, 13.4850177168846, 0), 
	ZonePoint(52.5148783400928, 13.485005646944, 0), 
	ZonePoint(52.5148187620965, 13.484992235899, 0), 
	ZonePoint(52.5147551033263, 13.4849788248539, 0), 
	ZonePoint(52.5146906283241, 13.4849680960178, 0), 
	ZonePoint(52.5146343146372, 13.4849439561367, 0), 
	ZonePoint(52.5145592296089, 13.484907746315, 0)
}
zone_22_agent_1.OriginalPoint = ZonePoint(52.5148334930843, 13.4848884344101, 0)
zone_22_agent_1.DistanceRangeUOM = "Feet"
zone_22_agent_1.ProximityRangeUOM = "Meters"
zone_22_agent_1.OutOfRangeName = ""
zone_22_agent_1.InRangeName = ""
zone_22_agent_2 = Wherigo.Zone(prometheus_chapter_2)
zone_22_agent_2.Id = "b449dc79-add6-4a70-b79f-b0b21c55b759"
zone_22_agent_2.Name = "zone_22_agent_2"
zone_22_agent_2.Description = ""
zone_22_agent_2.Visible = false
zone_22_agent_2.Commands = {}
zone_22_agent_2.DistanceRange = Distance(-1, "feet")
zone_22_agent_2.ShowObjects = "OnEnter"
zone_22_agent_2.ProximityRange = Distance(60, "meters")
zone_22_agent_2.AllowSetPositionTo = false
zone_22_agent_2.Active = false
zone_22_agent_2.Points = {
	ZonePoint(52.5156161211877, 13.4889491647482, 0), 
	ZonePoint(52.5155826601452, 13.4890235960484, 0), 
	ZonePoint(52.5155426700853, 13.4890497475863, 0), 
	ZonePoint(52.5154671785466, 13.4890933334827, 0), 
	ZonePoint(52.5154210674348, 13.4891422837973, 0), 
	ZonePoint(52.5153488401977, 13.4891355782747, 0), 
	ZonePoint(52.5152647789701, 13.4891168028116, 0), 
	ZonePoint(52.5152027531068, 13.4890685230494, 0), 
	ZonePoint(52.5151064496193, 13.4890108555555, 0), 
	ZonePoint(52.515115427072, 13.4889256954193, 0), 
	ZonePoint(52.5152003047158, 13.4888425469398, 0), 
	ZonePoint(52.5152843660666, 13.4888284653425, 0), 
	ZonePoint(52.5153627143655, 13.4888177365065, 0), 
	ZonePoint(52.5154316770754, 13.4887956082821, 0), 
	ZonePoint(52.5154781962387, 13.4887607395649, 0), 
	ZonePoint(52.515539405589, 13.4888023138046, 0), 
	ZonePoint(52.5156055115917, 13.4888908267021, 0)
}
zone_22_agent_2.OriginalPoint = ZonePoint(52.5153864777652, 13.4889561069362, 0)
zone_22_agent_2.DistanceRangeUOM = "Feet"
zone_22_agent_2.ProximityRangeUOM = "Meters"
zone_22_agent_2.OutOfRangeName = ""
zone_22_agent_2.InRangeName = ""
zone_13_fionas_whereabouts_wrong_3 = Wherigo.Zone(prometheus_chapter_2)
zone_13_fionas_whereabouts_wrong_3.Id = "52b20271-755e-4194-831e-043397d59fde"
zone_13_fionas_whereabouts_wrong_3.Name = "zone_13_fionas_whereabouts_wrong_3"
zone_13_fionas_whereabouts_wrong_3.Description = ""
zone_13_fionas_whereabouts_wrong_3.Visible = false
zone_13_fionas_whereabouts_wrong_3.Media = img_footprints
zone_13_fionas_whereabouts_wrong_3.Commands = {}
zone_13_fionas_whereabouts_wrong_3.DistanceRange = Distance(-1, "feet")
zone_13_fionas_whereabouts_wrong_3.ShowObjects = "OnEnter"
zone_13_fionas_whereabouts_wrong_3.ProximityRange = Distance(60, "meters")
zone_13_fionas_whereabouts_wrong_3.AllowSetPositionTo = false
zone_13_fionas_whereabouts_wrong_3.Active = false
zone_13_fionas_whereabouts_wrong_3.Points = {
	ZonePoint(52.5093290784681, 13.4763059020042, 0), 
	ZonePoint(52.5095119157238, 13.4764185547829, 0), 
	ZonePoint(52.5096653678335, 13.4763622283936, 0), 
	ZonePoint(52.509523343027, 13.4761664271355, 0)
}
zone_13_fionas_whereabouts_wrong_3.OriginalPoint = ZonePoint(52.5095074262631, 13.4763132780791, 0)
zone_13_fionas_whereabouts_wrong_3.DistanceRangeUOM = "Feet"
zone_13_fionas_whereabouts_wrong_3.ProximityRangeUOM = "Meters"
zone_13_fionas_whereabouts_wrong_3.OutOfRangeName = ""
zone_13_fionas_whereabouts_wrong_3.InRangeName = ""
zone_13_fionas_whereabouts_wrong_1 = Wherigo.Zone(prometheus_chapter_2)
zone_13_fionas_whereabouts_wrong_1.Id = "e4c4efb5-49b1-4d0a-bcd9-8c05ae7fe84b"
zone_13_fionas_whereabouts_wrong_1.Name = "zone_13_fionas_whereabouts_wrong_1"
zone_13_fionas_whereabouts_wrong_1.Description = ""
zone_13_fionas_whereabouts_wrong_1.Visible = false
zone_13_fionas_whereabouts_wrong_1.Media = img_footprints
zone_13_fionas_whereabouts_wrong_1.Commands = {}
zone_13_fionas_whereabouts_wrong_1.DistanceRange = Distance(-1, "feet")
zone_13_fionas_whereabouts_wrong_1.ShowObjects = "OnEnter"
zone_13_fionas_whereabouts_wrong_1.ProximityRange = Distance(60, "meters")
zone_13_fionas_whereabouts_wrong_1.AllowSetPositionTo = false
zone_13_fionas_whereabouts_wrong_1.Active = false
zone_13_fionas_whereabouts_wrong_1.Points = {
	ZonePoint(52.5082434665963, 13.4736049175262, 0), 
	ZonePoint(52.5081161299129, 13.4739857912064, 0), 
	ZonePoint(52.507954509745, 13.4738248586655, 0), 
	ZonePoint(52.508090009522, 13.4734627604485, 0)
}
zone_13_fionas_whereabouts_wrong_1.OriginalPoint = ZonePoint(52.508101028944, 13.4737195819616, 0)
zone_13_fionas_whereabouts_wrong_1.DistanceRangeUOM = "Feet"
zone_13_fionas_whereabouts_wrong_1.ProximityRangeUOM = "Meters"
zone_13_fionas_whereabouts_wrong_1.OutOfRangeName = ""
zone_13_fionas_whereabouts_wrong_1.InRangeName = ""
zone_22_agent_3 = Wherigo.Zone(prometheus_chapter_2)
zone_22_agent_3.Id = "df3755b9-6838-48e2-b3aa-c0873823929c"
zone_22_agent_3.Name = "zone_22_agent_3"
zone_22_agent_3.Description = ""
zone_22_agent_3.Visible = false
zone_22_agent_3.Commands = {}
zone_22_agent_3.DistanceRange = Distance(-1, "feet")
zone_22_agent_3.ShowObjects = "OnEnter"
zone_22_agent_3.ProximityRange = Distance(60, "meters")
zone_22_agent_3.AllowSetPositionTo = false
zone_22_agent_3.Active = false
zone_22_agent_3.Points = {
	ZonePoint(52.5142715385035, 13.4932782500982, 0), 
	ZonePoint(52.5143364221938, 13.4932976961136, 0), 
	ZonePoint(52.5143845748078, 13.4933090955019, 0), 
	ZonePoint(52.5144237497769, 13.4933272004128, 0), 
	ZonePoint(52.5144719022951, 13.4933318942785, 0), 
	ZonePoint(52.5145123014012, 13.4933439642191, 0), 
	ZonePoint(52.5145584134666, 13.4933486580849, 0), 
	ZonePoint(52.51457473631, 13.4932923316956, 0), 
	ZonePoint(52.5145478036151, 13.4932232648134, 0), 
	ZonePoint(52.514493530104, 13.4932111948729, 0), 
	ZonePoint(52.5144523148365, 13.4931991249323, 0), 
	ZonePoint(52.5144110995303, 13.49319845438, 0), 
	ZonePoint(52.5143698841855, 13.4931870549917, 0), 
	ZonePoint(52.5143070409119, 13.4931917488575, 0)
}
zone_22_agent_3.OriginalPoint = ZonePoint(52.5144368079956, 13.4932671380895, 0)
zone_22_agent_3.DistanceRangeUOM = "Feet"
zone_22_agent_3.ProximityRangeUOM = "Meters"
zone_22_agent_3.OutOfRangeName = ""
zone_22_agent_3.InRangeName = ""
zone_22_road_block_2 = Wherigo.Zone(prometheus_chapter_2)
zone_22_road_block_2.Id = "d123c864-4b05-4547-9174-33194f79a16e"
zone_22_road_block_2.Name = "zone_22_road_block_2"
zone_22_road_block_2.Description = ""
zone_22_road_block_2.Visible = false
zone_22_road_block_2.Commands = {}
zone_22_road_block_2.DistanceRange = Distance(-1, "feet")
zone_22_road_block_2.ShowObjects = "OnEnter"
zone_22_road_block_2.ProximityRange = Distance(60, "meters")
zone_22_road_block_2.AllowSetPositionTo = false
zone_22_road_block_2.Active = false
zone_22_road_block_2.Points = {
	ZonePoint(52.5140597476774, 13.4817051887512, 0), 
	ZonePoint(52.5140597476774, 13.4819841384888, 0), 
	ZonePoint(52.5143078570589, 13.4819304943085, 0), 
	ZonePoint(52.5144580278461, 13.4817802906036, 0), 
	ZonePoint(52.5143862070989, 13.4815764427185, 0), 
	ZonePoint(52.5142360360662, 13.4817159175873, 0)
}
zone_22_road_block_2.OriginalPoint = ZonePoint(52.5142512705708, 13.481782078743, 0)
zone_22_road_block_2.DistanceRangeUOM = "Feet"
zone_22_road_block_2.ProximityRangeUOM = "Meters"
zone_22_road_block_2.OutOfRangeName = ""
zone_22_road_block_2.InRangeName = ""
zone_22_road_block_3 = Wherigo.Zone(prometheus_chapter_2)
zone_22_road_block_3.Id = "4b533cae-d866-4ac3-9f2a-5e1c0c31cd16"
zone_22_road_block_3.Name = "zone_22_road_block_3"
zone_22_road_block_3.Description = ""
zone_22_road_block_3.Visible = false
zone_22_road_block_3.Commands = {}
zone_22_road_block_3.DistanceRange = Distance(-1, "feet")
zone_22_road_block_3.ShowObjects = "OnEnter"
zone_22_road_block_3.ProximityRange = Distance(60, "meters")
zone_22_road_block_3.AllowSetPositionTo = false
zone_22_road_block_3.Active = false
zone_22_road_block_3.Points = {
	ZonePoint(52.5152562096127, 13.4905993938446, 0), 
	ZonePoint(52.5151174674019, 13.4907227754593, 0), 
	ZonePoint(52.5151778611239, 13.4909051656723, 0), 
	ZonePoint(52.5153117063743, 13.4907495975494, 0)
}
zone_22_road_block_3.OriginalPoint = ZonePoint(52.5152158111282, 13.4907442331314, 0)
zone_22_road_block_3.DistanceRangeUOM = "Feet"
zone_22_road_block_3.ProximityRangeUOM = "Meters"
zone_22_road_block_3.OutOfRangeName = ""
zone_22_road_block_3.InRangeName = ""

-- Characters --
character_fiona_greenwitch = Wherigo.ZCharacter{
	Cartridge = prometheus_chapter_2, 
	Container = zone_16_fiona
}
character_fiona_greenwitch.Id = "053f3af3-3ab9-4195-ab0f-6e3b7d7f94e3"
character_fiona_greenwitch.Name = "Fiona Greenwitch"
character_fiona_greenwitch.Description = ""
character_fiona_greenwitch.Visible = true
character_fiona_greenwitch.Media = img_fiona_greenwitch
character_fiona_greenwitch.Commands = {}
character_fiona_greenwitch.ObjectLocation = Wherigo.INVALID_ZONEPOINT
character_fiona_greenwitch.Gender = "Female"
character_fiona_greenwitch.Type = "NPC"
character_john_greenwitch = Wherigo.ZCharacter(prometheus_chapter_2)
character_john_greenwitch.Id = "6a6f62bc-a67f-490d-85fa-aadf23acf778"
character_john_greenwitch.Name = "John Greenwitch"
character_john_greenwitch.Description = ""
character_john_greenwitch.Visible = true
character_john_greenwitch.Media = img_john_greenwitch
character_john_greenwitch.Commands = {}
character_john_greenwitch.ObjectLocation = Wherigo.INVALID_ZONEPOINT
character_john_greenwitch.Gender = "Male"
character_john_greenwitch.Type = "NPC"
character_mr_johnson = Wherigo.ZCharacter(prometheus_chapter_2)
character_mr_johnson.Id = "87384a5c-9341-48a8-8a38-8816162417a3"
character_mr_johnson.Name = "Mr. Johnson"
character_mr_johnson.Description = ""
character_mr_johnson.Visible = true
character_mr_johnson.Media = img_mr_johnson
character_mr_johnson.Commands = {}
character_mr_johnson.ObjectLocation = Wherigo.INVALID_ZONEPOINT
character_mr_johnson.Gender = "Male"
character_mr_johnson.Type = "NPC"
character_medical_doctor = Wherigo.ZCharacter{
	Cartridge = prometheus_chapter_2, 
	Container = zone_23_hospital
}
character_medical_doctor.Id = "0ea50022-5f8d-4d79-9691-26c8996dec95"
character_medical_doctor.Name = "Dr. Who"
character_medical_doctor.Description = ""
character_medical_doctor.Visible = true
character_medical_doctor.Commands = {}
character_medical_doctor.ObjectLocation = Wherigo.INVALID_ZONEPOINT
character_medical_doctor.Gender = "Female"
character_medical_doctor.Type = "NPC"

-- Items --
item_12_call_from_johnson_abducted_daughter = Wherigo.ZItem{
	Cartridge = prometheus_chapter_2, 
	Container = Player
}
item_12_call_from_johnson_abducted_daughter.Id = "41db92c6-7faa-4bc0-8ba7-b3c234ca2c3f"
item_12_call_from_johnson_abducted_daughter.Name = "item_12_call_from_johnson_abducted_daughter"
item_12_call_from_johnson_abducted_daughter.Description = ""
item_12_call_from_johnson_abducted_daughter.Visible = false
item_12_call_from_johnson_abducted_daughter.Commands = {
	command_listen = Wherigo.ZCommand{
		Text = "command_listen", 
		CmdWith = false, 
		Enabled = true, 
		EmptyTargetListText = "Nothing available"
	}
}
item_12_call_from_johnson_abducted_daughter.Commands.command_listen.Custom = true
item_12_call_from_johnson_abducted_daughter.Commands.command_listen.Id = "a58f52ee-485c-44cb-9be6-38259c022821"
item_12_call_from_johnson_abducted_daughter.Commands.command_listen.WorksWithAll = true
item_12_call_from_johnson_abducted_daughter.ObjectLocation = Wherigo.INVALID_ZONEPOINT
item_12_call_from_johnson_abducted_daughter.Locked = false
item_12_call_from_johnson_abducted_daughter.Opened = false
item_memo = Wherigo.ZItem{
	Cartridge = prometheus_chapter_2, 
	Container = Player
}
item_memo.Id = "586cac6e-242c-4662-85ea-34dd410e9c53"
item_memo.Name = "item_memo"
item_memo.Description = ""
item_memo.Visible = true
item_memo.Media = img_memo
item_memo.Icon = icon_memo
item_memo.Commands = {
	command_view = Wherigo.ZCommand{
		Text = "command_view", 
		CmdWith = false, 
		Enabled = true, 
		EmptyTargetListText = "Nothing available"
	}
}
item_memo.Commands.command_view.Custom = true
item_memo.Commands.command_view.Id = "df5c6a47-49a4-44ad-9042-b727d3de5ae7"
item_memo.Commands.command_view.WorksWithAll = true
item_memo.ObjectLocation = Wherigo.INVALID_ZONEPOINT
item_memo.Locked = false
item_memo.Opened = false
item_03_health_office_answering_machine = Wherigo.ZItem{
	Cartridge = prometheus_chapter_2, 
	Container = Player
}
item_03_health_office_answering_machine.Id = "3a8023f9-654b-4338-889e-8e47daf28b3e"
item_03_health_office_answering_machine.Name = "item_03_health_office_answering_machine"
item_03_health_office_answering_machine.Description = ""
item_03_health_office_answering_machine.Visible = false
item_03_health_office_answering_machine.Media = img_telephone
item_03_health_office_answering_machine.Icon = icon_telephone
item_03_health_office_answering_machine.Commands = {
	command_call = Wherigo.ZCommand{
		Text = "command_call", 
		CmdWith = false, 
		Enabled = true, 
		EmptyTargetListText = "Nothing available"
	}
}
item_03_health_office_answering_machine.Commands.command_call.Custom = true
item_03_health_office_answering_machine.Commands.command_call.Id = "7a2c310b-229a-4d9f-b472-bce5f30ec479"
item_03_health_office_answering_machine.Commands.command_call.WorksWithAll = true
item_03_health_office_answering_machine.ObjectLocation = Wherigo.INVALID_ZONEPOINT
item_03_health_office_answering_machine.Locked = false
item_03_health_office_answering_machine.Opened = false
item_03_news = Wherigo.ZItem{
	Cartridge = prometheus_chapter_2, 
	Container = Player
}
item_03_news.Id = "35ede1e9-19f0-4cbf-88d4-85c7f75f39eb"
item_03_news.Name = "item_03_news"
item_03_news.Description = ""
item_03_news.Visible = false
item_03_news.Commands = {
	command_view = Wherigo.ZCommand{
		Text = "command_view", 
		CmdWith = false, 
		Enabled = true, 
		EmptyTargetListText = "Nothing available"
	}
}
item_03_news.Commands.command_view.Custom = true
item_03_news.Commands.command_view.Id = "eee022ed-27b7-4036-a91e-22fb1888c59b"
item_03_news.Commands.command_view.WorksWithAll = true
item_03_news.ObjectLocation = Wherigo.INVALID_ZONEPOINT
item_03_news.Locked = false
item_03_news.Opened = false
item_20_antidote = Wherigo.ZItem{
	Cartridge = prometheus_chapter_2, 
	Container = character_john_greenwitch
}
item_20_antidote.Id = "01adf745-03d7-4360-b6df-a093c0a7b3d0"
item_20_antidote.Name = "item_20_antidote"
item_20_antidote.Description = ""
item_20_antidote.Visible = true
item_20_antidote.Media = img_antidote
item_20_antidote.Icon = img_antidote
item_20_antidote.Commands = {}
item_20_antidote.ObjectLocation = Wherigo.INVALID_ZONEPOINT
item_20_antidote.Locked = false
item_20_antidote.Opened = false
item_20b_minigame_rules = Wherigo.ZItem{
	Cartridge = prometheus_chapter_2, 
	Container = Player
}
item_20b_minigame_rules.Id = "5bdf40ee-816c-4cce-afc4-81aa0a245e90"
item_20b_minigame_rules.Name = "item_20b_minigame_rules"
item_20b_minigame_rules.Description = ""
item_20b_minigame_rules.Visible = false
item_20b_minigame_rules.Commands = {
	command_view = Wherigo.ZCommand{
		Text = "command_view", 
		CmdWith = false, 
		Enabled = true, 
		EmptyTargetListText = ""
	}
}
item_20b_minigame_rules.Commands.command_view.Custom = true
item_20b_minigame_rules.Commands.command_view.Id = "cd95b7f0-5ef7-4b05-8ef5-c5057f854647"
item_20b_minigame_rules.Commands.command_view.WorksWithAll = true
item_20b_minigame_rules.ObjectLocation = Wherigo.INVALID_ZONEPOINT
item_20b_minigame_rules.Locked = false
item_20b_minigame_rules.Opened = false
item_completion_code = Wherigo.ZItem{
	Cartridge = prometheus_chapter_2, 
	Container = Player
}
item_completion_code.Id = "222bed24-9d5a-4dce-a6e4-4d58643e00b7"
item_completion_code.Name = "item_completion_code"
item_completion_code.Description = ""
item_completion_code.Visible = false
item_completion_code.Commands = {
	command_view = Wherigo.ZCommand{
		Text = "command_view", 
		CmdWith = false, 
		Enabled = true, 
		EmptyTargetListText = ""
	}
}
item_completion_code.Commands.command_view.Custom = true
item_completion_code.Commands.command_view.Id = "a2b148c0-62e2-4cbc-abf7-2374c5e497e8"
item_completion_code.Commands.command_view.WorksWithAll = true
item_completion_code.ObjectLocation = Wherigo.INVALID_ZONEPOINT
item_completion_code.Locked = false
item_completion_code.Opened = false
item_credits = Wherigo.ZItem{
	Cartridge = prometheus_chapter_2, 
	Container = Player
}
item_credits.Id = "7e0deea7-2b42-49d2-bdd2-db039c7d3e25"
item_credits.Name = "item_credits"
item_credits.Description = ""
item_credits.Visible = false
item_credits.Commands = {
	command_view = Wherigo.ZCommand{
		Text = "command_view", 
		CmdWith = false, 
		Enabled = true, 
		EmptyTargetListText = ""
	}
}
item_credits.Commands.command_view.Custom = true
item_credits.Commands.command_view.Id = "ecd25b52-49c4-47d9-8fbe-5350fea8f40c"
item_credits.Commands.command_view.WorksWithAll = true
item_credits.ObjectLocation = Wherigo.INVALID_ZONEPOINT
item_credits.Locked = false
item_credits.Opened = false

-- Tasks --
task_07_call_to_greenwitch = Wherigo.ZTask(prometheus_chapter_2)
task_07_call_to_greenwitch.Id = "fce99167-e807-45e0-ab7f-7b7fa5438b5a"
task_07_call_to_greenwitch.Name = "task_07_call_to_greenwitch"
task_07_call_to_greenwitch.Description = ""
task_07_call_to_greenwitch.Visible = false
task_07_call_to_greenwitch.Active = false
task_07_call_to_greenwitch.Complete = false
task_07_call_to_greenwitch.CorrectState = "None"
task_01_previously = Wherigo.ZTask(prometheus_chapter_2)
task_01_previously.Id = "bddcf3d6-8b63-4bb0-831f-6da0e2639f6d"
task_01_previously.Name = "task_01_previously"
task_01_previously.Description = ""
task_01_previously.Visible = true
task_01_previously.Active = true
task_01_previously.Complete = false
task_01_previously.CorrectState = "None"
task_04_call_from_johnson_1_2 = Wherigo.ZTask(prometheus_chapter_2)
task_04_call_from_johnson_1_2.Id = "77478d1d-eae0-4296-8923-ad3c81afddcb"
task_04_call_from_johnson_1_2.Name = "task_04_call_from_johnson_1_2"
task_04_call_from_johnson_1_2.Description = ""
task_04_call_from_johnson_1_2.Visible = false
task_04_call_from_johnson_1_2.Active = false
task_04_call_from_johnson_1_2.Complete = false
task_04_call_from_johnson_1_2.CorrectState = "None"
task_08_call_to_greenwitch_end = Wherigo.ZTask(prometheus_chapter_2)
task_08_call_to_greenwitch_end.Id = "3310a115-8b44-462f-ac37-fc58994179d7"
task_08_call_to_greenwitch_end.Name = "task_08_call_to_greenwitch_end"
task_08_call_to_greenwitch_end.Description = ""
task_08_call_to_greenwitch_end.Visible = false
task_08_call_to_greenwitch_end.Active = false
task_08_call_to_greenwitch_end.Complete = false
task_08_call_to_greenwitch_end.CorrectState = "None"
task_19_warn_greenwitch_or_wait = Wherigo.ZTask(prometheus_chapter_2)
task_19_warn_greenwitch_or_wait.Id = "7f767778-b589-41a9-b907-b32fb8ffda6e"
task_19_warn_greenwitch_or_wait.Name = "task_19_warn_greenwitch_or_wait"
task_19_warn_greenwitch_or_wait.Description = ""
task_19_warn_greenwitch_or_wait.Visible = false
task_19_warn_greenwitch_or_wait.Active = false
task_19_warn_greenwitch_or_wait.Complete = false
task_19_warn_greenwitch_or_wait.CorrectState = "None"
task_20b_bring_antidote_to_hospital = Wherigo.ZTask(prometheus_chapter_2)
task_20b_bring_antidote_to_hospital.Id = "28ae3320-2b8b-4a75-b057-cf50807bcf1c"
task_20b_bring_antidote_to_hospital.Name = "task_20b_bring_antidote_to_hospital"
task_20b_bring_antidote_to_hospital.Description = ""
task_20b_bring_antidote_to_hospital.Visible = false
task_20b_bring_antidote_to_hospital.Active = false
task_20b_bring_antidote_to_hospital.Complete = false
task_20b_bring_antidote_to_hospital.CorrectState = "None"
debug_task = Wherigo.ZTask(prometheus_chapter_2)
debug_task.Id = "54715617-d1fa-428b-9ff3-3fd15eb2f23e"
debug_task.Name = "debug_task"
debug_task.Description = ""
debug_task.Visible = true
debug_task.Active = true
debug_task.Complete = false
debug_task.CorrectState = "None"
debug_task_lose_antidote = Wherigo.ZTask(prometheus_chapter_2)
debug_task_lose_antidote.Id = "26ac03c6-3091-450c-8ec1-c505cf1bad7f"
debug_task_lose_antidote.Name = "debug_task_lose_antidote"
debug_task_lose_antidote.Description = ""
debug_task_lose_antidote.Visible = true
debug_task_lose_antidote.Active = true
debug_task_lose_antidote.Complete = false
debug_task_lose_antidote.CorrectState = "None"
task_13_find_fiona = Wherigo.ZTask(prometheus_chapter_2)
task_13_find_fiona.Id = "48b064f2-9c97-4dd7-94ce-6fcc8fa45579"
task_13_find_fiona.Name = "task_13_find_fiona"
task_13_find_fiona.Description = ""
task_13_find_fiona.Visible = false
task_13_find_fiona.Active = false
task_13_find_fiona.Complete = false
task_13_find_fiona.CorrectState = "None"

-- Cartridge Variables --
string_yes = ""
string_no = ""
result = false
bool_06a_call_from_johnson_daughter_abducted = false
int_10_shake_off_pursuers = 5
bool_08_told_greenwitch_about_abduction = false
bool_13_fionas_whereabouts_found = false
int_16_track_fiona_iterator = 1
bool_10_pursuers_shaken_off = false
int_16_track_fiona_length = 0
int_18_greenwitch_meets_daughter_iterator = 1
int_18_greenwitch_meets_daughter_length = 0
bool_19_warned_greenwitch = false
bool_19_can_warn_greenwitch = false
int_22_helicopter_direction = 0
int_22_helicopter_distance = 100
int_22_helicopter_range_of_sight = 25
int_22_helicopter_speed = 15
int_22_agent_1_iterator = 1
int_22_agent_1_length = 0
int_22_agent_2_iterator = 1
int_22_agent_2_length = 0
int_22_agent_3_iterator = 1
int_22_agent_3_length = 0
bool_22_henchmen_active = false
bool_17_call_from_johnson_stay = false
_BNP0K = "zone_09_meet_greenwitch"
_g_25 = "character_fiona_greenwitch"
_Dveg = "item_12_call_from_johnson_abducted_daughter"
_PFowZ = "task_07_call_to_greenwitch"
_HQbny = "input_08"
_WBObK = "timer_02_call_from_johnson"
prometheus_chapter_2.ZVariables = {
	string_yes = "", 
	string_no = "", 
	result = false, 
	bool_06a_call_from_johnson_daughter_abducted = false, 
	int_10_shake_off_pursuers = 5, 
	bool_08_told_greenwitch_about_abduction = false, 
	bool_13_fionas_whereabouts_found = false, 
	int_16_track_fiona_iterator = 1, 
	bool_10_pursuers_shaken_off = false, 
	int_16_track_fiona_length = 0, 
	int_18_greenwitch_meets_daughter_iterator = 1, 
	int_18_greenwitch_meets_daughter_length = 0, 
	bool_19_warned_greenwitch = false, 
	bool_19_can_warn_greenwitch = false, 
	int_22_helicopter_direction = 0, 
	int_22_helicopter_distance = 100, 
	int_22_helicopter_range_of_sight = 25, 
	int_22_helicopter_speed = 15, 
	int_22_agent_1_iterator = 1, 
	int_22_agent_1_length = 0, 
	int_22_agent_2_iterator = 1, 
	int_22_agent_2_length = 0, 
	int_22_agent_3_iterator = 1, 
	int_22_agent_3_length = 0, 
	bool_22_henchmen_active = false, 
	bool_17_call_from_johnson_stay = false, 
	_BNP0K = "zone_09_meet_greenwitch", 
	_g_25 = "character_fiona_greenwitch", 
	_Dveg = "item_12_call_from_johnson_abducted_daughter", 
	_PFowZ = "task_07_call_to_greenwitch", 
	_HQbny = "input_08", 
	_WBObK = "timer_02_call_from_johnson"
}

-- Timers --
timer_02_call_from_johnson = Wherigo.ZTimer(prometheus_chapter_2)
timer_02_call_from_johnson.Id = "9dbf15b3-c4ac-451b-83b8-cf5f2a7bb7a2"
timer_02_call_from_johnson.Name = "timer_02_call_from_johnson"
timer_02_call_from_johnson.Description = "Shows text_02_call_from_johnson_1_1"
timer_02_call_from_johnson.Visible = true
timer_02_call_from_johnson.Duration = 3
timer_02_call_from_johnson.Type = "Countdown"
timer_10_shake_off_pursuers = Wherigo.ZTimer(prometheus_chapter_2)
timer_10_shake_off_pursuers.Id = "791f95c1-4606-4b26-9b8a-f9262260d3cc"
timer_10_shake_off_pursuers.Name = "timer_10_shake_off_pursuers"
timer_10_shake_off_pursuers.Description = [[Places zone_10_shake_off_pursuers
around the player's position and activates
that zone.]]
timer_10_shake_off_pursuers.Visible = true
timer_10_shake_off_pursuers.Duration = 2
timer_10_shake_off_pursuers.Type = "Countdown"
timer_11_call_from_greenwitch = Wherigo.ZTimer(prometheus_chapter_2)
timer_11_call_from_greenwitch.Id = "067f4f5b-db8c-4214-8042-2cee272aa99f"
timer_11_call_from_greenwitch.Name = "timer_11_call_from_greenwitch"
timer_11_call_from_greenwitch.Description = [[Shows
text_11_call_from_greenwitch_abduction
or
text_11_call_from_greenwitch]]
timer_11_call_from_greenwitch.Visible = true
timer_11_call_from_greenwitch.Duration = 2
timer_11_call_from_greenwitch.Type = "Countdown"
timer_10_call_from_greenwitch_followed = Wherigo.ZTimer(prometheus_chapter_2)
timer_10_call_from_greenwitch_followed.Id = "01542f94-1742-4d07-b6fa-964c4ad51bde"
timer_10_call_from_greenwitch_followed.Name = "timer_10_call_from_greenwitch_followed"
timer_10_call_from_greenwitch_followed.Description = "Shows timer_10_call_from_greenwitch_followed"
timer_10_call_from_greenwitch_followed.Visible = true
timer_10_call_from_greenwitch_followed.Duration = 2
timer_10_call_from_greenwitch_followed.Type = "Countdown"
timer_14_call_from_johnson_right_zone = Wherigo.ZTimer(prometheus_chapter_2)
timer_14_call_from_johnson_right_zone.Id = "e80acf40-8663-40bb-8455-37b3f7ff72fd"
timer_14_call_from_johnson_right_zone.Name = "timer_14_call_from_johnson_right_zone"
timer_14_call_from_johnson_right_zone.Description = "Shows text_14_call_from_johnson_right_zone"
timer_14_call_from_johnson_right_zone.Visible = true
timer_14_call_from_johnson_right_zone.Duration = 2
timer_14_call_from_johnson_right_zone.Type = "Countdown"
timer_16_track_fiona = Wherigo.ZTimer(prometheus_chapter_2)
timer_16_track_fiona.Id = "194e1faf-b884-4553-85bd-3391d7589412"
timer_16_track_fiona.Name = "timer_16_track_fiona"
timer_16_track_fiona.Description = [[Iterates over points_16_track_fiona, thus moving
zone_16_fiona. When Fiona reaches her destination,
Johnson calls again
(text_17_call_from_johnson_stay).]]
timer_16_track_fiona.Visible = true
timer_16_track_fiona.Duration = 1
timer_16_track_fiona.Type = "Countdown"
timer_17_call_from_johnson_stay = Wherigo.ZTimer(prometheus_chapter_2)
timer_17_call_from_johnson_stay.Id = "2b7e1bea-2d60-499f-98fb-d7a451b4b700"
timer_17_call_from_johnson_stay.Name = "timer_17_call_from_johnson_stay"
timer_17_call_from_johnson_stay.Description = "Shows text_17_call_from_johnson_stay"
timer_17_call_from_johnson_stay.Visible = true
timer_17_call_from_johnson_stay.Duration = 3
timer_17_call_from_johnson_stay.Type = "Countdown"
timer_18_greenwitch_meets_daughter = Wherigo.ZTimer(prometheus_chapter_2)
timer_18_greenwitch_meets_daughter.Id = "c93c2dab-c4b8-44de-a95b-22e37baa3f5f"
timer_18_greenwitch_meets_daughter.Name = "timer_18_greenwitch_meets_daughter"
timer_18_greenwitch_meets_daughter.Description = [[Iterates over
timeout_18_greenwitch_meets_daughter
and
text_18_greenwitch_meets_daughter,
thus conducting the dialog between
John Greenwitch and his daughter. While
text_18_greenwitch_meets_daughter
holds the text for the dialog,
timeout_18_greenwitch_meets_daughter
holds the time in seconds for each text.

If the player did not warn Greenwitch while
he was talking to his daughter,
task_19_warn_greenwitch_or_wait
will be completed with
bool_19_warned_greenwitch being false,
which leads to the traitors' end of this game.]]
timer_18_greenwitch_meets_daughter.Visible = true
timer_18_greenwitch_meets_daughter.Duration = 11
timer_18_greenwitch_meets_daughter.Type = "Countdown"
timer_21a_call_from_johnson_gratitude_traitors_end = Wherigo.ZTimer(prometheus_chapter_2)
timer_21a_call_from_johnson_gratitude_traitors_end.Id = "42464d0c-87b1-48e4-922f-9e1dd2a9b9de"
timer_21a_call_from_johnson_gratitude_traitors_end.Name = "timer_21a_call_from_johnson_gratitude_traitors_end"
timer_21a_call_from_johnson_gratitude_traitors_end.Description = [[Mr. Johnson expresses his gratitude to the
player for selling out John Greenwitch.
TRAITORS' END]]
timer_21a_call_from_johnson_gratitude_traitors_end.Visible = true
timer_21a_call_from_johnson_gratitude_traitors_end.Duration = 3
timer_21a_call_from_johnson_gratitude_traitors_end.Type = "Countdown"
timer_21b_call_from_johnson_threat = Wherigo.ZTimer(prometheus_chapter_2)
timer_21b_call_from_johnson_threat.Id = "d0ffabe6-bfad-4ff0-b76f-55380eba1444"
timer_21b_call_from_johnson_threat.Name = "timer_21b_call_from_johnson_threat"
timer_21b_call_from_johnson_threat.Description = "Shows text_21b_call_from_johnson_threat"
timer_21b_call_from_johnson_threat.Visible = true
timer_21b_call_from_johnson_threat.Duration = 3
timer_21b_call_from_johnson_threat.Type = "Countdown"
timer_22_helicopter = Wherigo.ZTimer(prometheus_chapter_2)
timer_22_helicopter.Id = "847e0d33-3967-46ae-9a68-b4e3de51210a"
timer_22_helicopter.Name = "timer_22_helicopter"
timer_22_helicopter.Description = "Simulates an incoming helicopter."
timer_22_helicopter.Visible = true
timer_22_helicopter.Duration = 1
timer_22_helicopter.Type = "Countdown"
timer_22_helicopter_seeking = Wherigo.ZTimer(prometheus_chapter_2)
timer_22_helicopter_seeking.Id = "e7a21d75-014b-400d-9c5c-2bdad4da6349"
timer_22_helicopter_seeking.Name = "timer_22_helicopter_seeking"
timer_22_helicopter_seeking.Description = [[The player is in sight of the helicopter and has
to get away immediately, otherwise the antidote
is lost. This timer will be started when the player
enters zone_22_helicopter and stopped when the
player exits that zone.]]
timer_22_helicopter_seeking.Visible = true
timer_22_helicopter_seeking.Duration = 58
timer_22_helicopter_seeking.Type = "Countdown"
timer_22_agents = Wherigo.ZTimer(prometheus_chapter_2)
timer_22_agents.Id = "63a9b499-271c-4cf0-9fe7-bc832748ca1d"
timer_22_agents.Name = "timer_22_agents"
timer_22_agents.Description = [[Iterates over
points_22_agent_1 and points_22_agent_2,
thus moving
zone_22_agent_1 and zone_22_agent_2.
These zones represent two agents patrolling the
area. The player loses the antidote on entering
one of these zones.]]
timer_22_agents.Visible = true
timer_22_agents.Duration = 1
timer_22_agents.Type = "Countdown"

-- Inputs --
input_08 = Wherigo.ZInput(prometheus_chapter_2)
input_08.Id = "c8cc0a09-fd84-4bb3-afd5-c4133658b711"
input_08.Name = "input_08"
input_08.Description = ""
input_08.Visible = true
input_08.Choices = {
	"1", 
	"2", 
	"3"
}
input_08.InputType = "MultipleChoice"
input_08.Text = ""
input_01_previously = Wherigo.ZInput(prometheus_chapter_2)
input_01_previously.Id = "3d5f5509-1de9-4bbd-9c7d-a3cfff0200df"
input_01_previously.Name = "input_01_previously"
input_01_previously.Description = ""
input_01_previously.Visible = true
input_01_previously.Choices = {}
input_01_previously.InputType = "MultipleChoice"
input_01_previously.Text = ""
input_13_fionas_whereabouts = Wherigo.ZInput(prometheus_chapter_2)
input_13_fionas_whereabouts.Id = "f5ee94db-f09b-4b31-b727-2b05e0ec1199"
input_13_fionas_whereabouts.Name = "input_13_fionas_whereabouts"
input_13_fionas_whereabouts.Description = ""
input_13_fionas_whereabouts.Visible = true
input_13_fionas_whereabouts.InputType = "Text"
input_13_fionas_whereabouts.Text = ""

-- WorksWithList for object commands --

-- functions --
function prometheus_chapter_2:OnStart()
	--[[
	Use this section to initialize localized object
	names, captions, descriptions and what not.
	--]]
	-- General variables
	string_yes = text_yes
	string_no = text_no
	-- item_memo
	item_memo.Name = memo_name
	item_memo.Description = memo_description
	item_memo.Commands.command_view.Text = memo_command_view_caption
	
	-- DRAMATIS PERSONAE
	character_john_greenwitch.Name = character_john_greenwitch_name
	character_john_greenwitch.Description = character_john_greenwitch_description
	character_fiona_greenwitch.Name = character_fiona_greenwitch_name
	character_fiona_greenwitch.Description = character_fiona_greenwitch_description
	character_mr_johnson.Name = character_mr_johnson_name
	character_mr_johnson.Description = character_mr_johnson_description
	character_medical_doctor.Name = character_medical_doctor_name
	character_medical_doctor.Description = character_medical_doctor_description
	
	-- Locations are initialized here
	-- Use 'locations.lua' for the real thing
	-- You can define a 'locations_debug.lua'
	-- to test this game around your house
	zone_09_meet_greenwitch.Points = zone_09_meet_greenwitch_points
	zone_10_shake_off_pursuers.Points = zone_10_shake_off_pursuers_points
	zone_11_meet_greenwitch.Points = zone_11_meet_greenwitch_points
	zone_13_fionas_whereabouts_right.Points = zone_13_fionas_whereabouts_right_points
	zone_13_fionas_whereabouts_wrong_1.Points = zone_13_fionas_whereabouts_wrong_1_points
	zone_13_fionas_whereabouts_wrong_2.Points = zone_13_fionas_whereabouts_wrong_2_points
	zone_13_fionas_whereabouts_wrong_3.Points = zone_13_fionas_whereabouts_wrong_3_points
	zone_13_fionas_whereabouts_wrong_4.Points = zone_13_fionas_whereabouts_wrong_4_points
	zone_16_fiona.Points = zone_16_fiona_points
	zone_18_greenwitch_meets_daughter.Points = zone_18_greenwitch_meets_daughter_points
	zone_21a_traitors_end.Points = zone_21a_traitors_end_points
	zone_22_helicopter.Points = zone_22_helicopter_points
	zone_22_road_block_1.Points = zone_22_road_block_1_points
	zone_22_road_block_2.Points = zone_22_road_block_2_points
	zone_22_road_block_3.Points = zone_22_road_block_3_points
	zone_22_agent_1.Points = points_22_agent_1
	zone_22_agent_2.Points = points_22_agent_2
	zone_22_agent_3.Points = points_22_agent_3
	zone_23_hospital.Points = zone_23_hospital_points
	zone_23c_heroes_end.Points = zone_23c_heroes_end_points
	zone_24d_mourners_end.Points = zone_24d_mourners_end_points
	
	-- 01 (What happened in Chapter One, GC4CTGM)
	task_01_previously.Name = task_01_previously_name
	task_01_previously.Description = task_01_previously_description
	input_01_previously.Text = question_01_previously
	input_01_previously.Choices = {
		string_yes, 
		string_no
	}
	
	-- 03 (Call from Johnson, news about the virus spread)
	item_03_news.Name = item_03_news_name
	item_03_news.Description = item_03_news_description
	item_03_news.Commands.command_view.Text = item_03_news_command_view_caption
	item_03_health_office_answering_machine.Name = item_03_health_office_answering_machine_name
	item_03_health_office_answering_machine.Description = item_03_health_office_answering_machine_description
	item_03_health_office_answering_machine.Commands.command_call.Text = item_03_health_office_answering_machine_command_call_caption
	
	-- 07 (Phoning Greenwitch)
	task_07_call_to_greenwitch.Name = task_07_call_to_greenwitch_name
	task_07_call_to_greenwitch.Description = task_07_call_to_greenwitch_description
	
	-- 09, 10, 11 (Meeting Greenwitch)
	zone_09_meet_greenwitch.Name = zone_meet_greenwitch_name
	zone_09_meet_greenwitch.Description = zone_09_meet_greenwitch_description
	zone_10_shake_off_pursuers.Name = zone_10_shake_off_pursuers_name
	zone_10_shake_off_pursuers.Description = zone_10_shake_off_pursuers_description
	zone_11_meet_greenwitch.Name = zone_meet_greenwitch_name
	zone_11_meet_greenwitch.Description = zone_11_meet_greenwitch_description
	
	-- 12 (The abducted daughter)
	item_12_call_from_johnson_abducted_daughter.Name = item_12_call_from_johnson_abducted_daughter_name
	item_12_call_from_johnson_abducted_daughter.Description = item_12_call_from_johnson_abducted_daughter_description
	item_12_call_from_johnson_abducted_daughter.Commands.command_listen.Text = item_12_command_listen_caption
	
	-- 13 (Looking for Fiona)
	zone_13_fionas_whereabouts_right.Name = zone_13_fionas_whereabouts_name
	zone_13_fionas_whereabouts_right.Description = zone_13_fionas_whereabouts_description
	zone_13_fionas_whereabouts_wrong_1.Name = zone_13_fionas_whereabouts_name
	zone_13_fionas_whereabouts_wrong_1.Description = zone_13_fionas_whereabouts_description
	zone_13_fionas_whereabouts_wrong_2.Name = zone_13_fionas_whereabouts_name
	zone_13_fionas_whereabouts_wrong_2.Description = zone_13_fionas_whereabouts_description
	zone_13_fionas_whereabouts_wrong_3.Name = zone_13_fionas_whereabouts_name
	zone_13_fionas_whereabouts_wrong_3.Description = zone_13_fionas_whereabouts_description
	zone_13_fionas_whereabouts_wrong_4.Name = zone_13_fionas_whereabouts_name
	zone_13_fionas_whereabouts_wrong_4.Description = zone_13_fionas_whereabouts_description
	task_13_find_fiona.Name = task_13_find_fiona_name
	task_13_find_fiona.Description = task_13_find_fiona_description
	input_13_fionas_whereabouts.Text = question_13_fionas_whereabouts
	
	-- 16 (Following Fiona)
	zone_16_fiona.Name = zone_16_fiona_name
	zone_16_fiona.Description = zone_16_fiona_description
	int_16_track_fiona_length = #points_16_track_fiona
	
	-- 18 (Fiona meets Greenwitch, they talk)
	-- Zone 18 description set in
	-- timer_17_call_from_johnson_stay
	zone_18_greenwitch_meets_daughter.Name = zone_18_greenwitch_meets_daughter_name
	int_18_greenwitch_meets_daughter_length = #timeout_18_greenwitch_meets_daughter
	-- The dialog as spoken text
	audio_18_greenwitch_meets_daughter = {}
	audio_18_greenwitch_meets_daughter[1] = audio_18_greenwitch_meets_daughter_01
	audio_18_greenwitch_meets_daughter[2] = audio_18_greenwitch_meets_daughter_02
	audio_18_greenwitch_meets_daughter[3] = audio_18_greenwitch_meets_daughter_03
	audio_18_greenwitch_meets_daughter[4] = audio_18_greenwitch_meets_daughter_04
	audio_18_greenwitch_meets_daughter[5] = audio_18_greenwitch_meets_daughter_05
	audio_18_greenwitch_meets_daughter[6] = audio_18_greenwitch_meets_daughter_06
	audio_18_greenwitch_meets_daughter[7] = audio_18_greenwitch_meets_daughter_07
	audio_18_greenwitch_meets_daughter[8] = audio_18_greenwitch_meets_daughter_08
	audio_18_greenwitch_meets_daughter[9] = audio_18_greenwitch_meets_daughter_09
	audio_18_greenwitch_meets_daughter[10] = audio_18_greenwitch_meets_daughter_10
	audio_18_greenwitch_meets_daughter[11] = audio_18_greenwitch_meets_daughter_11
	audio_18_greenwitch_meets_daughter[12] = audio_18_greenwitch_meets_daughter_12
	audio_18_greenwitch_meets_daughter[13] = audio_18_greenwitch_meets_daughter_13
	audio_18_greenwitch_meets_daughter[14] = audio_18_greenwitch_meets_daughter_14
	audio_18_greenwitch_meets_daughter[15] = audio_18_greenwitch_meets_daughter_15
	audio_18_greenwitch_meets_daughter[16] = audio_18_greenwitch_meets_daughter_16
	audio_18_greenwitch_meets_daughter[17] = audio_18_greenwitch_meets_daughter_17
	audio_18_greenwitch_meets_daughter[18] = audio_18_greenwitch_meets_daughter_18
	audio_18_greenwitch_meets_daughter[19] = audio_18_greenwitch_meets_daughter_19
	audio_18_greenwitch_meets_daughter[20] = audio_18_greenwitch_meets_daughter_20
	audio_18_greenwitch_meets_daughter[21] = audio_18_greenwitch_meets_daughter_21
	audio_18_greenwitch_meets_daughter[22] = audio_18_greenwitch_meets_daughter_22
	audio_18_greenwitch_meets_daughter[23] = audio_18_greenwitch_meets_daughter_23
	audio_18_greenwitch_meets_daughter[24] = audio_18_greenwitch_meets_daughter_24
	audio_18_greenwitch_meets_daughter[25] = audio_18_greenwitch_meets_daughter_25
	audio_18_greenwitch_meets_daughter[26] = audio_18_greenwitch_meets_daughter_26
	audio_18_greenwitch_meets_daughter[27] = audio_18_greenwitch_meets_daughter_27
	audio_18_greenwitch_meets_daughter[28] = audio_18_greenwitch_meets_daughter_28
	audio_18_greenwitch_meets_daughter[29] = audio_18_greenwitch_meets_daughter_29
	audio_18_greenwitch_meets_daughter[30] = audio_18_greenwitch_meets_daughter_30
	audio_18_greenwitch_meets_daughter[31] = audio_18_greenwitch_meets_daughter_31
	audio_18_greenwitch_meets_daughter[32] = audio_18_greenwitch_meets_daughter_32
	audio_18_greenwitch_meets_daughter[33] = audio_18_greenwitch_meets_daughter_33
	audio_18_greenwitch_meets_daughter[34] = audio_18_greenwitch_meets_daughter_34
	audio_18_greenwitch_meets_daughter[35] = audio_18_greenwitch_meets_daughter_35
	
	-- 19 (Warn -> B, Do not warn -> A)
	task_19_warn_greenwitch_or_wait.Name = task_19_warn_greenwitch_or_wait_name
	task_19_warn_greenwitch_or_wait.Description = task_19_warn_greenwitch_or_wait_description
	
	-- 20 (Antidote to hospital -> C, Caught -> D)
	item_20_antidote.Name = item_20_antidote_name
	item_20_antidote.Description = item_20_antidote_description
	item_20b_minigame_rules.Name = item_20b_minigame_rules_name
	item_20b_minigame_rules.Description = item_20b_minigame_rules_description
	item_20b_minigame_rules.Commands.command_view.Text = item_20b_command_view_caption
	task_20b_bring_antidote_to_hospital.Name = task_20b_bring_antidote_to_hospital_name
	task_20b_bring_antidote_to_hospital.Description = task_20b_bring_antidote_to_hospital_description
	
	-- 21a (TRAITORS END)
	zone_21a_traitors_end.Name = zone_21a_traitors_end_name
	zone_21a_traitors_end.Description = zone_21a_traitors_end_description
	
	-- 22 (Henchmen: incoming helicopter)
	zone_22_helicopter.Name = zone_22_helicopter_name
	zone_22_helicopter.Description = zone_22_helicopter_description
	
	-- 22 (Henchmen: road blocks)
	zone_22_road_block_1.Name = zone_22_road_block_name
	zone_22_road_block_1.Description = zone_22_road_block_description
	zone_22_road_block_2.Name = zone_22_road_block_name
	zone_22_road_block_2.Description = zone_22_road_block_description
	zone_22_road_block_3.Name = zone_22_road_block_name
	zone_22_road_block_3.Description = zone_22_road_block_description
	
	-- 22 (Henchmen: agents)
	zone_22_agent_1.Name = zone_22_agents_name
	zone_22_agent_1.Description = zone_22_agents_description
	int_22_agent_1_length = #points_22_agent_1
	zone_22_agent_2.Name = zone_22_agents_name
	zone_22_agent_2.Description = zone_22_agents_description
	int_22_agent_2_length = #points_22_agent_2
	zone_22_agent_3.Name = zone_22_agents_name
	zone_22_agent_3.Description = zone_22_agents_description
	int_22_agent_3_length = #points_22_agent_3
	
	-- 23 (The hospital)
	zone_23_hospital.Name = zone_23_hospital_name
	zone_23_hospital.Description = zone_23_hospital_description
	
	-- 23c (HEROES END)
	zone_23c_heroes_end.Name = zone_23c_heroes_end_name
	zone_23c_heroes_end.Description = zone_23c_heroes_end_description
	
	-- 24d (MOURNERS END)
	zone_24d_mourners_end.Name = zone_24d_mourners_end_name
	zone_24d_mourners_end.Description = zone_24d_mourners_end_description
	
	-- Completion code
	item_completion_code.Name = item_completion_code_name
	item_completion_code.Description = item_completion_code_description
	item_completion_code.Commands.command_view.Text = item_completion_code_command_view_caption
	
	-- Credits
	item_credits.Name = item_credits_name
	item_credits.Description = item_credits_description
	item_credits.Commands.command_view.Text = item_credits_command_view_caption
	
end
function prometheus_chapter_2:OnRestore()
end
function zone_09_meet_greenwitch:OnEnter()
	_BNP0K = "zone_09_meet_greenwitch"
	timer_10_call_from_greenwitch_followed:Start()
end
function zone_11_meet_greenwitch:OnEnter()
	_BNP0K = "zone_11_meet_greenwitch"
	if bool_10_pursuers_shaken_off == true then
		zone_11_meet_greenwitch.Active = false
		timer_11_call_from_greenwitch:Start()
	else
		dialog(text_10_shake_off_pursuers_first)
		
	end
end
function zone_23_hospital:OnEnter()
	_BNP0K = "zone_23_hospital"
	bool_22_henchmen_active = false
	stop_22_helicopter()
	stop_22_agents()
	stop_22_road_blocks()
	if Player:Contains(item_20_antidote) then
		item_20_antidote:MoveTo(character_medical_doctor)
		Wherigo.PlayAudio(audio_23c_reaching_hospital_heroes_end)
		dialog(text_23c_reaching_hospital_heroes_end, nil, text_ok, function()
			save_game(text_event_23c_reaching_hospital_heroes_end)
			show_23c_heroes_end()
		end)
		
	else
		Wherigo.PlayAudio(audio_24d_reaching_hospital_mourners_end)
		dialog(text_24d_reaching_hospital_mourners_end, nil, text_ok, function()
			save_game(text_event_23d_lost_antidote_to_johnson)
			show_24d_mourners_end()
		end)
		
	end
	task_20b_bring_antidote_to_hospital.Complete = true
	zone_23_hospital.Active = false
	zone_23_hospital.Visible = false
end
function zone_10_shake_off_pursuers:OnExit()
	_BNP0K = "zone_10_shake_off_pursuers"
	zone_10_shake_off_pursuers.Active = false
	if int_10_shake_off_pursuers > 0 then
		int_10_shake_off_pursuers = int_10_shake_off_pursuers + -1
		timer_10_shake_off_pursuers:Start()
	else
		dialog(text_10_no_pursuers_anymore, nil, text_ok)
		
		bool_10_pursuers_shaken_off = true
	end
end
function zone_16_fiona:OnEnter()
	_BNP0K = "zone_16_fiona"
	timer_16_track_fiona:Stop()
	dialog(text_16_track_fiona, img_16_track_fiona)
	
end
function zone_16_fiona:OnExit()
	_BNP0K = "zone_16_fiona"
	timer_16_track_fiona:Start()
end
function zone_18_greenwitch_meets_daughter:OnEnter()
	_BNP0K = "zone_18_greenwitch_meets_daughter"
	bool_19_can_warn_greenwitch = true
end
function zone_18_greenwitch_meets_daughter:OnExit()
	_BNP0K = "zone_18_greenwitch_meets_daughter"
	bool_19_can_warn_greenwitch = false
end
function zone_18_greenwitch_meets_daughter:OnProximity()
	_BNP0K = "zone_18_greenwitch_meets_daughter"
	if bool_17_call_from_johnson_stay == false then
		bool_17_call_from_johnson_stay = true
		timer_17_call_from_johnson_stay:Start()
	end
end
function zone_21a_traitors_end:OnEnter()
	_BNP0K = "zone_21a_traitors_end"
	finish_game()
end
function zone_23c_heroes_end:OnEnter()
	_BNP0K = "zone_23c_heroes_end"
	finish_game()
end
function zone_24d_mourners_end:OnEnter()
	_BNP0K = "zone_24d_mourners_end"
	finish_game()
end
function zone_22_helicopter:OnEnter()
	_BNP0K = "zone_22_helicopter"
	timer_22_helicopter_seeking:Start()
	Wherigo.PlayAudio(sound_helicopter)
end
function zone_22_helicopter:OnExit()
	_BNP0K = "zone_22_helicopter"
	Wherigo.PlayAudio(sound_helicopter_leaving)
	timer_22_helicopter_seeking:Stop()
end
function zone_22_road_block_1:OnEnter()
	_BNP0K = "zone_22_road_block_1"
	show_23d_lose_antidote_to_johnson()
end
function zone_22_agent_1:OnEnter()
	_BNP0K = "zone_22_agent_1"
	show_23d_lose_antidote_to_johnson()
end
function zone_22_agent_2:OnEnter()
	_BNP0K = "zone_22_agent_2"
	show_23d_lose_antidote_to_johnson()
end
function zone_22_agent_3:OnEnter()
	_BNP0K = "zone_22_agent_3"
	show_23d_lose_antidote_to_johnson()
end
function zone_22_road_block_2:OnEnter()
	_BNP0K = "zone_22_road_block_2"
	show_23d_lose_antidote_to_johnson()
end
function zone_22_road_block_3:OnEnter()
	_BNP0K = "zone_22_road_block_3"
	show_23d_lose_antidote_to_johnson()
end
function task_07_call_to_greenwitch:OnSetComplete()
	task_07_call_to_greenwitch.Visible = false
	task_08_call_to_greenwitch_end.Active = true
end
function task_07_call_to_greenwitch:OnClick()
	Wherigo.PlayAudio(audio_08_call_to_greenwitch)
	if bool_06a_call_from_johnson_daughter_abducted == true then
		input_08.Text = string.format([[%s
		1:
		%s
		2:
		%s
		3:
		%s]], text_08_call_to_greenwitch, text_08_call_to_greenwitch_a_honest[1], text_08_call_to_greenwitch_b_hide[1], text_08_call_to_greenwitch_c_a06[1])
		
		input_08.Choices = {
			"1", 
			"2", 
			"3"
		}
		
	else
		input_08.Text = string.format([[%s
		1:
		%s
		2:
		%s]], text_08_call_to_greenwitch, text_08_call_to_greenwitch_a_honest[1], text_08_call_to_greenwitch_b_hide[1])
		
		input_08.Choices = {
			"1", 
			"2"
		}
		
	end
	_Urwigo.RunDialogs(function()
		Wherigo.GetInput(input_08)
	end)
end
function task_01_previously:OnSetComplete()
	save_game(string.format([[%s
	%s]], text_01_previously, text_event_01_previously), prometheus_chapter_2)
	
	timer_02_call_from_johnson:Start()
end
function task_01_previously:OnClick()
	_Urwigo.RunDialogs(function()
		Wherigo.GetInput(input_01_previously)
	end)
end
function task_04_call_from_johnson_1_2:OnSetActive()
	Wherigo.PlayAudio(audio_04_call_from_johnson_1_2)
	save_game(text_event_04_call_from_johnson)
	
	question(string.format([[%s
	1:
	%s
	2:
	%s]], text_04_call_from_johnson_1_2, text_06a_call_from_johnson_daughter_abducted[1], text_05b_call_from_johnson), nil, "1", "2", function()
		show_06a_call_from_johnson_daughter_abducted()
	end, function()
		task_04_call_from_johnson_1_2.Complete = true
	end)
	
end
function task_04_call_from_johnson_1_2:OnSetComplete()
	task_07_call_to_greenwitch.Active = true
	task_07_call_to_greenwitch.Visible = true
end
function task_08_call_to_greenwitch_end:OnSetActive()
	Wherigo.PlayAudio(audio_08_call_to_greenwitch_end)
	dialog(text_08_call_to_greenwitch_end, nil, text_ok, function()
		task_08_call_to_greenwitch_end.Complete = true
	end)
	
end
function task_08_call_to_greenwitch_end:OnSetComplete()
	zone_09_meet_greenwitch.Active = true
	zone_09_meet_greenwitch.Visible = true
end
function task_19_warn_greenwitch_or_wait:OnSetComplete()
	task_19_warn_greenwitch_or_wait.Active = false
	task_19_warn_greenwitch_or_wait.Visible = false
	zone_18_greenwitch_meets_daughter.Active = false
	zone_18_greenwitch_meets_daughter.Visible = false
	if bool_19_warned_greenwitch == true then
		dialog(text_20b_call_from_greenwitch_antidote, img_john_greenwitch, text_ok, function()
			timer_21b_call_from_johnson_threat:Start()
		end)
		
	else
		bool_19_can_warn_greenwitch = false
		Wherigo.PlayAudio(sound_lost_antidote_to_johnson)
		dialog(text_event_20a_johnson_kidnaps_greenwitch, img_van, text_ok, function()
			save_game(text_event_20a_johnson_kidnaps_greenwitch)
			timer_21a_call_from_johnson_gratitude_traitors_end:Start()
		end)
		
	end
end
function task_19_warn_greenwitch_or_wait:OnClick()
	show_19_warn_greenwitch()
end
function task_20b_bring_antidote_to_hospital:OnSetActive()
	--[[The better name for this event would have been something like "BeforeActivityChange()" because this task is still not active, when this event is triggered.]]
	if (task_20b_bring_antidote_to_hospital.Active == false) and (task_20b_bring_antidote_to_hospital.Complete == false) then
		item_20_antidote:MoveTo(Player)
		--[[Show the hospital zone and activate it. The player must dodge all of Mr. Johnson's henchmen's attempts to lay hands on him.]]
		zone_23_hospital.Active = true
		zone_23_hospital.Visible = true
		bool_22_henchmen_active = true
		trigger_22_road_blocks()
		trigger_22_agents()
		trigger_22_helicopter()
	end
end
function task_20b_bring_antidote_to_hospital:OnSetComplete()
	task_20b_bring_antidote_to_hospital.Active = false
	task_20b_bring_antidote_to_hospital.Visible = false
end
function debug_task:OnClick()
	task_20b_bring_antidote_to_hospital.Active = false
	task_20b_bring_antidote_to_hospital.Complete = false
	show_20b_bring_antidote_to_hospital()
end
function debug_task_lose_antidote:OnClick()
	item_20_antidote:MoveTo(Player)
	zone_23_hospital.Active = true
	zone_23_hospital.Visible = true
	show_23d_lose_antidote_to_johnson()
end
function task_13_find_fiona:OnClick()
	_Urwigo.RunDialogs(function()
		Wherigo.GetInput(input_13_fionas_whereabouts)
	end)
end
function input_08:OnGetInput(input)
	if input == nil then
		input = ""
	end
	if Wherigo.NoCaseEquals(input, "1") then
		save_game(text_event_08_call_to_greenwitch_a_honest)
		
		Wherigo.PlayAudio(audio_08_call_to_greenwitch_a_honest)
		dialog(text_08_call_to_greenwitch_a_honest[2], nil, text_ok, function()
			task_07_call_to_greenwitch.Complete = true
		end)
		
	elseif Wherigo.NoCaseEquals(input, "2") then
		save_game(text_event_08_call_to_greenwitch_b_hide)
		
		Wherigo.PlayAudio(audio_08_call_to_greenwitch_b_hide)
		dialog(text_08_call_to_greenwitch_b_hide[2], nil, text_ok, function()
			task_07_call_to_greenwitch.Complete = true
		end)
		
	elseif Wherigo.NoCaseEquals(input, "3") then
		save_game(text_event_08_call_to_greenwitch_c_a06)
		
		Wherigo.PlayAudio(audio_08_call_to_greenwitch_c_a06)
		dialog(text_08_call_to_greenwitch_c_a06[2], nil, text_ok, function()
			task_07_call_to_greenwitch.Complete = true
			bool_08_told_greenwitch_about_abduction = true
		end)
		
	else
	end
end
function input_01_previously:OnGetInput(input)
	if input == nil then
		input = ""
	end
	if Wherigo.NoCaseEquals(input, string_yes) then
		-- The task shall be complete after
		-- clicking okay and not right away
		dialog(text_01_previously, img_prometheus_chapter_1, text_ok, function()
			task_01_previously.Complete = true
		end)
		
	else
		task_01_previously.Complete = true
	end
end
function input_13_fionas_whereabouts:OnGetInput(input)
	if input == nil then
		input = ""
	end
	if zone_13_fionas_whereabouts_right:Contains(Player) and (((Wherigo.NoCaseEquals(input, "onekana") or Wherigo.NoCaseEquals(input, "h. onekana")) or Wherigo.NoCaseEquals(input, "Onekana")) or Wherigo.NoCaseEquals(input, "H. Onekana")) then
		show_13_found_fiona()
	end
end
function timer_02_call_from_johnson:OnTick()
	incoming_phone_call(text_incoming_call_johnson, audio_02_call_from_johnson_1_1, text_02_call_from_johnson_1_1, img_mr_johnson, function()
		item_03_news.Visible = true
		show_03_news()
	end, text_ignore_call, function()
		timer_02_call_from_johnson:Start()
	end)
	
end
function timer_10_shake_off_pursuers:OnTick()
	zone_10_shake_off_pursuers.Points = regular_polygon(Player.ObjectLocation, 30, 6)
	
	zone_10_shake_off_pursuers.Visible = true
	zone_10_shake_off_pursuers.Active = true
end
function timer_11_call_from_greenwitch:OnTick()
	if bool_08_told_greenwitch_about_abduction == true then
		incoming_phone_call(text_incoming_call_greenwitch, audio_11_call_from_greenwitch_abduction_known, text_11_call_from_greenwitch_abduction_known, img_john_greenwitch, function()
			save_game(text_event_11_call_from_greenwitch_abduction_known)
			item_12_call_from_johnson_abducted_daughter.Visible = true
		end, text_ignore_call, function()
			timer_11_call_from_greenwitch:Start()
		end)
		
	else
		incoming_phone_call(text_incoming_call_greenwitch, audio_11_call_from_greenwitch_abduction, text_11_call_from_greenwitch_abduction, img_john_greenwitch, function()
			save_game(text_event_11_call_from_greenwitch_abduction)
			item_12_call_from_johnson_abducted_daughter.Visible = true
		end, text_ignore_call, function()
			timer_11_call_from_greenwitch:Start()
		end)
		
	end
end
function timer_10_call_from_greenwitch_followed:OnTick()
	incoming_phone_call(text_incoming_call_greenwitch, audio_10_call_from_greenwitch_followed, text_10_call_from_greenwitch_followed, img_john_greenwitch, function()
		save_game(text_event_10_shake_off_pursuers_first)
		zone_09_meet_greenwitch.Visible = false
		zone_09_meet_greenwitch.Active = false
		timer_10_shake_off_pursuers:Start()
		zone_11_meet_greenwitch.Visible = true
		zone_11_meet_greenwitch.Active = true
	end, text_ignore_call, function()
		timer_10_call_from_greenwitch_followed:Start()
	end)
	
end
function timer_14_call_from_johnson_right_zone:OnTick()
	incoming_phone_call(text_incoming_call_johnson, audio_14_call_from_johnson_right_zone, text_14_call_from_johnson_right_zone, img_mr_johnson, function()
		show_15_call_from_johnson_radio_tag()
	end, text_ignore_call, function()
		timer_14_call_from_johnson_right_zone:Start()
	end)
	
end
function timer_16_track_fiona:OnTick()
	if int_16_track_fiona_iterator <= int_16_track_fiona_length then
		zone_16_fiona.Active = false
		zone_16_fiona.Visible = true
		zone_16_fiona.Points = regular_polygon(points_16_track_fiona[int_16_track_fiona_iterator], 15, 3, 120)
		
		zone_16_fiona.Active = true
		int_16_track_fiona_iterator = int_16_track_fiona_iterator + 1
		timer_16_track_fiona:Start()
	else
		show_18_greenwitch_meets_daughter()
	end
end
function timer_17_call_from_johnson_stay:OnTick()
	incoming_phone_call(text_incoming_call_johnson, audio_17_call_from_johnson_stay, text_17_call_from_johnson_stay, img_mr_johnson, function()
		zone_18_greenwitch_meets_daughter.Description = zone_18_greenwitch_meets_daughter_description
		timer_18_greenwitch_meets_daughter:Start()
	end, text_ignore_call, function()
		timer_17_call_from_johnson_stay:Start()
	end)
	
end
function timer_18_greenwitch_meets_daughter:OnTick()
	if int_18_greenwitch_meets_daughter_iterator <= int_18_greenwitch_meets_daughter_length then
		if bool_19_warned_greenwitch == false then
			if bool_19_can_warn_greenwitch == true then
				Wherigo.PlayAudio(audio_18_greenwitch_meets_daughter[int_18_greenwitch_meets_daughter_iterator])
				
				accumulate_text_18(text_18_greenwitch_meets_daughter[int_18_greenwitch_meets_daughter_iterator])
				dialog(text_18, img_18_greenwitch_meets_daughter_near, text_19_warn_greenwitch, function()
					show_19_warn_greenwitch()
				end)
				
			end
			timer_18_greenwitch_meets_daughter.Duration = timeout_18_greenwitch_meets_daughter[int_18_greenwitch_meets_daughter_iterator]
			
			int_18_greenwitch_meets_daughter_iterator = int_18_greenwitch_meets_daughter_iterator + 1
			timer_18_greenwitch_meets_daughter:Start()
		end
	else
		if bool_19_warned_greenwitch == false then
			task_19_warn_greenwitch_or_wait.Complete = true
		end
	end
end
function timer_21a_call_from_johnson_gratitude_traitors_end:OnTick()
	incoming_phone_call(text_incoming_call_johnson, audio_21a_call_from_johnson_gratitude_traitors_end, text_21a_call_from_johnson_gratitude_traitors_end, img_mr_johnson, function()
		save_game(text_event_21a_call_from_johnson_gratitude_traitors_end)
		show_21a_traitors_end()
	end, text_ignore_call, function()
		timer_21a_call_from_johnson_gratitude_traitors_end:Start()
	end)
	
end
function timer_21b_call_from_johnson_threat:OnTick()
	incoming_phone_call(text_incoming_call_johnson, audio_21b_call_from_johnson_threat, text_21b_call_from_johnson_threat, img_mr_johnson, function()
		save_game(text_event_21b_call_from_johnson_threat)
		show_20b_bring_antidote_to_hospital()
	end, text_ignore_call, function()
		timer_21b_call_from_johnson_threat:Start()
	end)
	
end
function timer_22_helicopter:OnTick()
	if not zone_22_helicopter:Contains(Player) then
		zone_22_helicopter.Active = false
		zone_22_helicopter.Points = regular_polygon(location_22_helicopter, int_22_helicopter_range_of_sight, 5)
		
		zone_22_helicopter.Active = bool_22_henchmen_active
		zone_22_helicopter.Visible = bool_22_henchmen_active
		distance, int_22_helicopter_direction = Wherigo.VectorToPoint(Player.ObjectLocation, location_22_helicopter)
		distance = distance - int_22_helicopter_speed
		int_22_helicopter_distance = distance "m"
		location_22_helicopter = Wherigo.TranslatePoint(Player.ObjectLocation, distance, int_22_helicopter_direction)
		
	end
	--[[The code above takes time.]]
	--[[bool_22_henchmen_active may have been true]]
	--[[at that time and turned false meanwhile, so we]]
	--[[ask for it again before restarting the timer.]]
	if bool_22_henchmen_active == true then
		timer_22_helicopter:Start()
	end
end
function timer_22_helicopter_seeking:OnTick()
	if (bool_22_henchmen_active == true) and zone_22_helicopter:Contains(Player) then
		show_23d_lose_antidote_to_johnson()
	end
end
function timer_22_agents:OnTick()
	if bool_22_henchmen_active == true then
		handle_22_agent_1()
		handle_22_agent_2()
		handle_22_agent_3()
	end
	--[[The code above takes time.]]
	--[[bool_22_henchmen_active may have been true]]
	--[[at that time and turned false meanwhile, so we]]
	--[[ask for it again before restarting the timer.]]
	if bool_22_henchmen_active == true then
		timer_22_agents:Start()
	end
end
function item_12_call_from_johnson_abducted_daughter:Oncommand_listen(target)
	show_12_call_from_johnson_abducted_daughter()
end
function item_memo:Oncommand_view(target)
	dialog(text_memo)
	
end
function item_03_health_office_answering_machine:Oncommand_call(target)
	show_03_health_office_answering_machine()
end
function item_03_news:Oncommand_view(target)
	show_03_news()
end
function item_20b_minigame_rules:Oncommand_view(target)
	show_20b_minigame_rules()
end
function item_completion_code:Oncommand_view(target)
	show_completion_code()
end
function item_credits:Oncommand_view(target)
	show_credits()
end

-- Urwigo functions --
function show_03_news()
	dialog(text_03_news, nil, text_ok, function()
		--        item_03_health_office_answering_machine.Visible = true
		if not task_04_call_from_johnson_1_2.Complete then
			task_04_call_from_johnson_1_2.Active = true
		end
	end)
	
end
function show_03_health_office_answering_machine()
	Wherigo.PlayAudio(audio_03_health_office_answering_machine)
	dialog(text_03_health_office_answering_machine)
	
end
function show_06a_call_from_johnson_daughter_abducted()
	bool_06a_call_from_johnson_daughter_abducted = true
	Wherigo.PlayAudio(audio_06a_call_from_johnson_daughter_abducted)
	dialog(text_06a_call_from_johnson_daughter_abducted[2], nil, text_ok, function()
		task_04_call_from_johnson_1_2.Complete = true
		save_game(text_event_06a_call_from_johnson_daughter_abducted)
	end)
	
end
function show_12_call_from_johnson_abducted_daughter()
	Wherigo.PlayAudio(audio_12_call_from_johnson_abducted_daughter)
	dialog(text_12_call_from_johnson_abducted_daughter, img_fiona_greenwitch, text_ok, function()
		show_13_fionas_possible_whereabouts()
	end)
	
end
function show_13_fionas_possible_whereabouts()
	if bool_13_fionas_whereabouts_found == false then
		task_13_find_fiona.Active = true
		task_13_find_fiona.Visible = true
		zone_13_fionas_whereabouts_right.Active = true
		zone_13_fionas_whereabouts_right.Visible = true
		zone_13_fionas_whereabouts_wrong_1.Active = true
		zone_13_fionas_whereabouts_wrong_1.Visible = true
		zone_13_fionas_whereabouts_wrong_2.Active = true
		zone_13_fionas_whereabouts_wrong_2.Visible = true
		zone_13_fionas_whereabouts_wrong_3.Active = true
		zone_13_fionas_whereabouts_wrong_3.Visible = true
		zone_13_fionas_whereabouts_wrong_4.Active = true
		zone_13_fionas_whereabouts_wrong_4.Visible = true
	end
end
function show_15_call_from_johnson_radio_tag()
	Wherigo.PlayAudio(audio_15_call_from_johnson_radio_tag)
	dialog(text_15_call_from_johnson_radio_tag, nil, text_ok, function()
		save_game(text_event_15_call_from_johnson_radio_tag)
		timer_16_track_fiona:Start()
	end)
	
end
function show_18_greenwitch_meets_daughter()
	zone_16_fiona.Active = false
	zone_16_fiona.Visible = false
	zone_18_greenwitch_meets_daughter.Active = true
	zone_18_greenwitch_meets_daughter.Visible = true
	task_19_warn_greenwitch_or_wait.Active = true
	task_19_warn_greenwitch_or_wait.Visible = true
	character_fiona_greenwitch:MoveTo(zone_18_greenwitch_meets_daughter)
	character_john_greenwitch:MoveTo(zone_18_greenwitch_meets_daughter)
end
function show_19_warn_greenwitch()
	if (bool_19_can_warn_greenwitch == true) and (task_19_warn_greenwitch_or_wait.Complete == false) then
		timer_18_greenwitch_meets_daughter:Stop()
		bool_19_warned_greenwitch = true
		task_19_warn_greenwitch_or_wait.Complete = true
	elseif task_19_warn_greenwitch_or_wait.Complete == false then
		dialog(text_19_cannot_warn_greenwitch, img_18_greenwitch_meets_daughter_far)
		
	else
		dialog(text_19_cannot_warn_greenwitch_anymore, img_van)
		
	end
end
function show_21a_traitors_end()
	zone_21a_traitors_end.Active = true
	zone_21a_traitors_end.Visible = true
end
function show_20b_bring_antidote_to_hospital()
	show_20b_minigame_rules()
end
function show_23c_heroes_end()
	zone_23c_heroes_end.Active = true
	zone_23c_heroes_end.Visible = true
end
function show_24d_mourners_end()
	zone_24d_mourners_end.Active = true
	zone_24d_mourners_end.Visible = true
end
function show_23d_lose_antidote_to_johnson()
	bool_22_henchmen_active = false
	stop_22_helicopter()
	stop_22_agents()
	stop_22_road_blocks()
	if Player:Contains(item_20_antidote) then
		item_20_antidote:MoveTo(character_mr_johnson)
		Wherigo.PlayAudio(sound_lost_antidote_to_johnson)
		dialog(text_event_23d_lost_antidote_to_johnson, img_van)
		
		save_game(text_event_23d_lost_antidote_to_johnson)
		
	end
end
function activate_task_20b_bring_antidote_to_hospital()
	if (task_20b_bring_antidote_to_hospital.Active == false) and (task_20b_bring_antidote_to_hospital.Complete == false) then
		item_20b_minigame_rules.Visible = true
		task_20b_bring_antidote_to_hospital.Active = true
		task_20b_bring_antidote_to_hospital.Visible = true
	end
end
function show_20b_minigame_rules()
	dialog(item_20b_minigame_rules_content, img_20b_minigame_rules, text_ok, function()
		activate_task_20b_bring_antidote_to_hospital()
	end)
	
end
function trigger_22_helicopter()
	int_22_helicopter_direction = math.random(0, 359)
	location_22_helicopter = Wherigo.TranslatePoint(Player.ObjectLocation, Wherigo.Distance(int_22_helicopter_distance, "m"), int_22_helicopter_direction)
	
	timer_22_helicopter:Start()
end
function trigger_22_road_blocks()
	zone_22_road_block_1.Active = true
	zone_22_road_block_1.Visible = true
	zone_22_road_block_2.Active = true
	zone_22_road_block_2.Visible = true
	zone_22_road_block_3.Active = true
	zone_22_road_block_3.Visible = true
end
function trigger_22_agents()
	timer_22_agents:Start()
end
function stop_22_agents()
	timer_22_agents:Stop()
	zone_22_agent_1.Active = false
	zone_22_agent_1.Visible = false
	zone_22_agent_2.Active = false
	zone_22_agent_2.Visible = false
	zone_22_agent_3.Active = false
	zone_22_agent_3.Visible = false
end
function stop_22_helicopter()
	timer_22_helicopter:Stop()
	zone_22_helicopter.Active = false
	zone_22_helicopter.Visible = false
	timer_22_helicopter_seeking:Stop()
end
function stop_22_road_blocks()
	zone_22_road_block_1.Active = false
	zone_22_road_block_1.Visible = false
	zone_22_road_block_2.Active = false
	zone_22_road_block_2.Visible = false
	zone_22_road_block_3.Active = false
	zone_22_road_block_3.Visible = false
end
function handle_22_agent_1()
	if int_22_agent_1_iterator > int_22_agent_1_length then
		int_22_agent_1_iterator = 1
	end
	zone_22_agent_1.Active = false
	zone_22_agent_1.Points = regular_polygon(points_22_agent_1[int_22_agent_1_iterator], 7, 3)
	
	zone_22_agent_1.Visible = bool_22_henchmen_active
	zone_22_agent_1.Active = bool_22_henchmen_active
	int_22_agent_1_iterator = int_22_agent_1_iterator + 1
end
function handle_22_agent_2()
	if int_22_agent_2_iterator > int_22_agent_2_length then
		int_22_agent_2_iterator = 1
	end
	zone_22_agent_2.Active = false
	zone_22_agent_2.Points = regular_polygon(points_22_agent_2[int_22_agent_2_iterator], 7, 3)
	
	zone_22_agent_2.Visible = bool_22_henchmen_active
	zone_22_agent_2.Active = bool_22_henchmen_active
	int_22_agent_2_iterator = int_22_agent_2_iterator + 1
end
function handle_22_agent_3()
	if int_22_agent_3_iterator > int_22_agent_3_length then
		int_22_agent_3_iterator = 1
	end
	zone_22_agent_3.Active = false
	zone_22_agent_3.Points = regular_polygon(points_22_agent_3[int_22_agent_3_iterator], 7, 3)
	
	zone_22_agent_3.Visible = bool_22_henchmen_active
	zone_22_agent_3.Active = bool_22_henchmen_active
	int_22_agent_3_iterator = int_22_agent_3_iterator + 1
end
function show_13_found_fiona()
	bool_13_fionas_whereabouts_found = true
	task_13_find_fiona.Active = false
	task_13_find_fiona.Visible = false
	task_13_find_fiona.Complete = true
	zone_11_meet_greenwitch.Visible = false
	zone_13_fionas_whereabouts_right.Active = false
	zone_13_fionas_whereabouts_right.Visible = false
	zone_13_fionas_whereabouts_wrong_1.Active = false
	zone_13_fionas_whereabouts_wrong_1.Visible = false
	zone_13_fionas_whereabouts_wrong_2.Active = false
	zone_13_fionas_whereabouts_wrong_2.Visible = false
	zone_13_fionas_whereabouts_wrong_3.Active = false
	zone_13_fionas_whereabouts_wrong_3.Visible = false
	zone_13_fionas_whereabouts_wrong_4.Active = false
	zone_13_fionas_whereabouts_wrong_4.Visible = false
	timer_14_call_from_johnson_right_zone:Start()
end
function show_completion_code()
	if prometheus_chapter_2.Complete == true then
		dialog(string.format([[%s :
		%s]], text_event_completion_code, string.sub(Player.CompletionCode, 1, 15)))
		
	end
end
function finish_game()
	if prometheus_chapter_2.Complete == false then
		prometheus_chapter_2.Complete = true
		save_game(string.format([[%s
		%s :
		%s]], text_event_completed_game, text_event_completion_code, string.sub(Player.CompletionCode, 1, 15)))
		
		item_completion_code.Visible = true
		item_credits.Visible = true
		show_credits()
	end
end
function show_credits()
	dialog(item_credits_text)
	
end

-- Begin user functions --
-- End user functions --
return prometheus_chapter_2
